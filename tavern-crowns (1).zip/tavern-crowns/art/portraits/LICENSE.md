# Licence of these files

These files come from The Battle for Wesnoth (https://www.wesnoth.org, https://github.com/wesnoth/wesnoth).
They are licensed under the GNU General Public License version 2 or (at your option) any later version,
except where `CREDITS.md` names Creative Commons Attribution-ShareAlike 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
The full GPL v2 text is in `GPL-2.0.txt` in this folder. Authors and source paths are listed in `CREDITS.md` at the repository root.
