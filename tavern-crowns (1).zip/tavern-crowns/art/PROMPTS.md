# Art prompts
Generate one image per card, save it in this folder as `<id>.webp` (or .png/.jpg), and add it to `manifest.json`. Images of 600×840 px or larger work well.

## Neutral

**Scarecrow** · id `scarecrow`

> Painterly dark-fantasy trading-card illustration: a ragged scarecrow in a wheat field at dusk, wearing a dented kettle helmet and a sack hood. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Royal War Horn** · id `royal_war_horn`

> Painterly dark-fantasy trading-card illustration: a soldier blowing a huge carved aurochs war horn on castle walls, red-and-silver striped pennant. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Táltos Fire** · id `taltos_fire`

> Painterly dark-fantasy trading-card illustration: a pillar of shamanic fire bursting from the earth, burning warriors to ash, embers swirling. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Carpathian Frost** · id `carpathian_frost`

> Painterly dark-fantasy trading-card illustration: a frozen Carpathian mountain village, hoarfrost on thatched roofs, icicles, snow in the wind. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Ecsed Marsh Fog** · id `ecsed_marsh_fog`

> Painterly dark-fantasy trading-card illustration: thick fog over the Ecsed marsh, dead trees and glowing eyes in the mist. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Danube Deluge** · id `danube_deluge`

> Painterly dark-fantasy trading-card illustration: torrential rain over a muddy battlefield by the Danube, a spear stuck in the mud. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Clear Puszta Sky** · id `clear_puszta_sky`

> Painterly dark-fantasy trading-card illustration: sunlight breaking over the great Hungarian plain, a shadoof well and white-walled village. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Balaton Squall** · id `balaton_squall`

> Painterly dark-fantasy trading-card illustration: a violent storm on Lake Balaton, lightning, huge waves tossing a river galley. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Miklós Toldi** · id `miklos_toldi`

> Painterly dark-fantasy trading-card illustration: a giant 14th-century Hungarian strongman knight with a massive pole and a sword, broad shoulders, plain gambeson. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Prince Csaba of the Starry Road** · id `prince_csaba_of_the_starry_road`

> Painterly dark-fantasy trading-card illustration: a young royal horseman riding down the Milky Way, starlight armour, sword raised. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Saint Margaret the Healer** · id `saint_margaret_the_healer`

> Painterly dark-fantasy trading-card illustration: a 13th-century Dominican nun princess healing a wounded soldier with soft golden light. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Saint Elizabeth of the Roses** · id `saint_elizabeth_of_the_roses`

> Painterly dark-fantasy trading-card illustration: a young medieval princess whose apron of bread turns into red roses, castle in the background. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Hooded Táltos** · id `the_hooded_taltos`

> Painterly dark-fantasy trading-card illustration: a hooded táltos shaman with a drum and an antler headdress hidden in smoke, eyes glowing. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Golden Dragon of the Mátra** · id `golden_dragon_of_the_matra`

> Painterly dark-fantasy trading-card illustration: a golden dragon spreading wings over the Mátra mountains, breathing fire. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Old Gáspár, Monster-Hunter** · id `old_gaspar_monster_hunter`

> Painterly dark-fantasy trading-card illustration: a grizzled old monster hunter with a lantern and a silver-edged sword in a snowy forest. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Dömötör the Dwarf** · id `domotor_the_dwarf`

> Painterly dark-fantasy trading-card illustration: a cheerful red-bearded dwarf with a two-handed axe and a tankard. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Kálmán the Nightdrinker** · id `kalman_the_nightdrinker`

> Painterly dark-fantasy trading-card illustration: a gentle pale scholar-vampire in a dark coat reading in a candlelit cellar of herbs. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Igric the Minstrel** · id `igric_the_minstrel`

> Painterly dark-fantasy trading-card illustration: a flamboyant medieval minstrel (igric) playing a lute in a tavern. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Ispán of the Broken Oath** · id `ispan_of_the_broken_oath`

> Painterly dark-fantasy trading-card illustration: a cursed noble count (ispán) with a sabre and a scar, unkillable, in a burning manor. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Mirror Merchant** · id `the_mirror_merchant`

> Painterly dark-fantasy trading-card illustration: a smiling travelling merchant holding a silver hand mirror, too-perfect smile, crossroads at night. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Mirror Shadow** · id `mirror_shadow`

> Painterly dark-fantasy trading-card illustration: a shadow creature crawling out of a broken mirror. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Grey Cattle** · id `grey_cattle`

> Painterly dark-fantasy trading-card illustration: a long-horned Hungarian grey cattle on the puszta. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bull of the Puszta** · id `bull_of_the_puszta`

> Painterly dark-fantasy trading-card illustration: an enormous enraged long-horned grey bull charging, steam from its nostrils. Setting: medieval Central Europe, 12th–14th century. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

## Holy Crown of Hungaria

**Coloman the Learned, Keeper of the Mists** (leader) · id `cr_coloman_the_learned_keeper_of_the_mists`

> Painterly dark-fantasy trading-card illustration: a scholarly king with a book and crown, mist rising behind him. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Saint Ladislaus, the Knight-King** (leader) · id `cr_saint_ladislaus_the_knight_king`

> Painterly dark-fantasy trading-card illustration: a tall knight-king on horseback with a battle-axe. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Béla IV, the Second Founder** (leader) · id `cr_bela_iv_the_second_founder`

> Painterly dark-fantasy trading-card illustration: a king rebuilding stone castles after the Mongol invasion. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Charles Robert, Breaker of Oligarchs** (leader) · id `cr_charles_robert_breaker_of_oligarchs`

> Painterly dark-fantasy trading-card illustration: an Anjou king with lilies on his surcoat storming a rebel castle. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Louis the Great, Lord of Three Seas** (leader) · id `cr_louis_the_great_lord_of_three_seas`

> Painterly dark-fantasy trading-card illustration: a magnificent king in Anjou lilies with three seas behind him. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Castle Ballista** · id `castle_ballista`

> Painterly dark-fantasy trading-card illustration: a heavy ballista on a stone castle tower. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Árpád-Stripe Guard** · id `arpad_stripe_guard`

> Painterly dark-fantasy trading-card illustration: a royal guard with a shield painted with red and silver horizontal stripes. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Stone-Thrower of Esztergom** · id `stone_thrower_of_esztergom`

> Painterly dark-fantasy trading-card illustration: a wooden catapult hurling a stone, Esztergom castle on a hill. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Cuman Horse Archer** · id `cuman_horse_archer`

> Painterly dark-fantasy trading-card illustration: a Cuman horse archer with a composite bow, felt hat, galloping on the plain. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Court Astrologer** · id `court_astrologer`

> Painterly dark-fantasy trading-card illustration: a royal astrologer with an astrolabe on a tower at night. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Hospitaller Surgeon** · id `hospitaller_surgeon`

> Painterly dark-fantasy trading-card illustration: a Knights Hospitaller field surgeon in a black mantle with a white cross. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Palatine Dénes** · id `palatine_denes`

> Painterly dark-fantasy trading-card illustration: the palatine of the kingdom in full mail, holding a mace, 1241. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Ugrin Csák, Warrior-Archbishop** · id `ugrin_csak_warrior_archbishop`

> Painterly dark-fantasy trading-card illustration: a warrior archbishop in mitre and mail, leading knights into battle. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Queen Maria Laskarina** · id `queen_maria_laskarina`

> Painterly dark-fantasy trading-card illustration: a Byzantine-born Hungarian queen in a jewelled crown, a falcon on her arm. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Duke Coloman of Slavonia** · id `duke_coloman_of_slavonia`

> Painterly dark-fantasy trading-card illustration: a young royal duke defending a bridge with a sword, wounded but defiant. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Saxon Siege Engineer** · id `saxon_siege_engineer`

> Painterly dark-fantasy trading-card illustration: a Transylvanian Saxon engineer with a hammer and plans, building a siege engine. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Hedge-Witch of Pilis** · id `hedge_witch_of_pilis`

> Painterly dark-fantasy trading-card illustration: a hedge witch in the Pilis hills holding a glowing green orb. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Levied Peasant** · id `levied_peasant`

> Painterly dark-fantasy trading-card illustration: a frightened peasant levy with a pitchfork and a wicker shield. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bribed Castellan** · id `bribed_castellan`

> Painterly dark-fantasy trading-card illustration: a corrupt castle steward counting gold coins by candlelight. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Castle Warrior** · id `castle_warrior`

> Painterly dark-fantasy trading-card illustration: a castle warrior (várjobbágy) with a spear and kettle hat. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fire-Witch of Szeged** · id `fire_witch_of_szeged`

> Painterly dark-fantasy trading-card illustration: a sorceress conjuring a fireball on the Tisza riverbank. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Silver-Miner of Selmec** · id `silver_miner_of_selmec`

> Painterly dark-fantasy trading-card illustration: a German miner with a pick and a lamp in a silver mine. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Siege Tower** · id `siege_tower`

> Painterly dark-fantasy trading-card illustration: a wooden siege tower covered in hides rolling toward walls. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Teutonic Knight of Barcaság** · id `teutonic_knight_of_barcasag`

> Painterly dark-fantasy trading-card illustration: a Teutonic knight in white mantle with black cross in the Burzenland, 1211. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Spymaster of the Royal Court** · id `spymaster_of_the_royal_court`

> Painterly dark-fantasy trading-card illustration: a large spymaster in a dim office with letters and seals. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Sorceress of Óbuda** · id `sorceress_of_obuda`

> Painterly dark-fantasy trading-card illustration: a noble sorceress on the walls of Óbuda casting a violet spell. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Wandering Peddler-Spy** · id `wandering_peddler_spy`

> Painterly dark-fantasy trading-card illustration: a cheerful peddler with a pack full of trinkets and hidden letters. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Trebuchet** · id `trebuchet`

> Painterly dark-fantasy trading-card illustration: a giant counterweight trebuchet at dawn. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Vitéz of the Border** · id `vitez_of_the_border`

> Painterly dark-fantasy trading-card illustration: a fierce female border warrior (vitéz) with a sabre. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Dwarf of Selmec** · id `dwarf_of_selmec`

> Painterly dark-fantasy trading-card illustration: a stout dwarf with a war hammer and a mining helmet. Setting: 12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

## Golden Basileia

**Alexios Béla, Despot of Two Crowns** (leader) · id `ge_alexios_bela_despot_of_two_crowns`

> Painterly dark-fantasy trading-card illustration: a Hungarian prince raised in Constantinople, in Byzantine robes. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Anna Komnene, the Chronicler** (leader) · id `ge_anna_komnene_the_chronicler`

> Painterly dark-fantasy trading-card illustration: a Byzantine princess-historian writing a chronicle. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Manuel I Komnenos, the Basileus** (leader) · id `ge_manuel_i_komnenos_the_basileus`

> Painterly dark-fantasy trading-card illustration: a Byzantine emperor on a golden throne. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Andronikos Komnenos, the Usurper** (leader) · id `ge_andronikos_komnenos_the_usurper`

> Painterly dark-fantasy trading-card illustration: a charismatic usurper seizing a crown. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Irene Piroska, Founder of the Pantokrator** (leader) · id `ge_irene_piroska_founder_of_the_pantokrator`

> Painterly dark-fantasy trading-card illustration: a Hungarian-born Byzantine empress founding a hospital. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Palace Scribe** · id `palace_scribe`

> Painterly dark-fantasy trading-card illustration: a palace scribe writing with gold ink in a Byzantine scriptorium. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Theodora the Seeress** · id `theodora_the_seeress`

> Painterly dark-fantasy trading-card illustration: a Byzantine seeress with a golden veil, gazing into a bowl of water. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Toxotai Archer** · id `toxotai_archer`

> Painterly dark-fantasy trading-card illustration: a Byzantine archer in lamellar armour drawing a composite bow. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Kataphrakt Commander** · id `kataphrakt_commander`

> Painterly dark-fantasy trading-card illustration: a heavily armoured Byzantine cavalry commander with a gilded helmet. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Court Informant** · id `court_informant`

> Painterly dark-fantasy trading-card illustration: a veiled court lady whispering a secret behind a column. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Monastery Healer** · id `monastery_healer`

> Painterly dark-fantasy trading-card illustration: a monk healer from a Byzantine monastery hospital with herbs. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Sorceress of the Purple Court** · id `sorceress_of_the_purple_court`

> Painterly dark-fantasy trading-card illustration: a sorceress in purple silk with golden embroidery casting a spell. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Greek Fire Siphon** · id `greek_fire_siphon`

> Painterly dark-fantasy trading-card illustration: a bronze siphon spraying Greek fire from a dromon ship. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Varangian Guard** · id `varangian_guard`

> Painterly dark-fantasy trading-card illustration: a Varangian guardsman with a long-hafted axe and a red cloak. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Andronikos Kontostephanos** · id `andronikos_kontostephanos`

> Painterly dark-fantasy trading-card illustration: the victorious Byzantine general of Sirmium 1167 in gilded armour. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Grand Domestic John Axouch** · id `grand_domestic_john_axouch`

> Painterly dark-fantasy trading-card illustration: the grand domestic of the Byzantine army, wise and stern, with a baton. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Skoutatos Spearman** · id `skoutatos_spearman`

> Painterly dark-fantasy trading-card illustration: a Byzantine infantryman with a large oval shield and a spear. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Megas Doux of the Fleet** · id `megas_doux_of_the_fleet`

> Painterly dark-fantasy trading-card illustration: the Byzantine grand admiral on a dromon deck. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Kataphrakt Rider** · id `kataphrakt_rider`

> Painterly dark-fantasy trading-card illustration: a fully armoured Byzantine cavalry rider with a lance. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Psiloi Slinger** · id `psiloi_slinger`

> Painterly dark-fantasy trading-card illustration: a light Byzantine skirmisher whirling a sling. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Palace Assassin** · id `palace_assassin`

> Painterly dark-fantasy trading-card illustration: an assassin with a curved dagger in the shadows of a marble palace. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Toxotes Captain** · id `toxotes_captain`

> Painterly dark-fantasy trading-card illustration: a Byzantine archer captain directing a volley. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Old Mangonel** · id `old_mangonel`

> Painterly dark-fantasy trading-card illustration: an old weathered traction mangonel. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Imperial Ambassador** · id `imperial_ambassador`

> Painterly dark-fantasy trading-card illustration: a smooth Byzantine ambassador presenting a golden gift. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Imperial Siege Engineer** · id `imperial_siege_engineer`

> Painterly dark-fantasy trading-card illustration: a Byzantine engineer with compass and rope beside a siege engine. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Engine-Wright** · id `engine_wright`

> Painterly dark-fantasy trading-card illustration: a craftsman repairing a siege engine. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Spymaster of the Purple Chamber** · id `spymaster_of_the_purple_chamber`

> Painterly dark-fantasy trading-card illustration: a Byzantine spymaster in black and purple with a signet ring. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Logothete** · id `logothete`

> Painterly dark-fantasy trading-card illustration: a Byzantine minister of state with a scroll and seal. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Strategos Nikephoros** · id `strategos_nikephoros`

> Painterly dark-fantasy trading-card illustration: a Byzantine strategos in gilded armour under a double-headed eagle banner. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Ice-Mage of the Pontus** · id `ice_mage_of_the_pontus`

> Painterly dark-fantasy trading-card illustration: a Byzantine mage summoning frost. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Agent of the Logothete** · id `agent_of_the_logothete`

> Painterly dark-fantasy trading-card illustration: a masked imperial agent reading a stolen letter. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Akritai Borderer** · id `akritai_borderer`

> Painterly dark-fantasy trading-card illustration: a Byzantine frontier warrior with a spear on a rocky border. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Young Kaballarios** · id `young_kaballarios`

> Painterly dark-fantasy trading-card illustration: a young Byzantine cavalryman in shining scale armour. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Greek Fire Grenadier** · id `greek_fire_grenadier`

> Painterly dark-fantasy trading-card illustration: a soldier hurling a clay pot of Greek fire. Setting: 12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

## Free Folk of the Bakony

**Tündér Ilona, Queen of the Fairy Garden** (leader) · id `ff_tunder_ilona_queen_of_the_fairy_garden`

> Painterly dark-fantasy trading-card illustration: the fairy queen in her garden of golden apples. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Ilona, the Radiant** (leader) · id `ff_tunder_ilona_the_radiant`

> Painterly dark-fantasy trading-card illustration: the fairy queen glowing with moonlight. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Ilona, Keeper of the Golden Apples** (leader) · id `ff_tunder_ilona_keeper_of_the_golden_apples`

> Painterly dark-fantasy trading-card illustration: the fairy queen guarding a tree of golden apples. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Ilona, of the Winter Moon** (leader) · id `ff_tunder_ilona_of_the_winter_moon`

> Painterly dark-fantasy trading-card illustration: the fairy queen in a winter forest. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Ilona, Hope of the Greenwood** (leader) · id `ff_tunder_ilona_hope_of_the_greenwood`

> Painterly dark-fantasy trading-card illustration: the fairy queen leading forest folk. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Captain of the Mátra Dwarves** · id `captain_of_the_matra_dwarves`

> Painterly dark-fantasy trading-card illustration: a battle-scarred dwarf captain with a crossbow in the Mátra. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fairy Pathfinder** · id `fairy_pathfinder`

> Painterly dark-fantasy trading-card illustration: a slender fairy scout with a bow among Bakony beech trees. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Chieftain of the Bükk Dwarves** · id `chieftain_of_the_bukk_dwarves`

> Painterly dark-fantasy trading-card illustration: a dwarf chieftain with a braided beard and a hammer in a cave of the Bükk. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Archer** · id `tunder_archer`

> Painterly dark-fantasy trading-card illustration: a fairy archer of Tündérkert with silver hair. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Scout** · id `tunder_scout`

> Painterly dark-fantasy trading-card illustration: a fairy scout running through a misty forest. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bükk Dwarf Skirmisher** · id `bukk_dwarf_skirmisher`

> Painterly dark-fantasy trading-card illustration: a dwarf skirmisher with an axe charging out of a cave. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Hajnal, Lady of the Silver Birches** · id `hajnal_lady_of_the_silver_birches`

> Painterly dark-fantasy trading-card illustration: a fairy queen-mother in a grove of silver birches, ancient and fierce. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tündér Skirmisher** · id `tunder_skirmisher`

> Painterly dark-fantasy trading-card illustration: a fairy skirmisher loosing arrows from a tree. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Elder of the Fairy Garden** · id `elder_of_the_fairy_garden`

> Painterly dark-fantasy trading-card illustration: an ancient fairy elder in a ruined fairy garden. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Füvesasszony Herb-Wife** · id `fuvesasszony_herb_wife`

> Painterly dark-fantasy trading-card illustration: an old herb-wife gathering herbs in a forest clearing. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bakony Outlaw** · id `bakony_outlaw`

> Painterly dark-fantasy trading-card illustration: a forest outlaw with a hatchet-staff and a sheepskin cloak. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fairy Seeress** · id `fairy_seeress`

> Painterly dark-fantasy trading-card illustration: a fairy seeress with glowing eyes in an old ruin. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Csongor the Wanderer** · id `csongor_the_wanderer`

> Painterly dark-fantasy trading-card illustration: a wandering hero-archer searching for the fairy garden. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Old Gyula, Outlaw Lord** · id `old_gyula_outlaw_lord`

> Painterly dark-fantasy trading-card illustration: a scarred grey-haired outlaw lord with two swords. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Mountain Dwarf Defender** · id `mountain_dwarf_defender`

> Painterly dark-fantasy trading-card illustration: a dwarf with a huge round shield guarding a mountain gate. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Huntress Rozália** · id `huntress_rozalia`

> Painterly dark-fantasy trading-card illustration: a fierce huntress with a longbow in the Bakony. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fairy Apprentice** · id `fairy_apprentice`

> Painterly dark-fantasy trading-card illustration: a young fairy learning archery. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tünde the Dragon-Fairy** · id `tunde_the_dragon_fairy`

> Painterly dark-fantasy trading-card illustration: a fairy princess whose shadow is a golden dragon. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fairy Bowmaiden** · id `fairy_bowmaiden`

> Painterly dark-fantasy trading-card illustration: a fairy bowmaiden with a scornful look. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Greenwood Recruit** · id `greenwood_recruit`

> Painterly dark-fantasy trading-card illustration: a young forest rebel with a short bow. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Greenwood Veteran** · id `greenwood_veteran`

> Painterly dark-fantasy trading-card illustration: a seasoned forest rebel with a sword and a hood. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Outlaw Captain** · id `outlaw_captain`

> Painterly dark-fantasy trading-card illustration: a charismatic outlaw captain with a feathered cap. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Dwarven Fire-Mortar** · id `dwarven_fire_mortar`

> Painterly dark-fantasy trading-card illustration: a dwarf lighting a primitive fire-mortar in a ruined castle. Setting: ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

## Night Brood

**Vasorrú Bába, Mother of the Brood** (leader) · id `nb_vasorru_baba_mother_of_the_brood`

> Painterly dark-fantasy trading-card illustration: the iron-nosed hag of folk tales. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Lidérc Lord, Bringer of Death** (leader) · id `nb_the_liderc_lord_bringer_of_death`

> Painterly dark-fantasy trading-card illustration: a fiery lidérc in the shape of a lordly man. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Dragon King, Devourer of Realms** (leader) · id `nb_the_dragon_king_devourer_of_realms`

> Painterly dark-fantasy trading-card illustration: a dragon king in human form with a crown of horns. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Garabonciás, Rider of Storms** (leader) · id `nb_the_garaboncias_rider_of_storms`

> Painterly dark-fantasy trading-card illustration: a wandering scholar-sorcerer riding a dragon through storm clouds. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Ördög, the Deceiver** (leader) · id `nb_the_ordog_the_deceiver`

> Painterly dark-fantasy trading-card illustration: a sly folk devil offering a bargain. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Cave Spider** · id `cave_spider`

> Painterly dark-fantasy trading-card illustration: a giant armoured cave spider in a dark cavern. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Brood-Mother Spider** · id `brood_mother_spider`

> Painterly dark-fantasy trading-card illustration: a colossal spider brood-mother covered in eggs. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Lidérc Hatchling** · id `liderc_hatchling`

> Painterly dark-fantasy trading-card illustration: a lidérc hatching from a black egg, a fiery little imp. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Storm Harpy** · id `storm_harpy`

> Painterly dark-fantasy trading-card illustration: a harpy shrieking in a storm. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Basilisk Chick** · id `basilisk_chick`

> Painterly dark-fantasy trading-card illustration: a rooster-serpent basilisk in a ruined well. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Boszorkány: The Brewer** · id `boszorkany_the_brewer`

> Painterly dark-fantasy trading-card illustration: a witch stirring a bubbling cauldron at a witches' sabbath. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Boszorkány: The Spinner** · id `boszorkany_the_spinner`

> Painterly dark-fantasy trading-card illustration: a witch spinning dark threads at a spinning wheel. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Boszorkány: The Whisperer** · id `boszorkany_the_whisperer`

> Painterly dark-fantasy trading-card illustration: a witch whispering curses to the wind. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Undead Ispán** · id `the_undead_ispan`

> Painterly dark-fantasy trading-card illustration: an undead count rising from a battlefield with a rusted crown. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Stone Giant of the Mátra** · id `stone_giant_of_the_matra`

> Painterly dark-fantasy trading-card illustration: a giant made of mountain rock and roots. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Marsh Beetle** · id `marsh_beetle`

> Painterly dark-fantasy trading-card illustration: a giant beetle in the marsh. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Fene** · id `the_fene`

> Painterly dark-fantasy trading-card illustration: the fene, a horned shaggy beast of curses, with glowing eyes. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fire Lidérc** · id `fire_liderc`

> Painterly dark-fantasy trading-card illustration: a lidérc as a burning man made of fire. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Fog Wraith** · id `fog_wraith`

> Painterly dark-fantasy trading-card illustration: a wraith made of marsh fog. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Sárkánykígyó** · id `sarkanykigyo`

> Painterly dark-fantasy trading-card illustration: a winged dragon-serpent (sárkánykígyó) in a thunderstorm. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Mumus** · id `the_mumus`

> Painterly dark-fantasy trading-card illustration: the mumus bogeyman, a tall shadow under a bed. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Church Gargoyle** · id `church_gargoyle`

> Painterly dark-fantasy trading-card illustration: a stone gargoyle coming alive on a Romanesque church. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Grave Ghoul** · id `grave_ghoul`

> Painterly dark-fantasy trading-card illustration: a ghoul crawling over graves. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Graveyard Hag** · id `graveyard_hag`

> Painterly dark-fantasy trading-card illustration: a hag with a long tongue in a graveyard. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Carpathian Griff** · id `carpathian_griff`

> Painterly dark-fantasy trading-card illustration: a griffin on a Carpathian cliff. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Harpy** · id `harpy`

> Painterly dark-fantasy trading-card illustration: a harpy diving from a cliff. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Frost Giant of the Tatras** · id `frost_giant_of_the_tatras`

> Painterly dark-fantasy trading-card illustration: a frost giant in the Tatra mountains. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Seven-Headed Dragon** · id `the_seven_headed_dragon`

> Painterly dark-fantasy trading-card illustration: a seven-headed dragon (hétfejű sárkány) from Hungarian folk tales. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Wyrm of the Tisza** · id `wyrm_of_the_tisza`

> Painterly dark-fantasy trading-card illustration: a giant tentacled river wyrm rising from the Tisza. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Old Man of the Woods** · id `old_man_of_the_woods`

> Painterly dark-fantasy trading-card illustration: an ancient forest spirit made of wood and moss with glowing eyes. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Manó** · id `mano`

> Painterly dark-fantasy trading-card illustration: a mischievous little goblin (manó) with a big grin. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Dögvész, the Plague Maiden** · id `dogvesz_the_plague_maiden`

> Painterly dark-fantasy trading-card illustration: a plague maiden in a rotting veil with rats. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Nightdrinker: Lamia** · id `nightdrinker_lamia`

> Painterly dark-fantasy trading-card illustration: a beautiful lamia vampire with a shriek. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Nightdrinker: Strigoi** · id `nightdrinker_strigoi`

> Painterly dark-fantasy trading-card illustration: a bat-like strigoi vampire. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Nightdrinker: Upír** · id `nightdrinker_upir`

> Painterly dark-fantasy trading-card illustration: a feral upír vampire. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Nightdrinker: Mora** · id `nightdrinker_mora`

> Painterly dark-fantasy trading-card illustration: a mora night-hag vampire sitting on a sleeper's chest. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Nightdrinker: Vrykolakas** · id `nightdrinker_vrykolakas`

> Painterly dark-fantasy trading-card illustration: a hulking vrykolakas vampire. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Farkasember** · id `farkasember`

> Painterly dark-fantasy trading-card illustration: a werewolf (farkasember) howling at the moon. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Lesser Dragon** · id `lesser_dragon`

> Painterly dark-fantasy trading-card illustration: a lesser two-legged dragon over a cliff. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bog-Toad King** · id `bog_toad_king`

> Painterly dark-fantasy trading-card illustration: a monstrous crowned toad in a bog spitting poison. Setting: Hungarian folk-tale horror, marsh mist, moonlight, twisted willows. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

## River Clans of the Danube

**Botond, of the Iron Mace** (leader) · id `rc_botond_of_the_iron_mace`

> Painterly dark-fantasy trading-card illustration: a legendary warrior striking a city gate with an iron mace. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Lehel, of the Horn** (leader) · id `rc_lehel_of_the_horn`

> Painterly dark-fantasy trading-card illustration: a legendary chieftain with a carved horn. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bear-Kin Warrior** · id `bear_kin_warrior`

> Painterly dark-fantasy trading-card illustration: a wild warrior with a bear pelt and an axe. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Young Bear-Kin** · id `young_bear_kin`

> Painterly dark-fantasy trading-card illustration: a young warrior with a bear pelt and a bow. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Clan Wise-Woman** · id `clan_wise_woman`

> Painterly dark-fantasy trading-card illustration: a clan wise-woman with herbs and bone charms. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bulcsú the Blue-Eyed** · id `bulcsu_the_blue_eyed`

> Painterly dark-fantasy trading-card illustration: a tall blue-eyed river chieftain with an axe. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Réka, Shield-Queen** · id `reka_shield_queen`

> Painterly dark-fantasy trading-card illustration: a fierce young shield-queen leading shieldmaidens. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Tisza Clan Warrior** · id `tisza_clan_warrior`

> Painterly dark-fantasy trading-card illustration: a river-clan warrior with an axe and round shield. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Kende Clan Archer** · id `kende_clan_archer`

> Painterly dark-fantasy trading-card illustration: a river-clan archer on a riverbank. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Danube Fire-Raider** · id `danube_fire_raider`

> Painterly dark-fantasy trading-card illustration: a river raider throwing fire from a galley. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Shieldmaiden of Réka** · id `shieldmaiden_of_reka`

> Painterly dark-fantasy trading-card illustration: a shieldmaiden with a painted round shield. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Regös Singer** · id `regos_singer`

> Painterly dark-fantasy trading-card illustration: a regös singer with a drum telling old tales. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Clan Smith of Vasvár** · id `clan_smith_of_vasvar`

> Painterly dark-fantasy trading-card illustration: a clan smith hammering a glowing sword. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Elder Kurszán** · id `elder_kurszan`

> Painterly dark-fantasy trading-card illustration: an old clan elder with a staff. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**River Horn-Blower** · id `river_horn_blower`

> Painterly dark-fantasy trading-card illustration: a bard blowing a horn on a galley prow. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Old Táltos of the Clans** · id `old_taltos_of_the_clans`

> Painterly dark-fantasy trading-card illustration: an old táltos shaman with a drum and mushrooms. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Álmos the Dream-Born** · id `almos_the_dream_born`

> Painterly dark-fantasy trading-card illustration: a young chieftain under a giant eagle dream vision. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Shipwright Holló** · id `shipwright_hollo`

> Painterly dark-fantasy trading-card illustration: a one-handed shipwright with a raven. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Turul Chick** · id `turul_chick`

> Painterly dark-fantasy trading-card illustration: a tiny falcon chick (turul) in a nest. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Light River Boat** · id `light_river_boat`

> Painterly dark-fantasy trading-card illustration: a light river boat with oars on the Danube. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Madman of the Reeds** · id `madman_of_the_reeds`

> Painterly dark-fantasy trading-card illustration: a wild-eyed warrior emerging from reeds. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Kende the Bear-Father** · id `kende_the_bear_father`

> Painterly dark-fantasy trading-card illustration: a huge chieftain who is half bear. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Young Chieftain Taksony** · id `young_chieftain_taksony`

> Painterly dark-fantasy trading-card illustration: a proud young chieftain on a river boat. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Haunted Szabolcs** · id `haunted_szabolcs`

> Painterly dark-fantasy trading-card illustration: a haunted warrior seeing ghosts. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Danube War Galley** · id `danube_war_galley`

> Painterly dark-fantasy trading-card illustration: a war galley with a carved prow on the Danube. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Táltos Brew** · id `taltos_brew`

> Painterly dark-fantasy trading-card illustration: a steaming wooden cup of mushroom brew beside red-capped mushrooms on a mossy stone. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**The Great Turul** · id `the_great_turul`

> Painterly dark-fantasy trading-card illustration: the great mythical turul bird with a sword in its talons. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Bear of the Danube** · id `bear_of_the_danube`

> Painterly dark-fantasy trading-card illustration: a huge bear warrior roaring. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.

**Young Danube Bear** · id `young_danube_bear`

> Painterly dark-fantasy trading-card illustration: a young bear warrior. Setting: the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.
