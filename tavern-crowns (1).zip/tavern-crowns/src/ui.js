// ===================== TAVERN CROWNS UI =====================
const $app = document.getElementById('app');
const FACS = ['CR', 'GE', 'FF', 'NB', 'RC'];
// ---- icons (24x24, original simple glyphs) ----
const P = (d, extra = '') => `<svg viewBox="0 0 24 24" aria-hidden="true" ${extra}>${d}</svg>`;
const S = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
const ICON = {
  close: P(`<path ${S} d="M4 20l3-3M5.5 14.5l4 4M7.5 16.5L19 5V3h-2L5.5 14.5"/>`),
  ranged: P(`<path ${S} d="M6 3c7 2 11 8 11 18M6 3l11 18M4 13l9-4M13 9l-1 3M13 9l-3-1"/>`),
  siege: P(`<path fill="currentColor" d="M5 21V9h2.5V6h2v3h5V6h2v3H19v12h-5v-4a2 2 0 0 0-4 0v4z"/>`),
  spy: P(`<path ${S} d="M2 12s4-6.5 10-6.5S22 12 22 12s-4 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="2.8" fill="currentColor"/>`),
  medic: P(`<path fill="currentColor" d="M9.5 3h5v6.5H21v5h-6.5V21h-5v-6.5H3v-5h6.5z"/>`),
  muster: P(`<g fill="currentColor"><circle cx="6" cy="8" r="2.6"/><circle cx="12" cy="6" r="2.8"/><circle cx="18" cy="8" r="2.6"/><path d="M2 19c0-3.5 2-6 4-6s3 1 3 1-1 2-1 5zM22 19c0-3.5-2-6-4-6s-3 1-3 1 1 2 1 5zM7.5 20c0-4 2-7.5 4.5-7.5s4.5 3.5 4.5 7.5z"/></g>`),
  bond: P(`<g ${S}><circle cx="8.5" cy="12" r="5"/><circle cx="15.5" cy="12" r="5"/></g>`),
  morale: P(`<path ${S} d="M5 12l7-6 7 6M5 19l7-6 7 6"/>`),
  horn: P(`<path fill="currentColor" d="M3 9.5h3.5L19 4v16L6.5 14.5H3zM7 15.5h3l1.5 4.5h-3z"/>`),
  scorch: P(`<path fill="currentColor" d="M12 2c.8 3.6 6 5.8 6 12a6 6 0 0 1-12 0c0-3 1.8-5.1 3-6.2.1 2 .9 3.2 2.1 3.4C10.6 7.8 11.4 5 12 2z"/>`),
  agile: P(`<path ${S} d="M7 20V4M3.5 7.5L7 4l3.5 3.5M17 4v16M13.5 16.5L17 20l3.5-3.5"/>`),
  summon_avenger: P(`<path fill="currentColor" d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7.1L12 17.3 5.8 21l1.6-7.1L2 9.2l7.1-.6z"/>`),
  bearkin: P(`<g fill="currentColor"><ellipse cx="12" cy="15.5" rx="5" ry="4.5"/><circle cx="5" cy="10" r="2.2"/><circle cx="9" cy="6" r="2.2"/><circle cx="15" cy="6" r="2.2"/><circle cx="19" cy="10" r="2.2"/></g>`),
  brew: P(`<path fill="currentColor" d="M2.5 12a9.5 7.5 0 0 1 19 0zM9.5 12.5h5l.8 8.5H8.7z"/>`),
  decoy: P(`<g ${S}><circle cx="12" cy="5" r="2.5"/><path d="M12 7.5V21M4 11h16M8 21l4-4 4 4"/></g>`),
  weather_frost: P(`<path ${S} d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7M9 3.5l3 2.5 3-2.5M9 20.5l3-2.5 3 2.5"/>`),
  weather_fog: P(`<path ${S} d="M3 9h12M6 13h15M3 17h13M17 9h4"/>`),
  weather_rain: P(`<path ${S} d="M5 13a4 4 0 0 1 1-7.8A6 6 0 0 1 17.5 6 3.5 3.5 0 0 1 18 13M8 16l-1.5 4M12 16l-1.5 4M16 16l-1.5 4"/>`),
  weather_storm: P(`<path ${S} d="M5 12a4 4 0 0 1 1-7.8A6 6 0 0 1 17.5 5 3.5 3.5 0 0 1 18 12"/><path fill="currentColor" d="M13 11l-5 7h3.5L10 23l6-8h-3.5z"/>`),
  weather_clear: P(`<g ${S}><circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8"/></g>`),
  hero: P(`<path fill="currentColor" d="M3 18l1.5-10 4.5 4 3-7 3 7 4.5-4L21 18z"/>`),
  crown: P(`<path fill="currentColor" d="M3 18l1.5-10 4.5 4 3-7 3 7 4.5-4L21 18z"/>`),
  cards: P(`<g ${S}><rect x="4" y="5" width="11" height="15" rx="1.5"/><path d="M9 3.5h8.5A1.5 1.5 0 0 1 19 5v12"/></g>`),
};
ICON.scorch_close = ICON.scorch_ranged = ICON.scorch_siege = ICON.scorch;
const SIGIL = {
  CR: `<svg viewBox="0 0 100 100"><path d="M45 4h10v16h16v9H55v12h22v10H55v45H45V51H23V41h22V29H29v-9h16z" fill="currentColor"/></svg>`,
  GE: `<svg viewBox="0 0 100 100"><path d="M50 52Q32 22 4 26q12 8 8 20 14-4 16 8 8-6 14 4l8 34 8-34q6-10 14-4 2-12 16-8-4-12 8-20-28-4-46 26z" fill="currentColor"/><circle cx="38" cy="26" r="6" fill="currentColor"/><circle cx="62" cy="26" r="6" fill="currentColor"/></svg>`,
  FF: `<svg viewBox="0 0 100 100"><path d="M50 8C24 30 22 66 50 92 78 66 76 30 50 8z" fill="none" stroke="currentColor" stroke-width="6"/><path d="M50 18V88M50 40L34 30M50 56L30 46M50 40L66 30M50 56L70 46" stroke="currentColor" stroke-width="5" fill="none"/></svg>`,
  NB: `<svg viewBox="0 0 100 100"><path d="M22 12Q40 50 18 90M48 6Q66 48 46 94M74 12Q92 50 70 90" fill="none" stroke="currentColor" stroke-width="9" stroke-linecap="round"/></svg>`,
  RC: `<svg viewBox="0 0 100 100"><path d="M10 62Q30 50 50 62T90 62M10 80Q30 68 50 80T90 80" fill="none" stroke="currentColor" stroke-width="6"/><path d="M50 8V56M50 12C70 14 78 30 76 44H50z" fill="currentColor"/></svg>`,
  NE: `<svg viewBox="0 0 100 100"><path d="M50 4L58 42 96 50 58 58 50 96 42 58 4 50 42 42z" fill="currentColor"/><circle cx="50" cy="50" r="28" fill="none" stroke="currentColor" stroke-width="4"/></svg>`,
};

// ---- texts ----
const AB = {
  bond: ['Brotherhood', 'Placed next to cards with the same name, each one\'s strength is multiplied by the number of copies in the row (2 → ×2, 3 → ×3).'],
  muster: ['Muster', 'When played, every card of the same company in your deck joins the battle at once.'],
  morale: ['Rally', '+1 strength to every other unit in its row (not itself).'],
  medic: ['Healer', 'Choose a non-legend unit from your discard pile and play it instantly.'],
  spy: ['Spy', 'Placed on your opponent\'s side (adds to their score); you draw 2 cards.'],
  agile: ['Agile', 'Can be placed in the Close Combat or Ranged row; it cannot move afterwards.'],
  horn: ['War Horn', 'Doubles the strength of all non-legend units in the row. Only one horn per row counts; a horn-bearer does not double itself.'],
  scorch: ['Wildfire', 'Destroys the strongest non-legend unit(s) on the whole battlefield, including your own.'],
  scorch_close: ['Wildfire: Close Combat', 'If the enemy Close Combat row totals 10 or more, destroys the strongest unit(s) there.'],
  scorch_ranged: ['Wildfire: Ranged', 'If the enemy Ranged row totals 10 or more, destroys the strongest unit(s) there.'],
  scorch_siege: ['Wildfire: Siege', 'If the enemy Siege row totals 10 or more, destroys the strongest unit(s) there.'],
  summon_avenger: ['Avenger', 'When removed from the battlefield, a mighty unit takes its place.'],
  bearkin: ['Bear-Kin', 'Turns into a bear when Táltos Brew touches its row.'],
  brew: ['Táltos Brew', 'Transforms every Bear-Kin in the row, including ones placed there later.'],
  decoy: ['Scarecrow', 'Swap with a non-legend unit on your side of the battlefield to return it to your hand.'],
  weather_frost: ['Carpathian Frost', 'Sets every non-legend Close Combat unit on both sides to 1.'],
  weather_fog: ['Ecsed Marsh Fog', 'Sets every non-legend Ranged unit on both sides to 1.'],
  weather_rain: ['Danube Deluge', 'Sets every non-legend Siege unit on both sides to 1.'],
  weather_storm: ['Balaton Squall', 'Sets every non-legend Ranged and Siege unit on both sides to 1.'],
  weather_clear: ['Clear Puszta Sky', 'Removes all weather effects.'],
};
const AVENGER_TXT = { turul_chick: 'The Great Turul (11, legend) appears.', grey_cattle: 'Bull of the Puszta (8) appears.' };
const LEAD_TXT = {
  play_fog_from_deck: 'Play an Ecsed Marsh Fog from your deck instantly.',
  clear_weather: 'Clear all weather effects.',
  horn_siege: 'Doubles your Siege row (unless a War Horn is already there).',
  scorch_siege: 'Destroy the enemy\'s strongest Siege unit(s) if their Siege row totals 10 or more.',
  scorch_ranged: 'Destroy the enemy\'s strongest Ranged unit(s) if their Ranged row totals 10 or more.',
  play_rain_from_deck: 'Play a Danube Deluge from your deck instantly.',
  view_3_opponent_hand: 'Look at 3 random cards in your opponent\'s hand.',
  cancel_enemy_leader: 'Passive: your opponent\'s leader ability is cancelled.',
  take_from_enemy_discard: 'Take any card from your opponent\'s discard pile into your hand.',
  random_medic: 'Passive: every Healer revives a random unit (affects both players).',
  horn_close: 'Doubles your Close Combat row (unless a War Horn is already there).',
  discard_to_hand: 'Return a card from your discard pile to your hand.',
  discard2_pick1: 'Discard 2 cards, then choose any 1 card from your deck.',
  play_any_weather_from_deck: 'Play any weather card from your deck instantly.',
  double_spies: 'Passive: every Spy has double strength (affects both players).',
  scorch_close: 'Destroy the enemy\'s strongest Close Combat unit(s) if their Close Combat row totals 10 or more.',
  horn_ranged: 'Doubles your Ranged row (unless a War Horn is already there).',
  extra_card_start: 'Passive: draw an extra card at the start of the battle (11).',
  play_frost_from_deck: 'Play a Carpathian Frost from your deck instantly.',
  optimize_agile: 'Move your Agile units to whichever row makes them strongest.',
  shuffle_graveyards_into_decks: 'Shuffle both discard piles back into their owners\' decks.',
  weather_halves: 'Passive: bad weather only halves your units instead of setting them to 1.',
};
const PASSIVE = ['cancel_enemy_leader', 'random_medic', 'double_spies', 'extra_card_start', 'weather_halves'];
const SET_NAME = { core: 'Core Set', mirror: 'Mirror & Smoke', river: 'River Crowns' };
const LEVEL_NAME = { easy: 'Easy', medium: 'Medium', hard: 'Hard' };
const leaderTitle = L => `${L.n}, ${L.ti}`;
const FAC_ABIL = {};
const FAC_STYLE = { CR: 'Card advantage, siege engines, Brotherhood', GE: 'Spies, healers, court intrigue', FF: 'Agile archers, Muster, flexibility', NB: 'Swarms of folk-tale monsters', RC: 'Bear-Kin, galleys, a mighty third round' };
const FAC_EDGE = { CR: 'Draw a card from your deck whenever you win a round.', GE: 'Win any round that ends in a draw.', FF: 'You decide who takes the first turn.', NB: 'After each round, one random unit stays on the battlefield.', RC: 'At the start of round 3, two random units return from your discard pile to the battlefield.' };
Object.assign(FAC_ABIL, FAC_EDGE);
const ROW_NAME = { close: 'Close Combat', ranged: 'Ranged', siege: 'Siege', agile: 'Close or Ranged (Agile)', special: 'Special', weather: 'Weather' };
const FAC_PROMPT = {
  CR: '12th–13th century Kingdom of Hungary, Romanesque stone castles, red-and-silver Árpád stripes on shields and banners, the patriarchal double cross',
  GE: '12th-century Byzantine court, purple silk and gold mosaics, domed churches, lamellar armour, double-headed eagle banners',
  FF: 'ancient Bakony beech forests, fairy light, folk embroidery patterns, mossy ruins',
  NB: 'Hungarian folk-tale horror, marsh mist, moonlight, twisted willows',
  RC: 'the Danube and Tisza rivers, reeds, carved river galleys, bear pelts, 10th-century steppe clan gear',
  NE: 'medieval Central Europe, 12th–14th century',
};
function artPrompt(d, leader) {
  return `Painterly dark-fantasy trading-card illustration: ${d.p}. Setting: ${FAC_PROMPT[d.f] || FAC_PROMPT.NE}. Dramatic rim lighting, rich colours, detailed brushwork. Portrait orientation 5:7, main subject in the upper two thirds, lower third calm background. No text, no letters, no border, no frame.`;
}

// ---- helpers ----
const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

// ---- card art sources: uploaded (this browser) > art/ folder > generated fallback ----
const ARTSRC = { files: {}, custom: {} };
function artOf(key, fallback) { return ARTSRC.custom[key] || ARTSRC.files[key] || (typeof PORTRAITS !== 'undefined' && PORTRAITS[key] ? { pt: PORTRAITS[key], full: false } : { url: fallback(), full: false, gen: true }); }
const cardArt = d => artOf(d.id, () => ART.card(d));
const leaderArt = L => artOf(L.id, () => ART.leader(L));
function artLayers(d, art) {
  if (art.pt) return `<div class="art"><img class="bg" src="${ART.scene(d)}" alt="" draggable="false"><img class="pt" src="${art.pt}" alt="" draggable="false" loading="lazy"></div>`;
  return `<div class="art"><img class="bg cover" src="${art.url}" alt="" draggable="false" loading="lazy"></div>`;
}
const IDB = {
  db: null,
  open() { return new Promise(res => { try { const r = indexedDB.open('tavern_crowns', 1); r.onupgradeneeded = () => r.result.createObjectStore('art'); r.onsuccess = () => { IDB.db = r.result; res(true); }; r.onerror = () => res(false); } catch (e) { res(false); } }); },
  all() { return new Promise(res => { if (!IDB.db) return res([]); try { const out = []; const tx = IDB.db.transaction('art'); const st = tx.objectStore('art'); st.openCursor().onsuccess = e => { const c = e.target.result; if (c) { out.push([c.key, c.value]); c.continue(); } else res(out); }; tx.onerror = () => res(out); } catch (e) { res([]); } }); },
  put(k, v) { return new Promise(res => { if (!IDB.db) return res(false); try { const tx = IDB.db.transaction('art', 'readwrite'); tx.objectStore('art').put(v, k); tx.oncomplete = () => res(true); tx.onerror = () => res(false); } catch (e) { res(false); } }); },
  del(k) { return new Promise(res => { if (!IDB.db) return res(false); try { const tx = IDB.db.transaction('art', 'readwrite'); if (k == null) tx.objectStore('art').clear(); else tx.objectStore('art').delete(k); tx.oncomplete = () => res(true); tx.onerror = () => res(false); } catch (e) { res(false); } }); },
};
async function loadArt() {
  try { const r = await fetch('art/manifest.json', { cache: 'no-cache' }); if (r.ok) { const m = await r.json(); Object.entries(m.cards || {}).forEach(([k, v]) => { const f = typeof v === 'string' ? { file: v } : v; ARTSRC.files[k] = { url: 'art/' + f.file, full: !!f.full || /_full\.\w+$/.test(f.file) }; }); } } catch (e) { }
  if (await IDB.open()) (await IDB.all()).forEach(([k, v]) => { if (v && v.blob) ARTSRC.custom[k] = { url: URL.createObjectURL(v.blob), full: !!v.full }; });
  render();
}
function shrink(file, maxW = 600) {
  return new Promise((res, rej) => {
    const img = new Image(); const u = URL.createObjectURL(file);
    img.onload = () => { const sc = Math.min(1, maxW / img.width); const c = document.createElement('canvas'); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); c.toBlob(b => b ? res(b) : rej(new Error('encode')), 'image/webp', .9); };
    img.onerror = () => rej(new Error('That file is not an image this browser can read.')); img.src = u;
  });
}
async function saveCustom(key, file, full) {
  const blob = await shrink(file); await IDB.put(key, { blob, full });
  if (ARTSRC.custom[key]) URL.revokeObjectURL(ARTSRC.custom[key].url);
  ARTSRC.custom[key] = { url: URL.createObjectURL(blob), full };
}
const keyOf = s => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\.[a-z0-9]+$/, '').replace(/_full$/, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
function matchFile(name) {
  const k = keyOf(name);
  const c = CARD_DATA.find(d => d.id === k || keyOf(d.n) === k); if (c) return c.id;
  const l = LEADER_DATA.find(d => d.id === k || keyOf(d.n + ' ' + d.ti) === k); return l ? l.id : null;
}

const CHIP_LABEL = { spy: 'Spy', medic: 'Healer', bond: 'Brotherhood', muster: 'Muster', morale: 'Rally', horn: 'War Horn', scorch: 'Wildfire', scorch_close: 'Wildfire', scorch_ranged: 'Wildfire', scorch_siege: 'Wildfire', agile: 'Agile', summon_avenger: 'Avenger', bearkin: 'Bear-Kin', brew: 'Táltos Brew', decoy: 'Scarecrow' };
function cardType(d) { return d.r === 'weather' ? 'weather' : d.r === 'special' ? 'special' : d.h ? 'legend' : 'unit'; }
function cardHTML(d, o = {}) {
  const isU = isUnit(d); const art = cardArt(d); const ty = cardType(d);
  const cls = ['card', 't-' + ty, art.full ? 'full' : '', o.cls || ''].join(' ');
  let strHTML;
  if (isU) { const s = o.str != null ? o.str : d.s; strHTML = `<div class="str ${s > d.s ? 'up' : s < d.s ? 'down' : ''}"><span>${s}</span>${d.h ? `<i class="crownmark">${ICON.crown}</i>` : ''}</div>`; }
  else strHTML = `<div class="str sp"><span>${ICON[d.a[0]] || ''}</span></div>`;
  const chips = [];
  if (isU) { chips.push(`<i class="ch ch-row" title="${ROW_NAME[d.r]}">${d.r === 'agile' ? ICON.agile : ICON[d.r]}</i>`); d.a.filter(a => ICON[a] && a !== 'agile').slice(0, 2).forEach(a => chips.push(`<i class="ch ab-${a}" title="${CHIP_LABEL[a] || a}">${ICON[a]}<em>${CHIP_LABEL[a] || ''}</em></i>`)); }
  const sub = isU ? (d.a.filter(a => AB[a]).map(a => AB[a][0]).join(' · ') || (d.h ? 'Legend' : ROW_NAME[d.r])) : (AB[d.a[0]] ? AB[d.a[0]][1] : 'Special');
  const tag = ty === 'unit' ? '' : `<span class="ttag">${ty === 'legend' ? 'Legend' : ty === 'weather' ? 'Weather' : 'Special'}</span>`;
  const attrs = `${o.u != null ? `data-u="${o.u}"` : ''} data-id="${d.id}" ${o.act ? `data-act="${o.act}"` : ''} ${o.extra || ''}`;
  return `<div class="${cls}" style="--fc:var(--${d.f});--rib:var(--rib-${d.f});${o.style || ''}" ${attrs} title="${esc(d.n)}">${artLayers(d, art)}<div class="frame"></div>${tag}${strHTML}<div class="chips">${chips.join('')}</div><div class="plate"><b>${esc(d.n)}</b><span>${esc(sub)}</span></div>${o.cnt ? `<span class="cnt">×${o.cnt}</span>` : ''}</div>`;
}
function leaderCardHTML(L, o = {}) {
  const art = leaderArt(L);
  return `<div class="card t-leader ${art.full ? 'full' : ''} ${o.cls || ''}" style="--fc:var(--${L.f});--rib:var(--rib-${L.f})" ${o.act ? `data-act="${o.act}"` : ''} data-leader="${L.id}" title="${esc(leaderTitle(L))}">${artLayers(L, art)}<div class="frame"></div><span class="ttag">Leader</span><div class="str sp lead"><span>${ICON.crown}</span></div><div class="plate"><b>${esc(L.n)}</b><span>${esc(L.ti)}</span></div></div>`;
}
function describeCard(d) {
  const out = [];
  if (d.h) out.push(['hero', 'Legend', 'Untouched by special cards, abilities and weather. Cannot be targeted by Scarecrow, Healer or Wildfire.']);
  d.a.forEach(a => {
    const t = AB[a]; if (!t) return; let desc = t[1];
    if (a === 'summon_avenger') desc += ' ' + (AVENGER_TXT[d.id] || '');
    if (a === 'bearkin') desc = d.id === 'bear_kin_warrior' ? 'Táltos Brew turns it into the Bear of the Danube (14, Close Combat, Rally).' : 'Táltos Brew turns it into a Young Danube Bear (8, Ranged, Brotherhood).';
    if (a === 'muster' && d.id === 'reka_shield_queen') desc = 'When played, every Shieldmaiden of Réka in your deck joins the battle.';
    if (a === 'brew' && isUnit(d)) desc = 'When played, transforms every Bear-Kin in his own row.';
    out.push([a, t[0], desc]);
  });
  return out;
}
function previewHTML(d, extra = '') {
  if (!d) return `<div class="hint">Hover over or tap a card to read it.</div>`;
  const abil = describeCard(d).map(x => `<div class="ab"><i>${ICON[x[0]] || ICON.hero}</i><div><b>${x[1]}.</b> ${x[2]}</div></div>`).join('');
  return `${cardHTML(d, { cls: 'big' })}<div class="txt"><h3>${esc(d.n)}</h3><div><span class="tag">${FACTION_NAME[d.f]}</span><span class="tag">${ROW_NAME[d.r]}</span>${isUnit(d) ? `<span class="tag">Strength ${d.s}</span>` : ''}</div>${abil || (isUnit(d) ? '<div class="muted">No special ability.</div>' : '')}${extra}</div>`;
}
function leaderPreviewHTML(L, extra = '') {
  return `${leaderCardHTML(L, { cls: 'big' })}<div class="txt"><h3>${esc(leaderTitle(L))}</h3><div><span class="tag">${FACTION_NAME[L.f]}</span><span class="tag">Leader</span>${PASSIVE.includes(L.k) ? '<span class="tag">Passive</span>' : '<span class="tag">Once per match</span>'}</div><div>${LEAD_TXT[L.k]}</div>${extra}</div>`;
}

// ---- persistence ----
const STORE = 'tavern_crowns_decks_v1';
const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { } } };
function loadDecks() {
  let saved = {}; try { saved = JSON.parse(ls.get(STORE) || '{}') || {}; } catch (e) { saved = {}; }
  const out = {}; FACS.forEach(f => { const s = saved[f]; out[f] = s && Array.isArray(s.ids) && s.ids.every(id => DEF[id]) && LDEF[s.leader] ? s : { leader: defaultLeader(f), ids: defaultDeck(f) }; });
  return out;
}
function saveDecks() { ls.set(STORE, JSON.stringify(UI.decks)); }

// ---- global UI state ----
const UI = { music: ls.get('tc_music') !== '0', level: ['easy', 'medium', 'hard'].includes(ls.get('tc_level')) ? ls.get('tc_level') : 'medium', screen: 'menu', decks: loadDecks(), myFac: FACS.includes(ls.get('tc_fac')) ? ls.get('tc_fac') : 'CR', oppFac: 'random', bf: 'CR', bfilter: 'all', bprev: null, bfull: false, artMsg: '', st: null, sel: null, prev: null, passArm: false, aiTimer: null, lastHist: 0, seenFx: 0, newU: new Set(), overlay: null };
UI.bf = UI.myFac;
function musicBtn() { const on = MUSIC.playing; return `<span class="musicbar"><button class="btn" data-act="music" aria-pressed="${on}" title="${on && MUSIC.track ? esc(MUSIC.track.title + ' by ' + MUSIC.track.by) : 'Music'}">${on ? '♪ Music on' : '♪ Music off'}</button><input type="range" id="vol" min="0" max="1" step="0.05" value="${MUSIC.volume}" aria-label="Music volume"></span>`; }
// music starts in the menu; browsers only allow sound after the first click or key press, so it also (re)starts then
if (UI.music) MUSIC.start();
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, function kick() { if (UI.music) MUSIC.start(); document.removeEventListener('pointerdown', kick); document.removeEventListener('keydown', kick); }, { once: true }));

function go(screen) { UI.screen = screen; UI.overlay = null; clearTimeout(UI.aiTimer); if (screen !== 'game') MUSIC.setMode('menu'); render(); window.scrollTo(0, 0); }
function render() {
  if (UI.screen === 'menu') $app.innerHTML = menuHTML();
  else if (UI.screen === 'setup') $app.innerHTML = setupHTML();
  else if (UI.screen === 'builder') $app.innerHTML = builderHTML();
  else if (UI.screen === 'rules') $app.innerHTML = rulesHTML();
  else if (UI.screen === 'game') { $app.innerHTML = gameHTML(); fitAll(); const lg = $app.querySelector('.log'); if (lg) lg.scrollTop = lg.scrollHeight; }
}

// ---------- MENU ----------
function menuHTML() {
  const fan = ['arpad_stripe_guard', 'varangian_guard', 'miklos_toldi', 'the_seven_headed_dragon', 'reka_shield_queen'].map((id, k) => cardHTML(DEF[id], { cls: 'mid', style: `transform:translateX(${(k - 2) * 92}px) translateY(${Math.abs(k - 2) * 14}px) rotate(${(k - 2) * 8}deg);z-index:${5 - Math.abs(k - 2)}` })).join('');
  return `<div class="screen" id="menu"><div class="menu-inner">
  <div class="fan" aria-hidden="true">${fan}</div>
  <div class="title-block"><div class="eyebrow">A tavern card game of crowns, castles and folk-tale monsters</div><h1>Tavern Crowns</h1>
  <p>Three rounds, two victories, ten cards in your hand. Raise the Árpád banners, bribe the Golden Basileia, call the fairies of the Bakony, the Night Brood of the marshes or the river clans of the Danube against an opponent who knows exactly when to pass.</p></div>
  <div class="menu-grid">
   <button class="menu-tile" data-act="go-setup"><b>Play</b><span>Choose a faction and sit down across the table.</span></button>
   <button class="menu-tile" data-act="go-builder"><b>Deck Builder</b><span>Leaders, cards and card art. At least 22 units, at most 10 specials.</span></button>
   <button class="menu-tile" data-act="go-rules"><b>Rulebook</b><span>Rules, factions, leaders, the full card list and the history behind it.</span></button>
  </div>
  <div class="menu-foot">${musicBtn()}<span class="muted">${MUSIC.track ? 'Now playing: ' + esc(MUSIC.track.title) + ' · ' + esc(MUSIC.track.by) : 'Music from The Battle for Wesnoth, freely licensed.'}</span><button class="linkbtn" data-act="go-credits">Credits</button></div>
  </div></div>`;
}

// ---------- SETUP ----------
function facTile(f, sel, act, sub) {
  return `<button class="fac ${sel ? 'sel' : ''}" style="--fc:var(--${f})" data-act="${act}" data-f="${f}"><b>${FACTION_NAME[f]}</b><small>${FAC_ABIL[f]}</small>${sub || ''}</button>`;
}
function setupHTML() {
  const mine = FACS.map(f => { const d = UI.decks[f]; const s = deckStats(d.ids); const ok = deckValid(d.ids); return facTile(f, UI.myFac === f, 'my-fac', `<span class="ok" style="color:${ok ? 'var(--good)' : 'var(--blood)'}">${s.units} units · ${s.specials} specials${ok ? '' : ' (invalid)'}</span><small>Leader: ${esc(leaderTitle(LDEF[d.leader]))}</small>`); }).join('');
  const opp = [`<button class="fac ${UI.oppFac === 'random' ? 'sel' : ''}" style="--fc:var(--brass)" data-act="opp-fac" data-f="random"><b>Random</b><small>A surprise opponent with a random leader.</small></button>`].concat(FACS.map(f => facTile(f, UI.oppFac === f, 'opp-fac', `<small>${FAC_STYLE[f]}</small>`))).join('');
  const valid = deckValid(UI.decks[UI.myFac].ids);
  const lv = [['easy', 'Easy', 'Makes mistakes, passes early and spends cards freely.'], ['medium', 'Medium', 'Passes on purpose, uses spies and plays for card advantage.'], ['hard', 'Hard', 'A tuned deck and its faction\'s best leader. Careful around Wildfire, rarely blunders.']];
  return `<div class="screen"><div class="wrap">
  <div class="topbar"><button class="btn" data-act="go-menu">← Menu</button><h2>New match</h2><button class="btn" data-act="go-builder">Deck Builder</button><button class="btn primary" data-act="start" ${valid ? '' : 'disabled'}>Take a seat</button></div>
  <div class="eyebrow">Your faction</div><div class="fac-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">${mine}</div>
  <div class="eyebrow">Opponent</div><div class="fac-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">${opp}</div>
  <div class="eyebrow">Difficulty</div><div class="lvl-grid">${lv.map(([k, t, d]) => `<button class="fac ${UI.level === k ? 'sel' : ''}" style="--fc:var(--${k === 'easy' ? 'FF' : k === 'medium' ? 'NE' : 'NB'})" data-act="lvl" data-k="${k}"><b>${t}</b><small>${d}</small></button>`).join('')}</div>
  <div class="panel music-row"><div><b>Music</b><span class="muted">Orchestral and tavern tracks from The Battle for Wesnoth (GPL / CC BY-SA). Calmer tunes in the menu, battle themes at the table, an epic one for the deciding round.</span></div>${musicBtn()}</div>
  ${valid ? '' : '<div style="color:var(--blood)">This deck is not valid yet. Open the Deck Builder to fix it.</div>'}
  </div></div>`;
}

// ---------- BUILDER ----------
function builderHTML() {
  const f = UI.bf, D = UI.decks[f]; const st = deckStats(D.ids);
  const counts = {}; D.ids.forEach(id => counts[id] = (counts[id] || 0) + 1);
  const filt = d => { switch (UI.bfilter) { case 'close': return d.r === 'close' || d.r === 'agile'; case 'ranged': return d.r === 'ranged' || d.r === 'agile'; case 'siege': return d.r === 'siege'; case 'hero': return d.h; case 'special': return !isUnit(d); case 'faction': return d.f === f; case 'neutral': return d.f === 'NE'; default: return true; } };
  const sortF = (a, b) => (isUnit(a) - isUnit(b)) || ((b.h || 0) - (a.h || 0)) || (b.s - a.s) || a.n.localeCompare(b.n);
  const coll = collection(f).filter(filt).sort(sortF).filter(d => d.c - (counts[d.id] || 0) > 0).map(d => cardHTML(d, { act: 'b-add', cnt: d.c - (counts[d.id] || 0) })).join('') || '<div class="muted">Every card of this kind is already in your deck.</div>';
  const deck = Object.keys(counts).map(id => DEF[id]).filter(filt).sort(sortF).map(d => cardHTML(d, { act: 'b-rem', cnt: counts[d.id] })).join('') || '<div class="muted">Click cards in your collection to add them.</div>';
  const leaders = LEADER_DATA.filter(l => l.f === f).map(L => `<button class="leader-opt ${D.leader === L.id ? 'sel' : ''}" data-act="b-leader" data-l="${L.id}">${leaderCardHTML(L)}<span><b>${esc(L.n)}</b><small class="lt">${esc(L.ti)}</small><small>${LEAD_TXT[L.k]}</small></span></button>`).join('');
  const tabs = FACS.map(x => `<button class="chip ${x === f ? 'on' : ''}" data-act="b-fac" data-f="${x}">${FACTION_NAME[x]}</button>`).join('');
  const fl = [['all', 'All'], ['faction', 'Faction'], ['neutral', 'Neutral'], ['close', 'Close'], ['ranged', 'Ranged'], ['siege', 'Siege'], ['hero', 'Legends'], ['special', 'Specials']].map(([k, t]) => `<button class="chip ${UI.bfilter === k ? 'on' : ''}" data-act="b-filter" data-k="${k}">${t}</button>`).join('');
  const nCustom = Object.keys(ARTSRC.custom).length, nFiles = Object.keys(ARTSRC.files).length;
  return `<div class="screen"><div class="wrap">
  <div class="topbar"><button class="btn" data-act="go-menu">← Menu</button><h2>Deck Builder</h2><button class="btn" data-act="b-default">Restore starter deck</button><button class="btn" data-act="b-clear">Empty deck</button><button class="btn primary" data-act="go-setup">Continue to match</button></div>
  <div class="chips">${tabs}</div>
  <div class="panel" style="display:grid;gap:10px"><div class="eyebrow">Leader · faction edge: ${FAC_ABIL[f]}</div><div class="leaders">${leaders}</div></div>
  <div class="panel bstats">
   <div class="bstat ${st.units >= 22 ? 'good' : 'bad'}"><span class="eyebrow">Units</span><b>${st.units} / 22+</b></div>
   <div class="bstat ${st.specials <= 10 ? 'good' : 'bad'}"><span class="eyebrow">Specials</span><b>${st.specials} / 10</b></div>
   <div class="bstat"><span class="eyebrow">Cards</span><b>${st.total}</b></div>
   <div class="bstat"><span class="eyebrow">Unit strength</span><b>${st.str}</b></div>
   <div class="bstat"><span class="eyebrow">Legends</span><b>${st.heroes}</b></div>
   <span class="muted" style="flex:1;min-width:200px;font-size:13px">Your deck saves automatically in this browser. A smaller deck draws your best cards more often.</span>
  </div>
  <details class="panel artpanel"><summary><b>Card art</b> <span class="muted">${Object.keys(typeof PORTRAITS !== 'undefined' ? PORTRAITS : {}).length} painted portraits · ${nFiles} from your art folder · ${nCustom} uploaded in this browser</span></summary>
   <div class="artgrid">
    <div><p>Every card already has a painted portrait. To replace one with your own art, generate a picture with the card's ready-made prompt, then upload it here, one card at a time from the card preview below, or many at once. For a bulk upload, name each file after the card, for example <code>miklos_toldi.png</code> or <code>Miklós Toldi.png</code>. Uploaded images stay in this browser only.</p>
    <p class="muted">To ship art with the game on GitHub, put the files in the <code>art/</code> folder and list them in <code>art/manifest.json</code>.</p></div>
    <div class="artbtns"><label class="btn primary">Upload images…<input type="file" id="bulk-art" accept="image/*" multiple class="vh"></label>
     <label class="chk"><input type="checkbox" id="bulk-full" ${UI.bfull ? 'checked' : ''}> The images are complete cards with their own frame</label>
     <button class="btn" data-act="copy-prompts">Copy all prompts</button>
     <button class="btn" data-act="art-clear" ${nCustom ? '' : 'disabled'}>Remove uploaded art</button>
     ${UI.artMsg ? `<div class="artmsg">${esc(UI.artMsg)}</div>` : ''}</div>
   </div></details>
  <div class="chips">${fl}</div>
  <div class="panel" id="bprev">${UI.bprev ? builderPrev(UI.bprev) : '<div class="muted">Hover over a card to read it and manage its art. Click a card to add it to your deck or remove it.</div>'}</div>
  <div class="bcols"><div class="panel" style="display:grid;gap:10px;align-content:start"><div class="eyebrow">Collection (click to add)</div><div class="bgrid">${coll}</div></div>
  <div class="panel" style="display:grid;gap:10px;align-content:start"><div class="eyebrow">Your deck (click to remove)</div><div class="bgrid">${deck}</div></div></div>
  </div></div>`;
}
function builderPrev(key) {
  const L = LDEF[key]; const d = DEF[key]; if (!d && !L) return '';
  const src = L ? leaderArt(L) : cardArt(d);
  const head = L ? `${leaderCardHTML(L, { cls: 'mid' })}<div class="bp-txt"><h3>${esc(leaderTitle(L))}</h3><div class="muted">${FACTION_NAME[L.f]} · Leader · ${SET_NAME[L.d]}</div><div>${LEAD_TXT[L.k]}</div>`
    : `${cardHTML(d, { cls: 'mid' })}<div class="bp-txt"><h3>${esc(d.n)}</h3><div class="muted">${FACTION_NAME[d.f]} · ${ROW_NAME[d.r]}${isUnit(d) ? ' · Strength ' + d.s : ''} · ${SET_NAME[d.d]}</div>${describeCard(d).map(x => `<div class="ab"><i>${ICON[x[0]] || ''}</i><div><b>${x[1]}.</b> ${x[2]}</div></div>`).join('') || '<div class="muted">No special ability.</div>'}`;
  const prompt = artPrompt(L || d);
  return `<div class="bp">${head}
   <div class="promptbox"><div class="eyebrow">Image prompt</div><p>${esc(prompt)}</p>
   <div class="artbtns"><button class="btn" data-act="copy-prompt" data-k="${key}">Copy prompt</button><label class="btn">Upload art…<input type="file" class="one-art vh" data-k="${key}" accept="image/*"></label><label class="chk"><input type="checkbox" id="one-full" ${UI.bfull ? 'checked' : ''}> Complete card with its own frame</label>${ARTSRC.custom[key] ? `<button class="btn" data-act="art-del" data-k="${key}">Remove uploaded art</button>` : ''}<span class="muted">${ARTSRC.custom[key] ? 'Using your uploaded image.' : src.pt ? 'Using the painted portrait (The Battle for Wesnoth).' : src.gen ? 'Using generated art.' : 'Using the art file from your art folder.'}</span></div></div></div></div>`;
}

// ---------- GAME ----------
function startGame() {
  const f = UI.myFac; const D = UI.decks[f];
  const of = UI.oppFac === 'random' ? FACS[rnd(5)] : UI.oppFac;
  const lsd = LEADER_DATA.filter(l => l.f === of); const lvl = UI.level; const ol = lvl === 'hard' ? STRONG_LEADER[of] : lsd[rnd(lsd.length)].id;
  ls.set('tc_level', lvl); ls.set('tc_fac', f);
  UI.st = newGame({ players: [{ name: 'You', faction: f, leader: D.leader, deck: D.ids.slice(), ai: false }, { name: 'Opponent', faction: of, leader: ol, deck: lvl === 'hard' ? strongDeck(of) : defaultDeck(of), ai: true }] });
  UI.st.level = [null, lvl];
  UI.sel = null; UI.prev = null; UI.lastHist = 0; UI.seenFx = 0; UI.overlay = { kind: 'mulligan' };
  AI.mulligan(UI.st, 1, lvl);
  MUSIC.setMode('game'); if (UI.music) MUSIC.start();
  UI.screen = 'game'; render();
}
function afterMulligan() {
  const st = UI.st; const a = st.p[0].faction === 'FF', b = st.p[1].faction === 'FF';
  if (a && !b) { UI.overlay = { kind: 'first' }; return render(); }
  let first = rnd(2); let why = 'A coin toss decided.';
  if (b && !a) { first = 0; why = 'The Free Folk opponent lets you move first.'; }
  beginPlay(first, why);
}
function beginPlay(first, why) { UI.overlay = null; startPlay(UI.st, first); banner(first === 0 ? 'You go first' : 'Your opponent goes first', why); step(); }
function banner(title, sub) { const b = document.createElement('div'); b.className = 'banner'; b.innerHTML = `<b>${esc(title)}</b><span>${esc(sub || '')}</span>`; document.body.appendChild(b); setTimeout(() => b.remove(), 1850); }
function step() {
  const st = UI.st; if (!st) return;
  for (; UI.seenFx < st.fx.length; UI.seenFx++) { const e = st.fx[UI.seenFx]; if (e.kind === 'place') UI.newU.add(e.u); }
  if (st.history.length > UI.lastHist) {
    const h = st.history[st.history.length - 1]; UI.lastHist = st.history.length;
    if (!st.over && st.round === 3) MUSIC.setMode('final');
    if (st.over) MUSIC.sting(st.winner === 0 ? 'victory' : 'defeat');
    if (!st.over) banner(h.winner === 0 ? 'You won the round!' : h.winner === 1 ? 'Your opponent won the round' : 'The round is a draw', `${h.scores[0]} – ${h.scores[1]}`);
    else setTimeout(() => { UI.overlay = { kind: 'over' }; render(); }, 1300);
  }
  if (st.pending && st.pending.player === 0) UI.overlay = { kind: 'pending' };
  render(); UI.newU.clear();
  clearTimeout(UI.aiTimer);
  if (!st.over && st.phase === 'play' && st.turn === 1 && !st.pending) UI.aiTimer = setTimeout(aiMove, 900);
}
function aiMove() { const st = UI.st; if (!st || st.over || st.turn !== 1 || UI.screen !== 'game') return; runAction(st, 1, AI.decide(st, 1)); step(); }
function humanAct(act) { const st = UI.st; if (!canAct(st, 0)) return; UI.sel = null; UI.passArm = false; runAction(st, 0, act, () => { }); step(); }
function selectedCard() { const st = UI.st; return UI.sel != null ? st.p[0].hand.find(c => c.u === UI.sel) : null; }

function pinfoHTML(i) {
  const st = UI.st, Pp = st.p[i], L = LDEF[Pp.leader]; const sc = score(st, i), so = score(st, 1 - i);
  const usable = i === 0 && canAct(st, 0) && leaderUsable(st, 0);
  const lcls = (Pp.leaderUsed || Pp.leaderDisabled) ? 'used' : (usable ? 'ready' : '');
  const gems = [0, 1].map(k => `<span class="gem ${k < Pp.lives ? '' : 'off'}"></span>`).join('');
  return `<div class="pinfo ${st.turn === i && st.phase === 'play' && !st.over ? 'turn' : ''}"><div class="lead">${leaderCardHTML(L, { cls: lcls, act: 'leader-' + i })}</div>
   <div class="who"><b>${i === 0 ? 'You' : 'Opponent'}</b><small>${FACTION_NAME[Pp.faction]}${i === 1 && st.level ? ' · ' + LEVEL_NAME[st.level[1]] : ''}</small></div>
   <div class="meta"><span class="gems" title="Lives">${gems}</span><span class="handct" title="Cards in hand">${ICON.cards.replace('<svg', '<svg width="16" height="16"')} ${Pp.hand.length}</span>${Pp.passed ? '<span class="passed-tag">Passed</span>' : ''}<span class="total ${sc > so ? 'lead' : ''}">${sc}</span></div></div>`;
}
function rowHTML(i, r) {
  const st = UI.st, Pp = st.p[i]; const sel = selectedCard(); const sd = sel ? def(sel) : null;
  let drop = false, hdrop = false;
  if (sel && canAct(st, 0)) {
    const rows = legalRows(st, 0, sel);
    if (sd.a.includes('spy')) drop = i === 1 && rows.includes(r);
    else if (sd.r === 'special' && (sd.a.includes('horn') || sd.a.includes('brew'))) { drop = i === 0 && rows.includes(r); hdrop = drop; }
    else drop = i === 0 && rows.includes(r);
  }
  const decoyMode = sel && sd.a.includes('decoy') && canAct(st, 0);
  const cards = Pp.rows[r].map(c => { const d = def(c); const tgt = decoyMode && i === 0 && !d.h && !has(c, 'decoy'); return cardHTML(d, { u: c.u, str: unitStr(st, i, r, c), act: tgt ? 'decoy-t' : 'peek', cls: (UI.newU.has(c.u) ? 'new ' : '') + (tgt ? 'target' : '') }); }).join('');
  const h = Pp.horn[r]; const hs = h ? (h.leader ? `<span class="lh" title="Leader's horn">${ICON.horn}</span>` : cardHTML(def(h), { u: h.u, act: 'peek' })) : (Pp.mard[r] && Pp.mard[r].u ? cardHTML(def(Pp.mard[r]), { u: Pp.mard[r].u, act: 'peek' }) : '');
  const mardTag = Pp.mard[r] && h ? `<span style="position:absolute;bottom:2px;right:2px;width:14px;height:14px;color:var(--brass2)">${ICON.brew}</span>` : '';
  return `<div class="row ${st.weather[r] ? 'w w-' + r : ''} ${drop ? 'drop' : ''}" ${drop ? `data-act="row-drop" data-row="${r}"` : ''}>
   <div class="rs" title="Row strength">${rowScore(st, i, r)}</div><div class="hslot ${hdrop ? 'hdrop' : ''}" title="Horn slot">${hs}${mardTag}</div>
   <div class="cards"><span class="rowlabel">${ICON[r]}</span>${cards}</div></div>`;
}
function gameHTML() {
  const st = UI.st; const me = st.p[0], op = st.p[1];
  const sel = selectedCard(); const sd = sel ? def(sel) : null;
  const myTurn = canAct(st, 0);
  const anyDrop = sel && myTurn && legalRows(st, 0, sel)[0] === 'any';
  const wcards = st.weatherCards.map(w => cardHTML(def(w.c), { u: w.c.u, act: 'peek' })).join('') || '<span class="muted" style="font-size:12px">Fair weather</span>';
  const hand = me.hand.slice().sort((a, b) => { const x = def(a), y = def(b); return (isUnit(y) - isUnit(x)) || (x.s - y.s) || x.n.localeCompare(y.n); }).map(c => cardHTML(def(c), { u: c.u, act: 'hand', cls: UI.sel === c.u ? 'sel' : '' })).join('');
  let status = '';
  if (st.over) status = 'The match is over.';
  else if (st.phase !== 'play') status = 'Shuffling…';
  else if (st.turn === 0) status = me.passed ? 'You passed.' : (op.passed ? 'Your opponent passed. Play as many cards as you like.' : 'Your turn.');
  else status = 'Your opponent is thinking…';
  if (sel && myTurn) status = sd.a.includes('decoy') ? 'Choose a unit on your side to take back.' : anyDrop ? 'Click the weather field or the Play button.' : sd.a.includes('spy') ? 'Place it in the highlighted enemy row.' : 'Choose a highlighted row.';
  const prevD = UI.prev ? (UI.prev.leader ? null : DEF[UI.prev.id]) : (sd || null);
  let pv;
  if (UI.prev && UI.prev.leader) { const L = LDEF[UI.prev.leader]; const mine = UI.prev.side === 0; const can = mine && myTurn && leaderUsable(st, 0); pv = leaderPreviewHTML(L, mine ? (st.p[0].leaderDisabled ? '<div style="color:var(--blood)">Cancelled by the enemy leader.</div>' : st.p[0].leaderUsed ? '<div class="muted">Already used.</div>' : PASSIVE.includes(L.k) ? '' : `<button class="btn primary" data-act="use-leader" ${can ? '' : 'disabled'}>Use ability</button>`) : (st.p[1].leaderUsed ? '<div class="muted">Your opponent has used it.</div>' : '')); }
  else pv = previewHTML(prevD, anyDrop && sd ? `<button class="btn primary" data-act="play-any">Play</button>` : '');
  const logH = st.log.slice(-60).map(l => `<div class="${l.who === 0 ? 'me' : l.who === 1 ? 'op' : 'sys'}">${esc(l.msg)}</div>`).join('');
  const mobileSel = sel ? `<div class="mobile-only" style="gap:8px;align-items:center;justify-content:space-between;background:var(--leather);border:1px solid var(--line);border-radius:8px;padding:8px"><span style="min-width:0"><b>${esc(sd.n)}</b> <span class="muted" style="font-size:12.5px">${esc(describeCard(sd).map(x => x[1]).join(', ') || ROW_NAME[sd.r])}</span></span>${anyDrop ? '<button class="btn primary" data-act="play-any">Play</button>' : ''}<button class="btn" data-act="peek-sel">Details</button></div>` : '';
  return `<div id="game" class="screen"><div class="gwrap">
  <aside class="side left">${pinfoHTML(1)}<div class="weather-box ${anyDrop ? 'drop' : ''}" ${anyDrop ? 'data-act="play-any"' : ''} title="Weather">${wcards}</div>${pinfoHTML(0)}</aside>
  <main class="board">
   ${rowHTML(1, 'siege')}${rowHTML(1, 'ranged')}${rowHTML(1, 'close')}
   <div class="mid-line"></div>
   ${rowHTML(0, 'close')}${rowHTML(0, 'ranged')}${rowHTML(0, 'siege')}
   <div class="status">${status}</div>
   ${mobileSel}
   <div class="hand">${hand || '<span class="muted">Your hand is empty.</span>'}</div>
  </main>
  <aside class="side right">
   <div class="controls"><button class="btn" data-act="quit">Leave</button>${musicBtn()}<button class="btn ${UI.passArm ? 'primary' : ''}" data-act="pass" ${myTurn ? '' : 'disabled'}>${UI.passArm ? 'Really pass?' : 'Pass'}</button></div>
   <div class="pile"><div class="stack">${op.deck.length}</div><div class="stack disc" data-act="disc-1" title="Opponent's discard pile">${op.discard.length}</div><span>Opponent<br>deck · discard</span></div>
   <div class="preview">${pv}</div>
   <div class="pile"><div class="stack">${me.deck.length}</div><div class="stack disc" data-act="disc-0" title="Your discard pile">${me.discard.length}</div><span>You<br>deck · discard</span></div>
   <div class="log" aria-live="polite">${logH}</div>
  </aside></div>${overlayHTML()}</div>`;
}
function overlayHTML() {
  const o = UI.overlay; const st = UI.st; if (!o) return '';
  if (o.kind === 'mulligan') {
    const left = 2 - st.mull[0];
    const cards = st.p[0].hand.map(c => cardHTML(def(c), { u: c.u, act: left > 0 ? 'mull' : 'none' })).join('');
    return `<div class="ov"><div class="box"><h2>Your opening hand</h2><div class="muted">Redraw up to 2 cards: click a card to swap it for a new one. ${left} redraw${left === 1 ? '' : 's'} left. You: ${FACTION_NAME[st.p[0].faction]} · Opponent: ${FACTION_NAME[st.p[1].faction]} (${esc(leaderTitle(LDEF[st.p[1].leader]))}).</div><div class="grid">${cards}</div><div style="display:flex;justify-content:flex-end"><button class="btn primary" data-act="mull-done">Done, let's play</button></div></div></div>`;
  }
  if (o.kind === 'first') return `<div class="ov"><div class="box" style="max-width:480px"><h2>Who goes first?</h2><div class="muted">Free Folk edge: you decide. Moving second lets you see your opponent's cards before you answer.</div><div class="controls"><button class="btn primary" data-act="first-0">I go first</button><button class="btn" data-act="first-1">Opponent goes first</button></div></div></div>`;
  if (o.kind === 'disc') { const Pp = st.p[o.i]; return `<div class="ov" data-act="close-ov"><div class="box"><h2>${o.i === 0 ? 'Your discard pile' : 'Opponent\'s discard pile'} (${Pp.discard.length})</h2><div class="grid">${Pp.discard.map(c => cardHTML(def(c), { u: c.u })).join('') || '<span class="muted">Empty.</span>'}</div><div style="display:flex;justify-content:flex-end"><button class="btn" data-act="close-ov">Close</button></div></div></div>`; }
  if (o.kind === 'peek') { const canL = o.leader && o.side === 0 && canAct(st, 0) && leaderUsable(st, 0); return `<div class="ov" data-act="close-ov"><div class="box" style="max-width:420px;justify-items:center">${o.leader ? leaderPreviewHTML(LDEF[o.leader]) : previewHTML(DEF[o.id])}<div class="controls" style="width:100%">${canL ? '<button class="btn primary" data-act="use-leader">Use ability</button>' : ''}<button class="btn" data-act="close-ov">Close</button></div></div></div>`; }
  if (o.kind === 'over') {
    const w = st.winner; const rows = st.history.map((h, k) => `<tr><td>Round ${k + 1}</td><td class="${h.winner === 0 ? 'w' : ''}">${h.scores[0]}</td><td class="${h.winner === 1 ? 'w' : ''}">${h.scores[1]}</td></tr>`).join('');
    return `<div class="ov"><div class="box" style="max-width:520px"><h2>${w === 0 ? 'Victory!' : w === 1 ? 'Defeat' : 'A draw'}</h2><div class="muted">${w === 0 ? 'The table is yours. The innkeeper is already pouring.' : w === 1 ? 'Your opponent takes the purse this time. Rematch?' : 'Nobody takes the purse tonight.'}</div>
    <table class="results"><tr><th></th><th>You</th><th>Opponent</th></tr>${rows}</table><div class="controls"><button class="btn" data-act="go-menu">Menu</button><button class="btn" data-act="go-setup">Change faction</button><button class="btn primary" data-act="start">Rematch</button></div></div></div>`;
  }
  if (o.kind === 'pending' && st.pending) {
    const p = st.pending; const titles = { medic: 'Healer: choose a unit to revive', row: 'Which row?', reveal: '3 random cards from your opponent\'s hand', pickToHand: 'Choose a card for your hand', discard: p.extra && p.extra.second ? 'Choose the second card to discard' : 'Choose the first card to discard', pickFromDeck: 'Choose a card from your deck', weatherFromDeck: 'Choose a weather card from your deck' };
    if (p.kind === 'row') return `<div class="ov"><div class="box" style="max-width:420px"><h2>${titles.row}</h2><div class="muted">${esc(def(p.extra.card).n)} is Agile.</div><div class="controls"><button class="btn primary" data-act="pend-row" data-row="close">Close Combat</button><button class="btn primary" data-act="pend-row" data-row="ranged">Ranged</button></div></div></div>`;
    const cards = p.options.map((c, k) => cardHTML(def(c), { u: c.u, act: p.kind === 'reveal' ? 'none' : 'pend-pick', extra: `data-k="${k}"` })).join('');
    return `<div class="ov"><div class="box"><h2>${titles[p.kind] || 'Choose'}</h2><div class="grid">${cards}</div>${p.kind === 'reveal' ? '<div style="display:flex;justify-content:flex-end"><button class="btn primary" data-act="pend-ok">OK</button></div>' : ''}</div></div>`;
  }
  return '';
}
function fitAll() {
  $app.querySelectorAll('.row .cards, .hand').forEach(el => {
    const cards = [...el.querySelectorAll(':scope > .card')]; if (cards.length < 2) return;
    const W = el.clientWidth - 12; const cw = cards[0].offsetWidth; const total = cards.length * (cw + 3);
    const ov = total > W ? (total - W) / (cards.length - 1) : 0;
    cards.forEach((c, k) => { c.style.marginLeft = k ? (ov ? `${-ov + 3}px` : '3px') : '0'; });
  });
}
window.addEventListener('resize', () => { if (UI.screen === 'game') fitAll(); });
function copyText(t, btn) {
  const done = ok => { if (btn) { const o = btn.textContent; btn.textContent = ok ? 'Copied' : 'Select and copy below'; setTimeout(() => btn.textContent = o, 1600); } };
  const fallback = () => { done(false); const w = document.createElement('div'); w.className = 'ov'; w.innerHTML = '<div class="box"><h2>Copy the text</h2><textarea readonly style="width:100%;height:50vh;box-sizing:border-box;background:#0f0c09;color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:8px;font:13px/1.4 var(--f-body)"></textarea><div style="display:flex;justify-content:flex-end"><button class="btn">Close</button></div></div>'; w.querySelector('textarea').value = t; w.querySelector('button').onclick = () => w.remove(); document.body.appendChild(w); w.querySelector('textarea').select(); };
  try { navigator.clipboard.writeText(t).then(() => done(true), fallback); } catch (e) { fallback(); }
}
function allPrompts() { return CARD_DATA.map(d => `${d.id} | ${d.n}\n${artPrompt(d)}`).concat(LEADER_DATA.map(L => `${L.id} | ${leaderTitle(L)}\n${artPrompt(L)}`)).join('\n\n'); }

// ---------- events ----------
$app.addEventListener('mouseover', e => {
  if (UI.screen === 'builder') { const c = e.target.closest('.card[data-id], .card[data-leader]'); if (!c || c.closest('#bprev')) return; const k = c.dataset.leader || c.dataset.id; if ((DEF[k] || LDEF[k]) && UI.bprev !== k) { UI.bprev = k; const p = document.getElementById('bprev'); if (p) p.innerHTML = builderPrev(k); } return; }
  if (UI.screen !== 'game' || UI.overlay) return;
  const c = e.target.closest('.card'); if (!c) return;
  const pv = $app.querySelector('.preview'); if (!pv) return;
  if (c.dataset.leader) { const side = c.dataset.act === 'leader-0' ? 0 : 1; if (UI.prev && UI.prev.leader === c.dataset.leader) return; UI.prev = { leader: c.dataset.leader, side }; }
  else if (c.dataset.id && DEF[c.dataset.id]) { if (UI.prev && UI.prev.id === c.dataset.id) return; UI.prev = { id: c.dataset.id }; }
  else return;
  const tmp = document.createElement('div'); tmp.innerHTML = gameHTML(); pv.innerHTML = tmp.querySelector('.preview').innerHTML;
});
$app.addEventListener('input', e => { if (e.target.id === 'vol') MUSIC.setVolume(+e.target.value); });
$app.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'bulk-full' || t.id === 'one-full') { UI.bfull = t.checked; return; }
  if (t.id === 'vol') { MUSIC.setVolume(+t.value); return; }
  if (t.id === 'bulk-art' && t.files.length) {
    const files = [...t.files]; let ok = 0; const miss = [];
    for (const f of files) { const k = matchFile(f.name); if (!k) { miss.push(f.name); continue; } try { await saveCustom(k, f, UI.bfull || /_full\.\w+$/i.test(f.name)); ok++; } catch (err) { miss.push(f.name); } }
    UI.artMsg = `Added art for ${ok} card${ok === 1 ? '' : 's'}.` + (miss.length ? ` No matching card for: ${miss.slice(0, 6).join(', ')}${miss.length > 6 ? '…' : ''}` : '');
    return render();
  }
  if (t.classList.contains('one-art') && t.files.length) { try { await saveCustom(t.dataset.k, t.files[0], UI.bfull); UI.artMsg = ''; } catch (err) { UI.artMsg = err.message; } return render(); }
});
$app.addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t) return;
  const a = t.dataset.act; const st = UI.st; const narrow = window.matchMedia('(max-width:1000px)').matches;
  if (a === 'close-ov') { if (e.target.closest('.box') && t.classList.contains('ov')) return; UI.overlay = null; return render(); }
  switch (a) {
    case 'go-menu': return go('menu');
    case 'go-setup': return go('setup');
    case 'go-builder': UI.bf = UI.myFac; return go('builder');
    case 'go-rules': return go('rules');
    case 'go-credits': UI.screen = 'rules'; render(); setTimeout(() => { const el = document.getElementById('r-credits'); if (el) el.scrollIntoView(); }, 30); return;
    case 'my-fac': UI.myFac = t.dataset.f; return render();
    case 'opp-fac': UI.oppFac = t.dataset.f; return render();
    case 'lvl': UI.level = t.dataset.k; return render();
    case 'music': if (MUSIC.playing) { MUSIC.stop(); UI.music = false; } else { MUSIC.start(); UI.music = true; } ls.set('tc_music', UI.music ? '1' : '0'); return render();
    case 'start': if (!deckValid(UI.decks[UI.myFac].ids)) return; return startGame();
    case 'b-fac': UI.bf = t.dataset.f; UI.bprev = null; return render();
    case 'b-filter': UI.bfilter = t.dataset.k; return render();
    case 'b-leader': UI.decks[UI.bf].leader = t.dataset.l; UI.bprev = t.dataset.l; saveDecks(); return render();
    case 'b-add': UI.decks[UI.bf].ids.push(t.dataset.id); UI.bprev = t.dataset.id; saveDecks(); return render();
    case 'b-rem': { const ids = UI.decks[UI.bf].ids; const k = ids.lastIndexOf(t.dataset.id); if (k >= 0) ids.splice(k, 1); UI.bprev = t.dataset.id; saveDecks(); return render(); }
    case 'b-default': UI.decks[UI.bf] = { leader: UI.decks[UI.bf].leader, ids: defaultDeck(UI.bf) }; saveDecks(); return render();
    case 'b-clear': UI.decks[UI.bf].ids = []; saveDecks(); return render();
    case 'copy-prompt': { const k = t.dataset.k; return copyText(artPrompt(LDEF[k] || DEF[k]), t); }
    case 'copy-prompts': return copyText(allPrompts(), t);
    case 'art-del': IDB.del(t.dataset.k).then(() => { const c = ARTSRC.custom[t.dataset.k]; if (c) URL.revokeObjectURL(c.url); delete ARTSRC.custom[t.dataset.k]; render(); }); return;
    case 'art-clear': IDB.del(null).then(() => { Object.values(ARTSRC.custom).forEach(c => URL.revokeObjectURL(c.url)); ARTSRC.custom = {}; UI.artMsg = 'Uploaded art removed.'; render(); }); return;
    case 'rules-jump': { e.preventDefault(); const el = document.getElementById(t.dataset.to); if (el) el.scrollIntoView({ behavior: 'smooth' }); return; }
  }
  if (UI.screen !== 'game' || !st) return;
  const dropRow = e.target.closest('.row.drop');
  if (dropRow && a !== 'decoy-t' && a !== 'row-drop') { const c = selectedCard(); if (c) return humanAct({ type: 'card', u: c.u, row: dropRow.dataset.row }); }
  switch (a) {
    case 'mull': mulligan(st, 0, +t.dataset.u); return render();
    case 'mull-done': UI.overlay = null; return afterMulligan();
    case 'first-0': return beginPlay(0, 'Your choice.');
    case 'first-1': return beginPlay(1, 'Your choice.');
    case 'quit': clearTimeout(UI.aiTimer); UI.st = null; return go('menu');
    case 'disc-0': case 'disc-1': UI.overlay = { kind: 'disc', i: +a.slice(-1) }; return render();
    case 'pass': if (!canAct(st, 0)) return; if (!UI.passArm) { UI.passArm = true; render(); setTimeout(() => { if (UI.passArm) { UI.passArm = false; if (UI.screen === 'game') render(); } }, 3000); return; } return humanAct({ type: 'pass' });
    case 'hand': { const u = +t.dataset.u; UI.sel = UI.sel === u ? null : u; UI.prev = null; UI.passArm = false; return render(); }
    case 'peek': case 'peek-sel': { if (narrow || a === 'peek-sel') { const id = a === 'peek-sel' ? def(selectedCard()).id : t.dataset.id; UI.overlay = { kind: 'peek', id }; return render(); } UI.prev = { id: t.dataset.id }; return render(); }
    case 'leader-0': case 'leader-1': { const side = +a.slice(-1); if (narrow) { UI.overlay = { kind: 'peek', leader: st.p[side].leader, side }; return render(); } UI.prev = { leader: st.p[side].leader, side }; return render(); }
    case 'use-leader': UI.prev = null; UI.overlay = null; return humanAct({ type: 'leader' });
    case 'row-drop': { const c = selectedCard(); if (!c) return; return humanAct({ type: 'card', u: c.u, row: t.dataset.row }); }
    case 'play-any': { const c = selectedCard(); if (!c) return; return humanAct({ type: 'card', u: c.u, row: null }); }
    case 'decoy-t': { const c = selectedCard(); if (!c) return; return humanAct({ type: 'card', u: c.u, target: +t.dataset.u }); }
    case 'pend-pick': { const p = st.pending; if (!p) return; const ch = p.options[+t.dataset.k]; UI.overlay = null; resolvePending(st, ch); return step(); }
    case 'pend-row': { if (!st.pending) return; UI.overlay = null; resolvePending(st, t.dataset.row); return step(); }
    case 'pend-ok': { if (!st.pending) return; UI.overlay = null; resolvePending(st, null); return step(); }
  }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && UI.screen === 'game') { if (UI.overlay && ['disc', 'peek'].includes(UI.overlay.kind)) { UI.overlay = null; render(); } else if (UI.sel != null) { UI.sel = null; render(); } } });
