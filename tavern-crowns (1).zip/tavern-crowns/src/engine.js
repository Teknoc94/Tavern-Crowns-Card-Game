// ===================== TAVERN CROWNS RULES ENGINE =====================
const DEF = {}; CARD_DATA.forEach(c => DEF[c.id] = c);
const LDEF = {}; LEADER_DATA.forEach(l => LDEF[l.id] = l);
const ROWS = ['close', 'ranged', 'siege'];
const AVENGER = { 'turul_chick': 'the_great_turul', 'grey_cattle': 'bull_of_the_puszta' };
const TRANSFORM = { 'bear_kin_warrior': 'bear_of_the_danube', 'young_bear_kin': 'young_danube_bear' };
const WEATHER_ROWS = { weather_frost: ['close'], weather_fog: ['ranged'], weather_rain: ['siege'], weather_storm: ['ranged', 'siege'] };
const FACTION_NAME = {}; Object.keys(FACTION_INFO).forEach(k => FACTION_NAME[k] = FACTION_INFO[k].name);

const def = c => DEF[c.id];
const has = (c, a) => DEF[c.id].a.includes(a);
const isUnit = d => !['special', 'weather'].includes(d.r);
const rnd = n => Math.floor(Math.random() * n);
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1);[a[i], a[j]] = [a[j], a[i]]; } return a; }
const clone = o => JSON.parse(JSON.stringify(o));

// ---------- state ----------
function newPlayer(name, faction, leaderId, deckIds, st) {
  const deck = deckIds.map(id => ({ u: st.uid++, id }));
  return { name, faction, leader: leaderId, leaderUsed: false, leaderDisabled: false, deck: shuffle(deck), hand: [], discard: [],
    rows: { close: [], ranged: [], siege: [] }, horn: { close: null, ranged: null, siege: null }, mard: { close: null, ranged: null, siege: null },
    lives: 2, passed: false };
}
function newGame(cfg) {
  // cfg: {players:[{name,faction,leader,deck:[ids],ai}]}
  const st = { uid: 1, round: 1, turn: 0, first: 0, weather: { close: false, ranged: false, siege: false }, weatherCards: [], history: [], over: false,
    winner: null, log: [], sim: false, pending: null, ai: cfg.players.map(p => !!p.ai), phase: 'mulligan', mull: [0, 0], fx: [] };
  st.p = cfg.players.map(p => newPlayer(p.name, p.faction, p.leader, p.deck, st));
  // White Flame
  [0, 1].forEach(i => { if (LDEF[st.p[i].leader].k === 'cancel_enemy_leader') st.p[1 - i].leaderDisabled = true; });
  [0, 1].forEach(i => { const P = st.p[i]; draw(st, i, 10 + (leaderOn(st, i, 'extra_card_start') ? 1 : 0)); });
  log(st, 'Decks shuffled. Both players drew their hands.');
  return st;
}
function log(st, msg, who) { if (!st.sim) st.log.push({ msg, who }); }
function fx(st, kind, data) { if (!st.sim) st.fx.push(Object.assign({ kind }, data)); }
function leaderOn(st, i, key) { const P = st.p[i]; return !P.leaderDisabled && LDEF[P.leader].k === key; }
function draw(st, i, n) { const P = st.p[i]; let k = 0; for (; k < n && P.deck.length; k++) P.hand.push(P.deck.pop()); return k; }
const nameOf = c => def(c).n;
const pname = (st, i) => st.p[i].name;

// ---------- strength ----------
function treacherous(st) { return leaderOn(st, 0, 'double_spies') || leaderOn(st, 1, 'double_spies'); }
function unitStr(st, i, row, c) {
  const d = def(c); if (d.h) return d.s; if (has(c, 'decoy')) return 0;
  const P = st.p[i]; const cards = P.rows[row];
  let s = d.s;
  if (has(c, 'spy') && treacherous(st)) s *= 2;
  if (st.weather[row]) s = leaderOn(st, i, 'weather_halves') ? Math.max(Math.floor(s / 2), s > 0 ? 1 : 0) : Math.min(s, 1);
  if (d.a.includes('bond')) { const key = d.g || d.id; const n = cards.filter(x => { const e = def(x); return !e.h && e.a.includes('bond') && (e.g || e.id) === key; }).length; s *= Math.max(1, n); }
  s += cards.filter(x => x !== c && has(x, 'morale')).length;
  if (P.horn[row] || cards.some(x => x !== c && has(x, 'horn'))) s *= 2;
  return s;
}
function rowScore(st, i, row) { return st.p[i].rows[row].reduce((a, c) => a + unitStr(st, i, row, c), 0); }
function score(st, i) { return ROWS.reduce((a, r) => a + rowScore(st, i, r), 0); }

// ---------- choices (CPS) ----------
// ask: if AI/sim -> immediate AI choice; else store pending for UI
function ask(st, i, kind, options, cb, extra) {
  if (!options.length) return cb(null);
  if (st.sim || st.ai[i]) return cb(AI.choose(st, i, kind, options, extra));
  st.pending = { player: i, kind, options, cb, extra };
}
function resolvePending(st, choice) { const p = st.pending; st.pending = null; p.cb(choice); }

// ---------- board ops ----------
function removeFromBoard(st, c) {
  for (const i of [0, 1]) for (const r of ROWS) { const a = st.p[i].rows[r]; const k = a.indexOf(c); if (k >= 0) { a.splice(k, 1); return { side: i, row: r }; } }
  return null;
}
function findOnBoard(st, uid) {
  for (const i of [0, 1]) for (const r of ROWS) { const c = st.p[i].rows[r].find(x => x.u === uid); if (c) return { c, side: i, row: r }; }
  return null;
}
function destroy(st, c) {
  const loc = removeFromBoard(st, c); if (!loc) return;
  const P = st.p[loc.side];
  P.discard.push(c);
  fx(st, 'burn', { u: c.u });
  log(st, `${nameOf(c)} was destroyed.`);
  const av = AVENGER[c.id];
  if (av) { const t = { u: st.uid++, id: av }; P.rows[DEF[av].r === 'agile' ? 'close' : DEF[av].r].push(t); log(st, `${DEF[av].n} rises in place of ${nameOf(c)}!`); }
}
function scorchAll(st, by) {
  let max = -1; const all = [];
  for (const i of [0, 1]) for (const r of ROWS) for (const c of st.p[i].rows[r]) { const d = def(c); if (d.h || has(c, 'decoy')) continue; const s = unitStr(st, i, r, c); all.push([c, s]); if (s > max) max = s; }
  if (max <= 0) { log(st, 'Wildfire: no valid target.'); return; }
  const kill = all.filter(x => x[1] === max).map(x => x[0]);
  log(st, `Wildfire (${by}): every unit with ${max} strength burns.`);
  kill.forEach(c => destroy(st, c));
}
function scorchRow(st, targetSide, row, by) {
  const total = rowScore(st, targetSide, row);
  if (total < 10) { log(st, `${by}: target row has only ${total} strength (< 10), no effect.`); return; }
  let max = -1; const cand = [];
  for (const c of st.p[targetSide].rows[row]) { const d = def(c); if (d.h || has(c, 'decoy')) continue; const s = unitStr(st, targetSide, row, c); cand.push([c, s]); if (s > max) max = s; }
  if (max <= 0) return;
  const kill = cand.filter(x => x[1] === max).map(x => x[0]);
  log(st, `${by}: the strongest ${ROW_TXT[row]} unit(s) of ${pname(st, targetSide)} (${max}) burn.`);
  kill.forEach(c => destroy(st, c));
}
const ROW_TXT = { close: 'close combat', ranged: 'ranged', siege: 'siege' };
function transformRow(st, i, row) {
  const a = st.p[i].rows[row];
  for (let k = 0; k < a.length; k++) { const t = TRANSFORM[a[k].id]; if (t) { log(st, `${nameOf(a[k])} transforms into ${DEF[t].n}!`); a[k] = { u: a[k].u, id: t }; fx(st, 'place', { u: a[k].u }); } }
}
function setWeather(st, kind) {
  if (kind === 'weather_clear') { ROWS.forEach(r => st.weather[r] = false); return; }
  WEATHER_ROWS[kind].forEach(r => st.weather[r] = true);
}
function playWeatherCard(st, i, c) {
  const k = def(c).a[0];
  if (k === 'weather_clear') {
    st.weatherCards.forEach(w => st.p[w.owner].discard.push(w.c)); st.weatherCards = [];
    setWeather(st, k); st.p[i].discard.push(c); log(st, `${pname(st, i)}: Clear Weather – all weather effects removed.`, i);
  } else {
    st.weatherCards.push({ c, owner: i }); setWeather(st, k); log(st, `${pname(st, i)} played ${nameOf(c)}.`, i);
  }
  fx(st, 'weather', { kind: k });
}

// place a unit on board, trigger abilities, then done()
function placeUnit(st, i, c, row, done, opts = {}) {
  const d = def(c);
  if (d.a.includes('spy') && !opts.silent) {
    st.p[1 - i].rows[row].push(c); fx(st, 'place', { u: c.u });
    const n = draw(st, i, 2);
    log(st, `${pname(st, i)} sent a spy: ${d.n} (+${n} cards).`, i);
    return done();
  }
  const P = st.p[i];
  P.rows[row].push(c); fx(st, 'place', { u: c.u });
  if (!opts.silent) log(st, `${pname(st, i)} played ${d.n}${opts.revived ? ' (revived)' : ''}.`, i);
  if (opts.silent) { if (TRANSFORM[c.id] && P.mard[row]) transformRow(st, i, row); return done(); }
  // bearkin
  if (TRANSFORM[c.id] && P.mard[row]) transformRow(st, i, row);
  if (d.a.includes('brew')) { if (!P.mard[row]) P.mard[row] = { hero: true }; transformRow(st, i, row); }
  if (d.a.includes('muster') && !opts.noMuster) {
    const pulled = P.deck.filter(x => DEF[x.id].g && DEF[x.id].g === d.g);
    if (pulled.length) {
      P.deck = P.deck.filter(x => !pulled.includes(x));
      pulled.forEach(x => { const xr = DEF[x.id].r === 'agile' ? 'close' : DEF[x.id].r; P.rows[xr].push(x); fx(st, 'place', { u: x.u }); if (TRANSFORM[x.id] && P.mard[xr]) transformRow(st, i, xr); });
      log(st, `Muster: ${pulled.map(nameOf).join(', ')} joined the battle.`, i);
    }
  }
  if (d.a.includes('scorch_close')) scorchRow(st, 1 - i, 'close', d.n);
  if (d.a.includes('scorch_ranged')) scorchRow(st, 1 - i, 'ranged', d.n);
  if (d.a.includes('scorch_siege')) scorchRow(st, 1 - i, 'siege', d.n);
  if (d.a.includes('scorch') && isUnit(d)) scorchAll(st, d.n);
  if (d.a.includes('medic')) return doMedic(st, i, done);
  done();
}
function medicTargets(st, i) { return st.p[i].discard.filter(c => { const d = def(c); return isUnit(d) && !d.h; }); }
function doMedic(st, i, done) {
  const opts = medicTargets(st, i);
  if (!opts.length) { log(st, 'Healer: no unit to revive.'); return done(); }
  const random = leaderOn(st, 0, 'random_medic') || leaderOn(st, 1, 'random_medic');
  const after = c => {
    if (!c) return done();
    const P = st.p[i]; P.discard.splice(P.discard.indexOf(c), 1);
    const d = def(c);
    if (d.r === 'agile') return ask(st, i, 'row', ['close', 'ranged'], r => placeUnit(st, i, c, r || 'close', done, { revived: true }), { card: c });
    placeUnit(st, i, c, d.r, done, { revived: true });
  };
  if (random) return after(opts[rnd(opts.length)]);
  ask(st, i, 'medic', opts, after);
}

// ---------- actions ----------
// action: {type:'card', u, row, target} | {type:'leader'} | {type:'pass'}
function canAct(st, i) { return !st.over && st.phase === 'play' && st.turn === i && !st.pending && !st.p[i].passed; }
function leaderUsable(st, i) {
  const P = st.p[i]; if (P.leaderUsed || P.leaderDisabled) return false;
  const k = LDEF[P.leader].k; const O = st.p[1 - i];
  switch (k) {
    case 'play_fog_from_deck': return P.deck.some(c => c.id === 'ecsed_marsh_fog');
    case 'play_rain_from_deck': return P.deck.some(c => c.id === 'danube_deluge');
    case 'play_frost_from_deck': return P.deck.some(c => c.id === 'carpathian_frost');
    case 'play_any_weather_from_deck': return P.deck.some(c => def(c).r === 'weather');
    case 'clear_puszta_sky': return ROWS.some(r => st.weather[r]);
    case 'horn_siege': return !P.horn.siege;
    case 'horn_close': return !P.horn.close;
    case 'horn_ranged': return !P.horn.ranged;
    case 'scorch_siege': case 'scorch_ranged': case 'scorch_close': return true;
    case 'view_3_opponent_hand': return O.hand.length > 0;
    case 'take_from_enemy_discard': return O.discard.length > 0;
    case 'discard_to_hand': return P.discard.length > 0;
    case 'discard2_pick1': return P.hand.length >= 2 && P.deck.length > 0;
    case 'optimize_agile': return ROWS.some(r => P.rows[r].some(c => def(c).r === 'agile'));
    case 'shuffle_graveyards_into_decks': return P.discard.length + O.discard.length > 0;
    default: return false; // passive
  }
}
function legalRows(st, i, c) {
  const d = def(c);
  if (d.r === 'weather' || (d.r === 'special' && d.a.includes('scorch'))) return ['any'];
  if (d.a.includes('decoy')) return [];
  if (d.r === 'special' && d.a.includes('horn')) return ROWS.filter(r => !st.p[i].horn[r]);
  if (d.r === 'special' && d.a.includes('brew')) return ROWS.filter(r => !st.p[i].mard[r]);
  if (d.r === 'agile') return ['close', 'ranged'];
  return [d.r];
}
function decoyTargets(st, i) { const out = []; ROWS.forEach(r => st.p[i].rows[r].forEach(c => { if (!def(c).h && !has(c, 'decoy')) out.push(c); })); return out; }

function doAction(st, i, act, done) {
  // done(): called when the action fully resolved (incl. choices)
  const P = st.p[i];
  if (act.type === 'pass') { P.passed = true; log(st, `${pname(st, i)} passed.`, i); fx(st, 'pass', { i }); return done(); }
  if (act.type === 'leader') return useLeader(st, i, done);
  const k = P.hand.findIndex(c => c.u === act.u); if (k < 0) return done();
  const c = P.hand[k]; const d = def(c);
  P.hand.splice(k, 1);
  if (d.r === 'weather') { playWeatherCard(st, i, c); return done(); }
  if (d.r === 'special') {
    if (d.a.includes('scorch')) { P.discard.push(c); log(st, `${pname(st, i)} played ${d.n}.`, i); scorchAll(st, d.n); return done(); }
    if (d.a.includes('horn')) { P.horn[act.row] = c; log(st, `${pname(st, i)} sounded a Commander's Horn on the ${ROW_TXT[act.row]} row.`, i); fx(st, 'horn', { i, row: act.row }); return done(); }
    if (d.a.includes('brew')) { P.mard[act.row] = c; log(st, `${pname(st, i)} used ${d.n} on the ${ROW_TXT[act.row]} row.`, i); transformRow(st, i, act.row); return done(); }
    if (d.a.includes('decoy')) {
      const t = findOnBoard(st, act.target);
      if (!t || t.side !== i || def(t.c).h) { P.hand.push(c); return done(); }
      const arr = P.rows[t.row]; arr[arr.indexOf(t.c)] = c; P.hand.push(t.c);
      log(st, `${pname(st, i)} used a Scarecrow to take back ${nameOf(t.c)}.`, i); fx(st, 'place', { u: c.u });
      return done();
    }
  }
  placeUnit(st, i, c, act.row, done);
}

function useLeader(st, i, done) {
  const P = st.p[i], O = st.p[1 - i]; const L = LDEF[P.leader];
  P.leaderUsed = true; log(st, `${pname(st, i)} used the leader ability: ${L.n}${L.ti && L.f !== 'RC' ? ' – ' + L.ti : ''}.`, i);
  fx(st, 'leader', { i });
  const fromDeck = id => { const k = P.deck.findIndex(c => c.id === id); if (k < 0) return; const c = P.deck.splice(k, 1)[0]; playWeatherCard(st, i, c); };
  switch (L.k) {
    case 'play_fog_from_deck': fromDeck('ecsed_marsh_fog'); return done();
    case 'play_rain_from_deck': fromDeck('danube_deluge'); return done();
    case 'play_frost_from_deck': fromDeck('carpathian_frost'); return done();
    case 'play_any_weather_from_deck': {
      const seen = {}; const opts = P.deck.filter(c => def(c).r === 'weather' && !seen[c.id] && (seen[c.id] = 1));
      return ask(st, i, 'weatherFromDeck', opts, c => { if (c) { P.deck.splice(P.deck.indexOf(c), 1); playWeatherCard(st, i, c); } done(); });
    }
    case 'clear_puszta_sky': st.weatherCards.forEach(w => st.p[w.owner].discard.push(w.c)); st.weatherCards = []; setWeather(st, 'weather_clear'); return done();
    case 'horn_siege': case 'horn_close': case 'horn_ranged': { const r = L.k.split('_')[1]; if (!P.horn[r]) P.horn[r] = { leader: true }; fx(st, 'horn', { i, row: r }); return done(); }
    case 'scorch_siege': scorchRow(st, 1 - i, 'siege', L.n); return done();
    case 'scorch_ranged': scorchRow(st, 1 - i, 'ranged', L.n); return done();
    case 'scorch_close': scorchRow(st, 1 - i, 'close', L.n); return done();
    case 'view_3_opponent_hand': {
      const cards = shuffle(O.hand.slice()).slice(0, 3);
      if (!st.sim && !st.ai[i]) { st.pending = { player: i, kind: 'reveal', options: cards, cb: () => done() }; return; }
      return done();
    }
    case 'take_from_enemy_discard': return ask(st, i, 'pickToHand', O.discard.slice(), c => { if (c) { O.discard.splice(O.discard.indexOf(c), 1); P.hand.push(c); log(st, `${pname(st, i)} took ${nameOf(c)} from the enemy discard pile.`, i); } done(); });
    case 'discard_to_hand': return ask(st, i, 'pickToHand', P.discard.slice(), c => { if (c) { P.discard.splice(P.discard.indexOf(c), 1); P.hand.push(c); log(st, `${pname(st, i)} returned ${nameOf(c)} to hand.`, i); } done(); });
    case 'discard2_pick1': {
      return ask(st, i, 'discard', P.hand.slice(), a => {
        if (a) { P.hand.splice(P.hand.indexOf(a), 1); P.discard.push(a); }
        ask(st, i, 'discard', P.hand.slice(), b => {
          if (b) { P.hand.splice(P.hand.indexOf(b), 1); P.discard.push(b); }
          const seen = {}; const opts = P.deck.filter(c => !seen[c.id] && (seen[c.id] = 1));
          ask(st, i, 'pickFromDeck', opts, c => { if (c) { P.deck.splice(P.deck.indexOf(c), 1); P.hand.push(c); } log(st, `${pname(st, i)} discarded 2 cards and picked one from the deck.`, i); done(); });
        }, { second: true });
      });
    }
    case 'optimize_agile': {
      ['close', 'ranged'].forEach(r => {
        P.rows[r].filter(c => def(c).r === 'agile').forEach(c => {
          const other = r === 'close' ? 'ranged' : 'close';
          const cur = rowScore(st, i, r) + rowScore(st, i, other);
          P.rows[r].splice(P.rows[r].indexOf(c), 1); P.rows[other].push(c);
          const nw = rowScore(st, i, r) + rowScore(st, i, other);
          if (nw <= cur) { P.rows[other].splice(P.rows[other].indexOf(c), 1); P.rows[r].push(c); }
        });
      });
      return done();
    }
    case 'shuffle_graveyards_into_decks':
      [P, O].forEach(X => { X.deck = shuffle(X.deck.concat(X.discard)); X.discard = []; });
      log(st, 'Both discard piles shuffled back into the decks.'); return done();
  }
  done();
}

// ---------- turn / round flow ----------
function startPlay(st, firstPlayer) { st.phase = 'play'; st.first = firstPlayer; st.turn = firstPlayer; log(st, `Round 1 begins. ${pname(st, firstPlayer)} ${firstPlayer === 0 ? 'go' : 'goes'} first.`); }
function mulligan(st, i, uid) {
  const P = st.p[i]; if (st.mull[i] >= 2) return; const k = P.hand.findIndex(c => c.u === uid); if (k < 0 || !P.deck.length) return;
  const c = P.hand.splice(k, 1)[0]; P.deck.unshift(c); shuffle(P.deck); P.hand.push(P.deck.pop()); st.mull[i]++;
}
// after an action of player i resolves
function afterAction(st, i) {
  if (st.p[0].passed && st.p[1].passed) return endRound(st);
  const o = 1 - i;
  st.turn = st.p[o].passed ? i : o;
  autoPassIfStuck(st);
}
function autoPassIfStuck(st) {
  const P = st.p[st.turn];
  if (!P.passed && P.hand.length === 0 && !leaderUsable(st, st.turn)) { P.passed = true; log(st, `${P.name} ${st.turn === 0 ? 'are' : 'is'} out of cards and passed.`, st.turn); fx(st, 'pass', { i: st.turn }); afterAction(st, st.turn); }
}
function roundWinner(st) {
  const a = score(st, 0), b = score(st, 1);
  if (a > b) return 0; if (b > a) return 1;
  const ng0 = st.p[0].faction === 'GE', ng1 = st.p[1].faction === 'GE';
  if (ng0 && !ng1) return 0; if (ng1 && !ng0) return 1; return -1;
}
function endRound(st) {
  const s = [score(st, 0), score(st, 1)]; const w = roundWinner(st);
  st.history.push({ scores: s, winner: w });
  if (w === -1) { st.p[0].lives--; st.p[1].lives--; log(st, `Round ${st.round}: draw (${s[0]}–${s[1]}). Both players lose a life.`); }
  else { st.p[1 - w].lives--; log(st, `Round ${st.round}: ${pname(st, w)} won (${s[0]}–${s[1]})${s[0] === s[1] ? ' – the Golden Basileia wins the tie' : ''}.`); }
  fx(st, 'roundEnd', { w, s });
  if (w >= 0 && st.p[w].faction === 'CR' && (st.p[0].lives > 0 && st.p[1].lives > 0)) { if (draw(st, w, 1)) log(st, `Holy Crown: ${pname(st, w)} ${w === 0 ? 'draw' : 'draws'} a card for the win.`, w); }
  const over = st.p[0].lives <= 0 || st.p[1].lives <= 0;
  // cleanup
  const avengers = [];
  [0, 1].forEach(i => {
    const P = st.p[i]; let keep = null;
    if (!over && P.faction === 'NB') {
      const units = []; ROWS.forEach(r => P.rows[r].forEach(c => { if (!has(c, 'decoy') && !has(c, 'spy')) units.push([c, r]); }));
      if (units.length) { keep = units[rnd(units.length)]; log(st, `Night Brood: ${nameOf(keep[0])} stays on the battlefield.`, i); }
    }
    ROWS.forEach(r => {
      P.rows[r].forEach(c => { if (keep && keep[0] === c) return; P.discard.push(c); if (AVENGER[c.id]) avengers.push([i, c]); });
      P.rows[r] = []; if (P.horn[r] && !P.horn[r].leader) P.discard.push(P.horn[r]); P.horn[r] = null;
      if (P.mard[r] && P.mard[r].u) P.discard.push(P.mard[r]); P.mard[r] = null;
    });
    if (keep) P.rows[keep[1]].push(keep[0]);
    P.passed = false;
  });
  st.weatherCards.forEach(wc => st.p[wc.owner].discard.push(wc.c)); st.weatherCards = []; setWeather(st, 'weather_clear');
  if (over) {
    st.over = true; st.phase = 'over';
    const l0 = st.p[0].lives <= 0, l1 = st.p[1].lives <= 0;
    st.winner = l0 && l1 ? -1 : (l0 ? 1 : 0);
    log(st, st.winner === -1 ? 'The match is a draw!' : `${pname(st, st.winner)} won the match!`);
    return;
  }
  if (!over) avengers.forEach(([i, c]) => { const id = AVENGER[c.id]; const t = { u: st.uid++, id }; st.p[i].rows[DEF[id].r].push(t); log(st, `${nameOf(c)} is gone – ${DEF[id].n} takes its place.`, i); });
  st.round++;
  const prevFirst = st.turn; // not used
  st.turn = w >= 0 ? w : 1 - st.first; st.first = st.turn;
  log(st, `Round ${st.round} begins. ${pname(st, st.turn)} ${st.turn === 0 ? 'go' : 'goes'} first.`);
  if (st.round === 3) [0, 1].forEach(i => {
    const P = st.p[i]; if (P.faction !== 'RC') return;
    const pool = P.discard.filter(c => { const d = def(c); return isUnit(d) && !d.h && !d.a.includes('spy') && !d.t; });
    shuffle(pool).slice(0, 2).forEach(c => { P.discard.splice(P.discard.indexOf(c), 1); placeUnit(st, i, c, def(c).r === 'agile' ? 'close' : def(c).r, () => { }, { silent: true }); log(st, `River Clans: ${nameOf(c)} returns from the discard pile!`, i); });
  });
  autoPassIfStuck(st);
}

// run a full action for i, then advance turn. cb() when completed (pending may defer)
function runAction(st, i, act, cb) { doAction(st, i, act, () => { afterAction(st, i); cb && cb(); }); }

// ===================== AI =====================
const AI = {
  // choose among options for a pending choice
  choose(st, i, kind, options, extra) {
    const last = st.p[0].lives === 1 && st.p[1].lives === 1;
    if (kind === 'row') { // agile placement: avoid weather, prefer row with horn/morale
      let best = options[0], bv = -1e9;
      options.forEach(r => { const s = clone(st); s.sim = true; s.ai = [true, true]; const c = s.p[i].discard.find(x => x.u === extra.card.u) || extra.card; s.p[i].rows[r].push({ u: -1, id: extra.card.id }); const v = score(s, i); if (v > bv) { bv = v; best = r; } });
      return best;
    }
    if (kind === 'medic' || kind === 'pickToHand') {
      let best = null, bv = -1e9;
      options.forEach(c => { const d = def(c); let v = d.s + (d.a.includes('spy') ? (last ? -d.s : 20 - d.s * 2) : 0) + (d.a.includes('medic') ? 8 : 0) + (d.a.includes('muster') ? 4 : 0) + (d.h ? 2 : 0) + (d.r === 'special' || d.r === 'weather' ? 6 : 0);
        if (kind === 'medic' && d.a.includes('spy') && st.p[i].faction !== 'X') v += 0; if (v > bv) { bv = v; best = c; } });
      return best;
    }
    if (kind === 'discard') { return options.slice().sort((a, b) => AI.cardWorth(st, a) - AI.cardWorth(st, b))[0]; }
    if (kind === 'pickFromDeck') { return options.slice().sort((a, b) => AI.cardWorth(st, b) - AI.cardWorth(st, a))[0]; }
    if (kind === 'weatherFromDeck') {
      let best = null, bv = -1e9;
      options.forEach(c => { const s = clone(st); s.sim = true; s.ai = [true, true]; const before = score(s, i) - score(s, 1 - i); setWeather(s, def(c).a[0]); const v = score(s, i) - score(s, 1 - i) - before; if (v > bv) { bv = v; best = c; } });
      return best;
    }
    return options[0];
  },
  cardWorth(st, c) { const d = def(c); let v = d.s * (d.h ? 1.3 : 1); if (d.a.includes('spy')) v = 18; if (d.a.includes('medic')) v += 6; if (d.a.includes('muster')) v += 4; if (d.a.includes('bond')) v += 3; if (d.r === 'special') v = 9; if (d.r === 'weather') v = 6; if (d.a.includes('decoy')) v = 8; return v; },
  enumerate(st, i) {
    const P = st.p[i]; const acts = []; const seen = new Set();
    P.hand.forEach(c => {
      const d = def(c); if (seen.has(c.id)) return; seen.add(c.id);
      if (d.a.includes('decoy')) { decoyTargets(st, i).forEach(t => acts.push({ type: 'card', u: c.u, target: t.u })); return; }
      legalRows(st, i, c).forEach(r => acts.push({ type: 'card', u: c.u, row: r === 'any' ? null : r }));
    });
    if (leaderUsable(st, i)) acts.push({ type: 'leader' });
    return acts;
  },
  simulate(st, i, act) {
    const s = clone(st); s.sim = true; s.ai = [true, true]; s.pending = null; s.fx = []; s.log = [];
    doAction(s, i, act, () => { }); return s;
  },
  winning(st, i) { const w = roundWinner(st); return w === i; },
  // greedy count of cards needed to take the lead
  cardsToWin(st, i) {
    let s = st; for (let k = 1; k <= 6; k++) {
      const acts = AI.enumerate(s, i); if (!acts.length) return null;
      let best = null, bv = -1e9;
      acts.forEach(a => { const t = AI.simulate(s, i, a); const v = score(t, i) - score(t, 1 - i); if (v > bv) { bv = v; best = t; } });
      if (!best) return null; s = best; if (AI.winning(s, i)) return k;
    }
    return null;
  },
  decide(st, i, level) {
    level = level || (st.level && st.level[i]) || 'medium';
    const P = st.p[i], O = st.p[1 - i];
    const me = score(st, i), op = score(st, 1 - i);
    const winning = AI.winning(st, i);
    const mustWin = P.lives === 1; const oppMust = O.lives === 1; const finalRound = mustWin && oppMust;
    const acts = AI.enumerate(st, i);
    if (!acts.length) return { type: 'pass' };
    if (level === 'easy') return AI.decideEasy(st, i, acts, winning, mustWin);
    const CV = finalRound ? 1 : (mustWin ? 4 : 8);
    const hard = level === 'hard' || level === 'hardnr';
    let pScorch = 0;
    if (level === 'hard' && O.hand.length) { let seen = 0; [0, 1].forEach(k => st.p[k].discard.forEach(c => { if (c.id === 'taltos_fire') seen++; })); pScorch = Math.max(0, 3 - seen) / 3 * Math.min(1, O.hand.length / 6) * 0.6; }
    const evals = acts.map(a => {
      const t = AI.simulate(st, i, a);
      const gain = (score(t, i) - score(t, 1 - i)) - (me - op);
      const handDelta = t.p[i].hand.length - P.hand.length;
      let card = a.type === 'card' ? P.hand.find(c => c.u === a.u) : null;
      let reserve = 0;
      if (!finalRound) {
        if (card) { const d = def(card); if (d.h) reserve += d.s * 0.45; if (d.r === 'special' && !d.a.includes('decoy')) reserve += 3; if (d.r === 'weather') reserve += 1; }
        if (a.type === 'leader') reserve += 4;
      }
      let spyBack = 0; if (card && def(card).a.includes('decoy')) { const tg = findOnBoard(st, a.target); if (tg && has(tg.c, 'spy')) spyBack = finalRound ? 0 : CV * 0.9; else if (tg && has(tg.c, 'medic')) spyBack = finalRound ? 0 : 3; else spyBack = -3; }
      let risk = 0;
      if (pScorch) { let mx = 0; const at = [[], []]; [0, 1].forEach(k => ROWS.forEach(r => t.p[k].rows[r].forEach(c => { const d = def(c); if (d.h || has(c, 'decoy')) return; const v = unitStr(t, k, r, c); if (v > mx) { mx = v; at[0] = []; at[1] = []; } if (v === mx) at[k].push(v); }))); const mine = at[i].reduce((x, y) => x + y, 0), theirs = at[1 - i].reduce((x, y) => x + y, 0); if (mx >= 8 && mine > theirs) risk = pScorch * (mine - theirs) * 0.6; }
      const val = gain + CV * (handDelta + 1) - reserve + spyBack - risk;
      return { a, t, gain, handDelta, val, win: AI.winning(t, i), worth: card ? AI.cardWorth(st, card) : 5 };
    });
    evals.sort((x, y) => y.val - x.val);
    const best = evals[0];
    // free card draw when it keeps the lead
    const free = evals.filter(e => e.handDelta >= 0 && e.win && e.gain > -1000).sort((x, y) => y.val - x.val)[0];
    if (O.passed) {
      if (winning) return free && free.handDelta > 0 ? free.a : { type: 'pass' };
      const winners = evals.filter(e => e.win);
      if (winners.length) {
        if (oppMust || mustWin || finalRound) return winners.sort((x, y) => x.worth - y.worth)[0].a;
        // round where neither must win: only if it keeps card parity
        if (P.hand.length - 1 >= O.hand.length - 1) return winners.sort((x, y) => x.worth - y.worth)[0].a;
        return { type: 'pass' };
      }
      const k = AI.cardsToWin(st, i);
      if (k == null) return { type: 'pass' };
      if (mustWin || oppMust) return best.a;
      if (P.hand.length - k >= O.hand.length) return best.a;
      return { type: 'pass' };
    }
    // opponent still playing
    if (winning) {
      if (free && free.handDelta > 0 && !finalRound) return free.a;
      if (finalRound) return O.hand.length === 0 ? { type: 'pass' } : (best.val > -CV * 2 ? best.a : { type: 'pass' });
      if (oppMust && !mustWin) return { type: 'pass' }; // we lead 1-0: let them burn cards
      if (mustWin) { const safe = hard ? Math.max(14, O.hand.length * 6) : 20; if (me - op >= safe && (hard || P.hand.length <= O.hand.length)) return { type: 'pass' }; return best.a; }
      if (P.hand.length >= O.hand.length) return { type: 'pass' };
      return best.val > 0 ? best.a : { type: 'pass' };
    }
    // behind or tied
    if (mustWin || finalRound) return best.a;
    if (best.handDelta >= 0) return best.a; // spies
    if (oppMust && !mustWin) {
      // we lead 1-0: invest only if cheap
      const k = AI.cardsToWin(st, i); if (k != null && k <= 2 && P.hand.length - k > O.hand.length - 1) return best.a; return { type: 'pass' };
    }
    const k = AI.cardsToWin(st, i);
    if (k == null) return { type: 'pass' };
    if (P.hand.length - k < O.hand.length - 1) return { type: 'pass' };
    return best.a;
  },
  decideEasy(st, i, acts, winning, mustWin) {
    const P = st.p[i], O = st.p[1 - i];
    const me = score(st, i), op = score(st, 1 - i);
    if (O.passed && winning) return { type: 'pass' };
    if (!O.passed && winning && Math.random() < 0.3) return { type: 'pass' };
    if (O.passed && !winning && !mustWin && Math.random() < 0.4) return { type: 'pass' };
    if (!winning && !mustWin && op - me > 25 && Math.random() < 0.5) return { type: 'pass' };
    if (Math.random() < 0.35) return acts[rnd(acts.length)];
    let best = acts[0], bv = -1e9;
    acts.forEach(a => { const t = AI.simulate(st, i, a); const v = score(t, i) - score(t, 1 - i); if (v > bv) { bv = v; best = a; } });
    return best;
  },
  mulligan(st, i, level) {
    if (level === 'easy') return;
    const P = st.p[i];
    for (let n = 0; n < 2; n++) {
      const groups = {}; P.hand.forEach(c => { const d = def(c); if (d.a.includes('muster') && d.g) (groups[d.g] = groups[d.g] || []).push(c); });
      let pick = null; for (const g in groups) if (groups[g].length > 1) { pick = groups[g][1]; break; }
      if (!pick) { const weak = P.hand.filter(c => { const d = def(c); return isUnit(d) && !d.h && d.a.length === 0 && d.s <= 3; }); if (weak.length) pick = weak[0]; }
      if (!pick) break; mulligan(st, i, pick.u);
    }
  },
};

// ---------- deck helpers ----------
function collection(faction) { return CARD_DATA.filter(c => !c.t && (c.f === faction || c.f === 'NE')); }
function deckStats(ids) { let units = 0, specials = 0, str = 0, heroes = 0; ids.forEach(id => { const d = DEF[id]; if (isUnit(d)) { units++; str += d.s; if (d.h) heroes++; } else specials++; }); return { units, specials, str, heroes, total: ids.length }; }
function deckValid(ids) { const s = deckStats(ids); return s.units >= 22 && s.specials <= 10; }
function defaultDeck(faction) {
  const ids = [];
  CARD_DATA.filter(c => !c.t && c.f === faction).forEach(c => { for (let k = 0; k < c.c; k++) ids.push(c.id); });
  // trim weak vanilla units if big
  const weakOrder = ids.filter(id => { const d = DEF[id]; return isUnit(d) && !d.h && d.a.length === 0; }).sort((a, b) => DEF[a].s - DEF[b].s);
  let units = ids.filter(id => isUnit(DEF[id])).length;
  const neutralUnits = ['miklos_toldi', 'prince_csaba_of_the_starry_road', 'saint_margaret_the_healer', 'the_hooded_taltos', 'golden_dragon_of_the_matra', 'saint_elizabeth_of_the_roses', 'igric_the_minstrel'];
  neutralUnits.forEach(id => ids.push(id)); units += neutralUnits.length;
  while (units > 26 && weakOrder.length) { const w = weakOrder.shift(); ids.splice(ids.indexOf(w), 1); units--; }
  const specials = ['scarecrow', 'scarecrow', 'royal_war_horn', 'taltos_fire', 'taltos_fire', 'carpathian_frost', 'ecsed_marsh_fog', 'danube_deluge', 'clear_puszta_sky'];
  if (faction === 'RC') { specials.splice(5, 3, 'carpathian_frost', 'balaton_squall'); specials.push('taltos_brew'); }
  const existingSpecials = ids.filter(id => !isUnit(DEF[id])).length; // River Clans own 3 Táltos Brews in faction
  let sp = specials.slice(0, Math.max(0, 10 - existingSpecials));
  if (faction === 'RC') { // keep 2 brew only
    let m = ids.filter(id => id === 'taltos_brew').length; while (m > 2) { ids.splice(ids.indexOf('taltos_brew'), 1); m--; }
    sp = specials.filter(x => x !== 'taltos_brew').slice(0, 10 - 2);
  }
  return ids.concat(sp);
}
function strongDeck(faction) {
  const pool = CARD_DATA.filter(c => !c.t && (c.f === faction || c.f === 'NE') && isUnit(c));
  const ids = []; const add = (c) => { for (let k = 0; k < c.c; k++) ids.push(c.id); };
  const val = c => c.s + (c.h ? 3 : 0) + (c.a.includes('spy') ? 30 : 0) + (c.a.includes('medic') ? 12 : 0) + (c.a.includes('muster') ? 6 : 0) + (c.a.includes('bond') ? 5 : 0) + (c.a.includes('morale') ? 3 : 0) + (c.a.includes('scorch_close') || c.a.includes('scorch_ranged') || c.a.includes('scorch_siege') ? 4 : 0) + (c.a.includes('summon_avenger') ? 9 : 0) + (c.a.includes('horn') ? 4 : 0) - (c.a.includes('bearkin') ? 2 : 0);
  pool.sort((a, b) => val(b) - val(a));
  for (const c of pool) { if (ids.length >= 22) break; add(c); }
  // complete muster/bond groups
  const sp = ['scarecrow', 'scarecrow', 'scarecrow', 'taltos_fire', 'taltos_fire', 'royal_war_horn', 'royal_war_horn', 'carpathian_frost', 'clear_puszta_sky', faction === 'RC' ? 'taltos_brew' : 'ecsed_marsh_fog'];
  return ids.concat(sp);
}
const STRONG_LEADER = { 'CR': 'cr_bela_iv_the_second_founder', 'GE': 'ge_manuel_i_komnenos_the_basileus', 'FF': 'ff_tunder_ilona_keeper_of_the_golden_apples', 'NB': 'nb_vasorru_baba_mother_of_the_brood', 'RC': 'rc_lehel_of_the_horn' };
function defaultLeader(f) { return LEADER_DATA.find(l => l.f === f).id; }

if (typeof module !== 'undefined') module.exports = { DEF, LDEF, newGame, startPlay, runAction, AI, score, roundWinner, defaultDeck, defaultLeader, deckValid, deckStats, LEADER_DATA, CARD_DATA, mulligan, resolvePending, leaderUsable };
