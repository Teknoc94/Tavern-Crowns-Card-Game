// ---------- RULEBOOK ----------
function rulesHTML() {
  const abRows = Object.keys(AB).map(k => `<tr><td style="width:28px;color:var(--brass2)"><span style="display:block;width:20px;height:20px">${ICON[k] || ''}</span></td><td><b>${AB[k][0]}</b></td><td>${AB[k][1]}</td></tr>`).join('');
  const leadRows = LEADER_DATA.map(L => `<tr><td>${FACTION_NAME[L.f]}</td><td><b>${esc(L.n)}</b><br><span class="muted">${esc(L.ti)}</span></td><td>${LEAD_TXT[L.k]}${PASSIVE.includes(L.k) ? '' : ' <span class="muted">(once per match)</span>'}</td></tr>`).join('');
  const cardTables = ['NE', ...FACS].map(f => {
    const list = CARD_DATA.filter(c => c.f === f).sort((a, b) => (isUnit(b) - isUnit(a)) || (b.h - a.h) || (b.s - a.s) || a.n.localeCompare(b.n));
    const rows = list.map(c => `<tr><td><b>${esc(c.n)}</b>${c.h ? ' <span style="color:var(--brass2)">· legend</span>' : ''}${c.t ? ' <span class="muted">· summoned only</span>' : ''}</td><td style="text-align:center">${isUnit(c) ? c.s : '–'}</td><td>${ROW_NAME[c.r]}</td><td>${c.a.map(a => AB[a] ? AB[a][0] : a).join(', ') || '–'}</td><td style="text-align:center">${c.t ? '–' : c.c}</td><td>${SET_NAME[c.d]}</td></tr>`).join('');
    return `<h3 id="k-${f}">${FACTION_NAME[f]} (${list.filter(c => !c.t).reduce((a, c) => a + c.c, 0)} cards in a full collection)</h3><div class="tbl"><table><tr><th>Card</th><th>Str</th><th>Row</th><th>Abilities</th><th>Copies</th><th>Set</th></tr>${rows}</table></div>`;
  }).join('');
  const toc = [['r-basics', 'Basics'], ['r-setup', 'Setup'], ['r-round', 'A round'], ['r-str', 'Strength'], ['r-ab', 'Abilities'], ['r-fac', 'Factions'], ['r-lead', 'Leaders'], ['r-tac', 'Tactics'], ['r-hist', 'History & legend'], ['r-cards', 'Card list'], ['r-credits', 'Credits']];
  return `<div class="screen"><div class="rules">
  <div class="topbar"><button class="btn" data-act="go-menu">← Menu</button><h2 style="font-size:28px;border:0;padding:0">Rulebook</h2><button class="btn primary" data-act="go-setup">Play</button></div>
  <p class="muted">Tavern Crowns is played in the inns of a fantasy Carpathian Basin around the 12th–14th centuries, where kings, emperors, fairies and folk-tale monsters all want a seat at the table.</p>
  <nav class="toc">${toc.map(([id, t]) => `<a href="#${id}" data-act="rules-jump" data-to="${id}">${t}</a>`).join('')}</nav>

  <section id="r-basics"><h2>Basics</h2>
  <p>A match is three rounds, and <b>the first player to win two rounds wins the match</b>. Each player has two lives; losing a round costs one. At the end of a round, the player with more total strength on the battlefield wins it.</p>
  <p>The twist: <b>you do not draw new cards between rounds</b>. The ten cards you start with, plus whatever your abilities fetch, must win two rounds. Losing a round on purpose is often the strongest move, because if your opponent spends more cards to win it than you did, you go into the last two rounds with more cards.</p></section>

  <section id="r-setup"><h2>Setup</h2><ul>
   <li><b>Deck:</b> one leader, at least 22 unit cards (legends count as units) and at most 10 special cards (weather, Scarecrow, War Horn, Táltos Fire, Táltos Brew). Neutral cards fit any deck.</li>
   <li><b>Opening hand:</b> both players draw 10 cards (11 with Tündér Ilona, Keeper of the Golden Apples), then may redraw up to 2.</li>
   <li><b>First turn:</b> a coin toss decides, unless one player plays the Free Folk of the Bakony; they choose.</li>
   <li><b>A smaller deck is a better deck.</b> Every extra card makes your best cards less likely to reach your hand.</li></ul></section>

  <section id="r-round"><h2>A round</h2><ul>
   <li>Players take turns. On your turn you <b>play one card</b>, <b>use your leader ability</b> or <b>pass</b>. Using the leader takes your whole turn.</li>
   <li><b>Passing</b> ends your part of the round: you cannot play again until the next round, but your opponent may keep playing cards one at a time. When both players have passed, the round ends. With no cards left you pass automatically.</li>
   <li><b>Winning a round:</b> the higher total wins. On a draw both players lose a life, unless exactly one of them plays the Golden Basileia, who wins ties.</li>
   <li><b>End of round:</b> every card goes to a discard pile (a spy goes to the pile of the player whose side it lay on) and the weather clears. The Night Brood keep one random unit; a Holy Crown player who won draws a card.</li>
   <li>The winner of a round starts the next one; after a draw, the player who did not start the previous round begins.</li>
   <li><b>Golden rule:</b> when a card's text contradicts these rules, the card wins.</li></ul></section>

  <section id="r-str"><h2>Rows and strength</h2>
  <p>Each side has three rows: <b>Close Combat</b>, <b>Ranged</b> and <b>Siege</b>. No row beats another; rows matter because weather, horns and many abilities work row by row. The icon on a card shows where it goes; Agile cards can go to Close Combat or Ranged.</p>
  <p>The strength of a non-legend unit is worked out in this order:</p>
  <ul><li><b>1. Base strength</b> (spies are doubled under The Ördög)</li><li><b>2. Weather:</b> drops to 1 (Lehel of the Horn: only halved, for his own units)</li><li><b>3. Brotherhood:</b> × the number of same-name Brotherhood cards in the row</li><li><b>4. Rally:</b> + the number of other Rally units in the row</li><li><b>5. War Horn:</b> ×2 if the row has a horn (the card, a leader horn, or another horn-bearer). Never more than one doubling per row.</li></ul>
  <p>Example: three Árpád-Stripe Guards (4) in a row are 3 × 12 = 36. One Rally unit in the same row makes them 3 × 13 = 39, and a War Horn doubles that to 78.</p></section>

  <section id="r-ab"><h2>Abilities and special cards</h2>
  <div class="tbl"><table><tr><th></th><th>Ability</th><th>Effect</th></tr><tr><td style="color:var(--brass2)"><span style="display:block;width:20px;height:20px">${ICON.hero}</span></td><td><b>Legend</b></td><td>Nothing touches a legend: no weather, horn, Rally, Brotherhood, Wildfire, Scarecrow or Healer. Legends with their own ability (Saint Margaret, the Hooded Táltos, Réka, the Old Táltos and others) still use it.</td></tr>${abRows}</table></div></section>

  <section id="r-fac"><h2>Factions</h2>
  <div class="tbl"><table><tr><th>Faction</th><th>Edge</th><th>World and style</th></tr>
  ${FACS.map(f => `<tr><td><b>${FACTION_NAME[f]}</b></td><td>${FAC_EDGE[f]}</td><td>${FACTION_INFO[f].lore}<br><span class="muted">${FAC_STYLE[f]}</span></td></tr>`).join('')}
  </table></div></section>

  <section id="r-lead"><h2>Leaders (22)</h2><p class="muted">Active abilities work once per match and take your turn. Passive abilities work all match long.</p><div class="tbl"><table><tr><th>Faction</th><th>Leader</th><th>Ability</th></tr>${leadRows}</table></div></section>

  <section id="r-tac"><h2>Tactics</h2><ul>
   <li><b>Cards are the currency, not points.</b> A round you lose while spending two cards fewer is often better than one you win for three extra cards.</li>
   <li><b>Play spies early.</b> A spy in round one buys two cards and rarely decides the round. The Hooded Táltos (0, legend) gives your opponent nothing at all.</li>
   <li><b>The spy engine.</b> A Scarecrow can take an enemy spy back from your side so you can play it against them. A Healer can revive a spy or another Healer.</li>
   <li><b>Pass while ahead.</b> Once you hold the card lead, pass in front and make your opponent spend cards to catch up.</li>
   <li><b>Mind the Wildfire.</b> Do not build one huge, fragile Brotherhood row while your opponent might hold Táltos Fire. Units of equal strength burn together.</li>
   <li><b>Weather hits both sides.</b> A legend-heavy deck can freeze its own rows happily. Save Clear Puszta Sky until your opponent has invested.</li>
   <li><b>The deciding round (1–1):</b> nothing is worth saving. Play every legend, horn and fire.</li></ul></section>

  <section id="r-hist"><h2>History and legend behind the cards</h2>
  <p class="muted">The cards mix real 12th–14th-century history with Hungarian folk tales. Abilities are invented for the game; the people and stories are real or traditional.</p><ul>
   <li><b>The Árpád stripes.</b> The red-and-silver horizontal stripes were the arms of the Árpád dynasty from around 1200; the patriarchal double cross appears on royal coins and seals of the period.</li>
   <li><b>Béla IV, the Second Founder.</b> After the Mongol invasion and the defeat at Muhi (1241) he rebuilt the kingdom around stone castles, which is why his ability doubles the Siege row. Palatine Dénes, Archbishop Ugrin Csák and Duke Coloman, Béla's brother, fought at Muhi; Queen Maria Laskarina was his Byzantine-born wife.</li>
   <li><b>Coloman the Learned</b> (reigned 1095–1116) is remembered for a law stating that witches do not exist, so his ability conjures fog rather than magic.</li>
   <li><b>Charles Robert of Anjou</b> broke the power of the great oligarchs and their castles in the early 14th century; <b>Louis the Great</b>'s realm was said to be washed by three seas.</li>
   <li><b>Teutonic Knights in Barcaság.</b> Andrew II invited the Order to the Burzenland in 1211 and expelled it in 1225. <b>Cuman horse archers</b> settled in Hungary from 1239; Saxon settlers and miners worked in Transylvania and in the silver mines of Selmec.</li>
   <li><b>The Golden Basileia</b> is drawn from 12th-century Byzantium. Béla III was raised at the court of Manuel I Komnenos as the heir Alexios, with the title of despot. Irene Piroska, daughter of Saint Ladislaus, became empress and co-founded the Pantokrator monastery and its hospital. Anna Komnene wrote the Alexiad; Andronikos Kontostephanos beat the Hungarians at Sirmium in 1167; John Axouch was Grand Domestic; the Varangian Guard and Greek fire were the empire's famous weapons.</li>
   <li><b>Saint Margaret</b> (1242–1270), Béla IV's daughter, and <b>Saint Elizabeth</b> (1207–1231), Andrew II's daughter, whose bread turned into roses, are among the best-loved Hungarian saints. <b>Miklós Toldi</b> was a 14th-century soldier whose strength became legend.</li>
   <li><b>Folk tales.</b> Tündér Ilona is the fairy queen of the Tündérkert; Csongor and Tünde come from Vörösmarty's play based on the same tale. The garabonciás is a wandering scholar who rides a dragon and calls storms; the vasorrú bába is the iron-nosed hag; the lidérc, the fene, the mumus, the boszorkány and the seven-headed dragon all come from the same folklore. Prince Csaba rides down the Milky Way, the Warriors' Road, to help his people.</li>
   <li><b>The River Clans</b> borrow their names from the age of the conquest: Lehel's carved horn, Botond's mace that cracked the gate of Constantinople, Álmos the Dream-Born, and the turul, the mythical falcon of the Árpád line.</li></ul></section>

  <section id="r-credits"><h2>Credits</h2>
  <p>Game design, rules engine, card text and code: the Tavern Crowns project (MIT licence).</p>
  <p><b>Character portraits</b> are taken from <a href="https://www.wesnoth.org" target="_blank" rel="noopener">The Battle for Wesnoth</a>, painted by the Wesnoth art team and released under the GNU GPL v2 or later (older art) and CC BY-SA 4.0 (newer art). They are cropped and placed on generated backgrounds here; these card images are shared under the same licences. The source file for every card is listed in <code>CREDITS.md</code>.</p>
  <p><b>Music</b> also comes from The Battle for Wesnoth:</p><ul>${[...TRACKS.menu, ...TRACKS.game, ...TRACKS.final, TRACKS.victory, TRACKS.defeat].map(t => `<li>${esc(t.title)} by ${esc(t.by)} (${t.lic})</li>`).join('')}</ul>
  <p class="muted">Backgrounds, icons and frames are generated by the game's own code.</p></section>

  <section id="r-cards"><h2>Full card list</h2><nav class="toc">${['NE', ...FACS].map(f => `<a href="#k-${f}" data-act="rules-jump" data-to="k-${f}">${FACTION_NAME[f]}</a>`).join('')}</nav>${cardTables}</section>
  </div></div>`;
}
