// ===================== MUSIC: freely licensed tracks from The Battle for Wesnoth (see CREDITS) =====================
const TRACKS = {
  menu: [
    { file: 'traveling_minstrels.mp3', title: 'Traveling Minstrels', by: 'Mattias Westlund', lic: 'GPL-2.0-or-later' },
    { file: 'three-sheets.mp3', title: 'Three Sheets', by: 'Scott Buckley', lic: 'CC BY-SA 4.0' },
  ],
  game: [
    { file: 'heroes_rite.mp3', title: 'Heroes’ Rite', by: 'Doug Kaufman', lic: 'GPL-2.0-or-later' },
    { file: 'legends_of_the_north.mp3', title: 'Legends of the North', by: 'Mattias Westlund', lic: 'GPL-2.0-or-later' },
    { file: 'northern_mountains.mp3', title: 'Northern Mountains', by: 'Mattias Westlund', lic: 'GPL-2.0-or-later' },
    { file: 'knolls.mp3', title: 'Knolls', by: 'Timothy Pinkham', lic: 'GPL-2.0-or-later' },
    { file: 'loyalists.mp3', title: 'Loyalists', by: 'Joseph G. Toscano', lic: 'GPL-2.0-or-later' },
    { file: 'the_city_falls.mp3', title: 'The City Falls', by: 'Doug Kaufman', lic: 'GPL-2.0-or-later' },
    { file: 'wanderer.mp3', title: 'Wanderer', by: 'Timothy Pinkham', lic: 'GPL-2.0-or-later' },
  ],
  final: [{ file: 'battle-epic.mp3', title: 'Battle (Epic)', by: 'Doug Kaufman', lic: 'GPL-2.0-or-later' }],
  victory: { file: 'victory.mp3', title: 'Victory', by: 'Timothy Pinkham', lic: 'GPL-2.0-or-later' },
  defeat: { file: 'defeat.mp3', title: 'Defeat', by: 'Timothy Pinkham', lic: 'GPL-2.0-or-later' },
};
const MUSIC = (() => {
  const BASE = 'music/';
  let el = null, mode = 'menu', idx = {}, playing = false, vol = 0.5, fadeT = null, now = null;
  try { const v = parseFloat(localStorage.getItem('tc_vol')); if (v >= 0 && v <= 1) vol = v; } catch (e) { }
  function audio() { if (!el) { el = new Audio(); el.preload = 'auto'; el.addEventListener('ended', () => { if (playing) next(); }); el.addEventListener('error', () => { if (playing) setTimeout(next, 800); }); } return el; }
  function pick(list) { const k = mode; idx[k] = ((idx[k] ?? Math.floor(Math.random() * list.length)) + 1) % list.length; return list[idx[k]]; }
  function fadeTo(target, ms, done) {
    clearInterval(fadeT); const a = audio(); const start = a.volume, t0 = performance.now();
    fadeT = setInterval(() => { const k = Math.min(1, (performance.now() - t0) / ms); a.volume = Math.max(0, Math.min(1, start + (target - start) * k)); if (k >= 1) { clearInterval(fadeT); done && done(); } }, 40);
  }
  function play(track) { const a = audio(); now = track; a.src = BASE + track.file; a.volume = 0; const p = a.play(); if (p && p.catch) p.catch(() => { }); fadeTo(vol, 1200); }
  function next() { play(pick(TRACKS[mode] || TRACKS.menu)); }
  return {
    start() { const a = audio(); if (playing) { if (a.paused && a.src) { const p = a.play(); if (p && p.catch) p.catch(() => { }); } return true; } playing = true; next(); return true; },
    stop() { if (!playing) return; playing = false; fadeTo(0, 500, () => audio().pause()); },
    setMode(m) { if (m === mode) return; mode = m; if (!playing) return; fadeTo(0, 700, () => next()); },
    sting(kind) { if (!playing) return; const t = TRACKS[kind]; if (!t) return; fadeTo(0, 400, () => { play(t); }); },
    setVolume(v) { vol = v; try { localStorage.setItem('tc_vol', String(v)); } catch (e) { } if (playing) audio().volume = v; },
    get volume() { return vol; },
    get playing() { return playing; },
    get audible() { return playing && el && !el.paused; },
    get track() { return now; },
  };
})();
