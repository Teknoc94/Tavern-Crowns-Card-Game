// ===================== ORIGINAL CARD ILLUSTRATIONS (procedural painted scenes) =====================
// Fallback art: every image is generated here when no painted art file exists: sky + layered terrain + backlit silhouette + atmosphere + grain.
const ART = (() => {
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let a = seed || 1; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  const PAL = {
    day: ['#5f8fbf', '#a6c3d8', '#ecdcb8', '#7a8c96', '#36442f', '#fff1c4', '#151a12'],
    dusk: ['#262540', '#9a5246', '#f2ae62', '#573a44', '#21151a', '#ffcd7e', '#120b0d'],
    night: ['#060a18', '#152048', '#3a4d78', '#1a243e', '#0a0e1a', '#b8d2ff', '#04060c'],
    storm: ['#1a1f26', '#394450', '#6b7983', '#323c45', '#151a1f', '#e2ebf3', '#0a0d10'],
    snow: ['#5e7189', '#b2c2d2', '#eef3f6', '#9aabbb', '#d6e1ea', '#ffffff', '#18212c'],
    fog: ['#545c60', '#879093', '#b7bcba', '#767e80', '#454d4f', '#f2f3ee', '#1c2122'],
    fire: ['#190704', '#6c1b0b', '#e3681f', '#3a1209', '#130504', '#ffc65c', '#0a0302'],
    swamp: ['#111d17', '#2d4733', '#7d8e5d', '#283a29', '#0e1810', '#d8f2a2', '#060c07'],
    sea: ['#1c283e', '#485d7e', '#a2b5c6', '#33455e', '#182333', '#e2edff', '#090f17'],
    forest: ['#192818', '#3d5931', '#aab670', '#2b3f26', '#121e10', '#f3f4b6', '#091107'],
    blood: ['#180407', '#560e15', '#bb432f', '#380a10', '#110309', '#ffb48c', '#090103'],
    gold: ['#110e09', '#4a3917', '#dba542', '#3a2b11', '#110c05', '#ffe49c', '#090704'],
    violet: ['#181330', '#4b3a78', '#bb8cab', '#392e59', '#130e23', '#f5daff', '#090611'],
    crown: ['#1b1923', '#5a2a30', '#cc8a6c', '#3a2a32', '#150f14', '#ffe2c4', '#0b0709'],
    purple: ['#150c22', '#4a2160', '#d6a44c', '#2e1840', '#110a1b', '#ffe7aa', '#09050f'],
    ice: ['#0d1a2a', '#2c5274', '#8fc3dc', '#22405a', '#0b1724', '#d9f4ff', '#050b12'],
  };

  // ---------- motifs: primitives in a 100x100 box ----------
  // ['p',d] fill path · ['s',d,w] stroke path · ['c',x,y,r] circle · ['e',x,y,rx,ry,rot] ellipse · ['g',d] glowing path · ['gc',x,y,r] glowing circle
  const fig = (x = 50, y = 0, s = 1) => d => d; // placeholder
  const BODY = 'M43 27 Q50 24 57 27 L61 52 Q60 56 57 56 L56 92 L51 92 L50 62 L49 92 L44 92 L43 56 Q40 56 39 52 Z';
  const M = {
    soldier: [['c', 50, 18, 7], ['p', 'M42 17 Q50 4 58 17 L59 20 L41 20 Z'], ['p', BODY], ['p', 'M22 33 L40 31 L40 54 Q31 66 22 54 Z'], ['p', 'M59 44 L61.5 46 L76 9 L73.5 7.5 Z'], ['s', 'M56 40 L66 46', 3]],
    spearman: [['c', 50, 18, 7], ['p', 'M42 17 Q50 5 58 17 L59 20 L41 20 Z'], ['p', BODY], ['s', 'M64 96 L64 4', 2.5], ['p', 'M61 6 L64 -4 L67 6 Z'], ['p', 'M24 30 L40 30 L40 60 L24 60 Z']],
    archer: [['c', 47, 18, 7], ['p', 'M40 17 Q46 8 54 14 L55 20 L40 20 Z'], ['p', 'M40 27 Q47 24 54 27 L58 52 Q57 56 54 56 L53 92 L48 92 L47 62 L46 92 L41 92 L40 56 Q37 56 36 52 Z'], ['s', 'M28 6 Q8 46 28 88', 3], ['s', 'M28 6 L60 42 L28 88', 1], ['s', 'M60 42 L16 42', 1.6], ['p', 'M12 42 L19 39 L19 45 Z'], ['s', 'M52 34 L62 42', 4]],
    cavalry: [['p', 'M14 62 Q18 49 38 50 L64 50 Q72 44 78 35 L87 32 L91 39 L85 46 Q81 54 79 62 L81 90 L76 90 L72 68 L49 68 L45 90 L40 90 L39 68 Q27 72 23 90 L18 90 Q19 74 14 62 Z'], ['p', 'M10 58 Q4 70 8 82 Q12 72 15 64 Z'], ['c', 50, 22, 5.5], ['p', 'M44 52 L42 31 L52 27 L58 33 L60 52 Z'], ['s', 'M58 34 L96 6', 2.5]],
    catapult: [['p', 'M8 78 L92 78 L88 70 L12 70 Z'], ['c', 24, 84, 9], ['c', 76, 84, 9], ['s', 'M28 68 L82 18', 5], ['c', 84, 16, 7], ['s', 'M46 70 L54 42 L62 70', 4], ['s', 'M44 50 L64 50', 3]],
    trebuchet: [['s', 'M28 92 L50 22 L72 92', 5], ['s', 'M12 92 L88 92', 6], ['s', 'M16 64 L92 8', 4], ['p', 'M8 58 L26 58 L28 78 L6 78 Z'], ['s', 'M92 8 L84 34', 1.5], ['c', 84, 36, 3]],
    ballista: [['s', 'M14 42 Q50 16 86 42', 5], ['s', 'M50 28 L50 74', 6], ['s', 'M14 42 L50 62 L86 42', 1.2], ['s', 'M50 62 L50 4', 2.4], ['p', 'M46 8 L50 -2 L54 8 Z'], ['s', 'M50 74 L28 94 M50 74 L72 94 M50 74 L50 94', 4]],
    tower: [['p', 'M28 92 L33 22 L67 22 L72 92 Z'], ['p', 'M30 22 L30 12 L37 12 L37 17 L44 17 L44 12 L56 12 L56 17 L63 17 L63 12 L70 12 L70 22 Z'], ['c', 33, 92, 6], ['c', 67, 92, 6], ['g', 'M45 40 L55 40 L55 52 L45 52 Z'], ['s', 'M67 40 L88 34', 3]],
    scorpion: [['p', 'M8 78 L92 78 L86 68 L14 68 Z'], ['c', 22, 84, 8], ['c', 78, 84, 8], ['p', 'M30 68 L36 50 L64 50 L70 68 Z'], ['s', 'M50 52 L84 22', 6], ['gc', 86, 20, 7], ['g', 'M80 12 Q90 4 96 14 Q92 24 86 26 Z']],
    swords: [['s', 'M20 88 L78 16', 4.5], ['s', 'M80 88 L22 16', 4.5], ['s', 'M24 70 L38 84', 4], ['s', 'M76 70 L62 84', 4], ['c', 17, 92, 4], ['c', 83, 92, 4], ['g', 'M78 16 L84 8 L82 18 Z'], ['g', 'M22 16 L16 8 L18 18 Z']],
    sword: [['s', 'M50 96 L50 18', 6], ['p', 'M46 18 L50 2 L54 18 Z'], ['s', 'M34 78 L66 78', 5], ['s', 'M50 80 L50 96', 4], ['c', 50, 97, 4], ['g', 'M49 22 L51 22 L51 70 L49 70 Z']],
    orb: [['s', 'M50 98 L50 38', 3.5], ['s', 'M44 40 Q50 30 56 40', 3], ['gc', 50, 26, 13], ['g', 'M50 6 L53 22 L50 46 L47 22 Z']],
    mask: [['p', 'M14 36 Q30 22 50 34 Q70 22 86 36 Q84 52 70 56 Q58 58 50 48 Q42 58 30 56 Q16 52 14 36 Z'], ['g', 'M26 40 Q32 35 40 41 Q32 46 26 40 Z'], ['g', 'M74 40 Q68 35 60 41 Q68 46 74 40 Z'], ['s', 'M50 60 L50 96', 4], ['p', 'M46 62 L50 52 L54 62 Z'], ['s', 'M42 66 L58 66', 4]],
    crown: [['p', 'M14 72 L18 30 L34 50 L50 18 L66 50 L82 30 L86 72 Z'], ['p', 'M12 74 L88 74 L86 86 L14 86 Z'], ['gc', 50, 60, 5], ['gc', 30, 62, 3.5], ['gc', 70, 62, 3.5]],
    lute: [['e', 42, 66, 19, 23, -35], ['s', 'M54 50 L84 12', 6], ['p', 'M80 14 L92 4 L96 10 L86 18 Z'], ['g', 'M38 64 m-6 0 a6 6 0 1 0 12 0 a6 6 0 1 0 -12 0'], ['s', 'M30 82 L84 14', 0.8]],
    hammer: [['s', 'M24 94 L64 30', 6], ['p', 'M50 14 L84 34 L74 50 L40 30 Z'], ['g', 'M60 26 L72 33 L70 36 L58 29 Z']],
    axe: [['s', 'M36 98 L58 6', 5], ['p', 'M54 12 Q82 4 90 30 Q86 46 74 50 Q74 36 56 34 Z'], ['g', 'M62 16 Q78 12 84 28 Q80 22 64 22 Z'], ['c', 58, 6, 3.5]],
    spider: [['e', 50, 60, 18, 14, 0], ['e', 50, 38, 10, 9, 0], ['s', 'M36 54 Q16 40 6 54 M34 60 Q14 56 4 72 M36 66 Q20 74 12 92 M40 70 Q32 84 30 98 M64 54 Q84 40 94 54 M66 60 Q86 56 96 72 M64 66 Q80 74 88 92 M60 70 Q68 84 70 98', 3], ['gc', 46, 36, 2], ['gc', 54, 36, 2], ['gc', 50, 33, 1.6]],
    vampire: [['p', 'M50 40 Q34 16 4 22 Q14 32 10 46 Q22 40 28 54 Q36 44 46 56 Z'], ['p', 'M50 40 Q66 16 96 22 Q86 32 90 46 Q78 40 72 54 Q64 44 54 56 Z'], ['c', 50, 26, 8], ['p', 'M43 22 L40 12 L46 19 Z M57 22 L60 12 L54 19 Z'], ['p', 'M44 34 Q50 30 56 34 L60 70 L55 96 L50 72 L45 96 L40 70 Z'], ['gc', 47, 25, 1.6], ['gc', 53, 25, 1.6]],
    hag: [['p', 'M36 96 Q26 66 34 44 Q38 26 52 22 Q64 22 64 34 L72 48 L88 54 L84 58 L68 54 L66 64 L76 96 Z'], ['p', 'M50 22 Q40 30 34 52 Q30 40 38 26 Z'], ['s', 'M84 56 L94 50 M86 58 L96 58 M84 58 L92 64', 1.5], ['gc', 58, 30, 1.8]],
    ghoul: [['p', 'M12 88 L22 64 Q30 50 44 48 Q60 42 70 50 L78 46 Q88 46 90 54 Q88 60 80 60 L76 58 L72 66 L82 88 L76 88 L66 72 L60 88 L54 88 L54 70 L40 70 L30 88 L24 88 L30 70 Z'], ['p', 'M48 46 L52 36 L56 44 L60 36 L62 46 Z'], ['gc', 84, 52, 1.6]],
    goblin: [['e', 50, 66, 16, 18, 0], ['c', 50, 42, 13], ['p', 'M38 36 L28 24 L42 32 Z M62 36 L72 24 L58 32 Z'], ['s', 'M36 70 L20 90 M64 70 L80 90 M42 82 L38 98 M58 82 L62 98', 4], ['gc', 45, 42, 2.2], ['gc', 55, 42, 2.2]],
    wolf: [['p', 'M30 96 Q28 70 36 56 Q32 44 34 30 L28 10 L42 24 Q50 22 56 26 L66 8 L64 30 Q72 40 70 50 L90 58 Q90 66 80 66 L66 64 Q66 80 72 96 Z'], ['gc', 58, 38, 2]],
    bird: [['p', 'M50 52 Q30 18 2 22 Q16 32 12 44 Q26 40 28 52 Q36 46 42 56 L46 72 L50 90 L54 72 L58 56 Q64 46 72 52 Q74 40 88 44 Q84 32 98 22 Q70 18 50 52 Z'], ['c', 50, 44, 7], ['p', 'M50 46 L56 52 L50 50 Z'], ['gc', 48, 42, 1.4]],
    dragon: [['p', 'M46 54 Q30 14 0 12 Q12 24 8 36 Q22 32 24 46 Q32 40 38 52 Z'], ['p', 'M54 54 Q70 14 100 12 Q88 24 92 36 Q78 32 76 46 Q68 40 62 52 Z'], ['p', 'M40 50 Q50 46 60 50 L64 70 Q60 80 50 82 Q40 80 36 70 Z'], ['p', 'M48 50 Q44 36 52 26 Q60 18 68 20 L74 24 L66 26 Q58 30 56 40 L54 50 Z'], ['p', 'M50 80 Q46 92 30 96 Q42 90 44 80 Z'], ['gc', 69, 22, 1.6], ['g', 'M74 24 Q86 26 96 34 Q84 32 72 28 Z']],
    golem: [['p', 'M36 30 L64 28 L72 46 L66 62 L34 62 L28 46 Z'], ['p', 'M42 14 L58 14 L60 28 L40 28 Z'], ['p', 'M28 34 L14 52 L18 72 L26 70 L24 54 L32 46 Z'], ['p', 'M72 34 L86 52 L82 72 L74 70 L76 54 L68 46 Z'], ['p', 'M36 62 L46 62 L44 96 L32 96 Z M54 62 L64 62 L68 96 L56 96 Z'], ['gc', 46, 21, 1.8], ['gc', 54, 21, 1.8], ['g', 'M44 40 L50 34 L56 42 L50 50 Z']],
    tree: [['p', 'M42 96 Q44 70 40 54 Q30 46 26 30 L16 18 L28 26 L24 8 L34 26 Q40 38 46 42 L48 20 L52 42 Q58 36 66 24 L72 6 L72 26 L84 16 L74 32 Q66 46 58 54 Q56 72 58 96 Z'], ['gc', 46, 50, 2], ['gc', 54, 50, 2]],
    tentacles: [['s', 'M20 98 Q10 60 30 40 Q42 30 36 16', 7], ['s', 'M40 98 Q36 70 48 52 Q58 40 54 22', 8], ['s', 'M62 98 Q66 70 58 56 Q50 44 64 30 Q72 24 80 28', 7], ['s', 'M80 98 Q92 70 80 54 Q72 44 88 38', 6], ['gc', 50, 92, 4]],
    beast: [['p', 'M10 80 Q12 56 30 50 Q48 40 62 46 L70 38 Q80 36 86 44 L92 54 L84 58 L80 54 L76 62 L78 88 L72 88 L66 70 L40 72 L34 88 L28 88 L28 72 Q20 74 16 88 L10 88 Z'], ['s', 'M74 40 Q72 26 62 20 M74 40 Q82 24 94 22 M66 22 L60 14 M86 22 L90 12', 3], ['gc', 82, 46, 1.6]],
    ship: [['p', 'M4 70 Q50 92 96 70 L90 62 Q50 78 10 62 Z'], ['p', 'M90 62 Q98 48 92 40 Q86 38 88 46 Q90 52 86 58 Z'], ['s', 'M50 74 L50 8', 3.5], ['p', 'M28 14 L72 14 Q76 36 72 56 L28 56 Q24 36 28 14 Z'], ['g', 'M40 14 L46 14 L46 56 L40 56 Z M54 14 L60 14 L60 56 L54 56 Z'], ['s', 'M14 72 L8 84 M24 76 L20 88 M76 76 L80 88 M86 72 L92 84', 1.5]],
    bear: [['p', 'M8 86 Q6 62 22 52 Q34 40 54 42 Q64 34 74 38 L80 40 Q88 42 94 52 L90 58 L84 56 Q80 62 76 66 L78 90 L70 90 L66 72 L42 74 L38 90 L30 90 L30 74 Q22 78 18 90 L10 90 Z'], ['p', 'M72 39 L74 31 L80 38 Z'], ['gc', 84, 47, 1.7]],
    shieldaxe: [['s', 'M24 94 L76 8', 4], ['p', 'M70 10 Q92 12 94 32 Q80 28 66 22 Z'], ['c', 46, 54, 30], ['g', 'M46 54 m-6 0 a6 6 0 1 0 12 0 a6 6 0 1 0 -12 0'], ['s', 'M46 26 L46 82 M18 54 L74 54', 1.5]],
    cow: [['p', 'M14 50 Q18 40 34 40 L70 40 Q76 34 84 36 L92 46 L88 54 L80 52 L78 60 L80 88 L74 88 L70 66 L36 66 L32 88 L26 88 L26 64 Q18 62 16 88 L10 88 Q12 64 14 50 Z'], ['p', 'M80 36 L78 28 L84 34 Z M88 36 L92 28 L90 38 Z'], ['gc', 86, 44, 1.4]],
    skull: [['p', 'M24 46 Q24 14 50 14 Q76 14 76 46 Q76 58 66 62 L64 76 L36 76 L34 62 Q24 58 24 46 Z'], ['g', 'M34 40 Q40 34 46 42 Q40 50 34 40 Z M66 40 Q60 34 54 42 Q60 50 66 40 Z'], ['p', 'M38 78 L62 78 L60 86 L40 86 Z']],
    wraith: [['p', 'M50 10 Q66 12 68 34 L74 62 Q80 80 90 96 L76 88 L70 96 L62 86 L54 96 L48 86 L40 96 L34 86 L24 94 Q30 78 30 60 L32 34 Q34 12 50 10 Z'], ['gc', 45, 30, 2], ['gc', 55, 30, 2], ['s', 'M30 50 Q18 56 10 48 M70 50 Q82 56 90 48', 3]],
    helm: [['p', 'M24 80 Q20 40 50 26 Q80 40 76 80 L64 80 L62 60 L56 56 L56 82 L44 82 L44 56 L38 60 L36 80 Z'], ['p', 'M30 44 L18 8 L38 34 Z M42 30 L40 0 L50 26 Z M58 30 L60 0 L50 26 Z M70 44 L82 8 L62 34 Z'], ['g', 'M38 58 L48 54 L48 58 Z M62 58 L52 54 L52 58 Z']],
    sun: [['gc', 50, 50, 18], ['g', 'M50 4 L54 30 L50 34 L46 30 Z M50 96 L46 70 L50 66 L54 70 Z M4 50 L30 46 L34 50 L30 54 Z M96 50 L70 54 L66 50 L70 46 Z M17 17 L37 33 L35 37 L31 35 Z M83 83 L63 67 L65 63 L69 65 Z M83 17 L67 37 L63 35 L65 31 Z M17 83 L33 63 L37 65 L35 69 Z']],
    leaf: [['p', 'M50 6 Q80 34 66 74 Q58 90 50 96 Q42 90 34 74 Q20 34 50 6 Z'], ['g', 'M49 20 L51 20 L51 90 L49 90 Z'], ['s', 'M14 86 L86 14', 2], ['p', 'M86 14 L78 16 L84 22 Z']],
    mirror: [['e', 50, 50, 24, 34, 0], ['g', 'M50 22 Q66 26 68 50 Q66 72 50 78 Q36 72 34 50 Q36 28 50 22 Z'], ['s', 'M44 34 L54 48 L46 60 L56 70', 1.4], ['s', 'M50 84 L50 98', 4]],
    banner: [['s', 'M28 98 L28 6', 3.5], ['p', 'M28 10 L80 14 L70 30 L80 46 L28 44 Z'], ['g', 'M48 18 L54 18 L54 24 L60 24 L60 30 L54 30 L54 36 L48 36 L48 30 L42 30 L42 24 L48 24 Z']],
    horn: [['p', 'M10 64 Q22 30 66 24 L88 12 L94 40 L74 38 Q38 42 22 72 Z'], ['g', 'M86 16 L92 38 L88 38 L82 18 Z'], ['s', 'M34 48 Q46 40 60 38', 1.5]],
    scarecrow: [['s', 'M50 98 L50 20', 4], ['s', 'M12 40 L88 40', 4], ['c', 50, 18, 9], ['p', 'M40 14 Q50 2 60 14 L62 18 L38 18 Z'], ['p', 'M30 34 L70 34 L74 68 L66 74 L58 66 L50 76 L42 66 L34 74 L26 68 Z'], ['p', 'M12 36 L24 34 L22 46 L10 46 Z M88 36 L76 34 L78 46 L90 46 Z']],
    flames: [['g', 'M50 98 Q20 86 26 58 Q30 46 38 40 Q36 54 44 58 Q38 34 54 12 Q56 32 66 40 Q70 30 68 22 Q86 44 78 72 Q72 92 50 98 Z'], ['p', 'M50 98 Q36 90 40 72 Q44 64 48 62 Q48 72 54 74 Q52 62 58 52 Q66 66 62 82 Q58 94 50 98 Z']],
    hut: [['p', 'M14 60 L50 28 L86 60 L80 60 L80 92 L20 92 L20 60 Z'], ['g', 'M30 66 L40 66 L40 76 L30 76 Z'], ['p', 'M56 70 L68 70 L68 92 L56 92 Z']],
    mushrooms: [['p', 'M20 52 Q36 26 56 52 Z'], ['p', 'M34 52 L42 52 L44 92 L32 92 Z'], ['p', 'M52 66 Q66 46 84 66 Z'], ['p', 'M64 66 L72 66 L72 92 L64 92 Z'], ['gc', 30, 44, 2], ['gc', 44, 40, 2], ['gc', 70, 58, 1.6]],
    lightning: [['g', 'M58 4 L30 54 L48 54 L38 98 L74 38 L54 38 L66 4 Z']],
    snowflake: [['s', 'M50 8 L50 92 M14 29 L86 71 M14 71 L86 29 M42 16 L50 24 L58 16 M42 84 L50 76 L58 84 M18 40 L26 36 L24 26 M82 60 L74 64 L76 74 M18 60 L26 64 L24 74 M82 40 L74 36 L76 26', 3.5]],
    hanged: [['s', 'M50 0 L50 30', 1.5], ['c', 50, 34, 6], ['p', 'M44 40 L56 40 L58 70 L54 72 L53 96 L50 96 L50 74 L47 96 L44 96 L44 72 L42 70 Z'], ['g', 'M44 96 L46 104 L48 96 Z M50 96 L52 104 L54 96 Z']],
    spear: [['s', 'M30 98 L64 4', 2.5], ['p', 'M60 12 L66 0 L68 14 Z'], ['p', 'M10 92 Q30 80 50 86 Q70 82 90 92 L90 98 L10 98 Z']],
    medic: [['p', 'M30 30 L70 30 L74 90 L26 90 Z'], ['p', 'M40 20 L60 20 L60 30 L40 30 Z'], ['g', 'M46 44 L54 44 L54 54 L64 54 L64 62 L54 62 L54 72 L46 72 L46 62 L36 62 L36 54 L46 54 Z']],
    dwarf: [['c', 50, 26, 9], ['p', 'M40 30 Q50 52 60 30 Q62 44 56 54 L44 54 Q38 44 40 30 Z'], ['p', 'M36 40 Q50 34 64 40 L70 66 L64 68 L62 92 L54 92 L50 74 L46 92 L38 92 L36 68 L30 66 Z'], ['s', 'M70 64 L86 26', 4], ['p', 'M78 20 L94 26 L90 34 L74 28 Z']],
    robed: [['c', 50, 18, 7], ['p', 'M42 18 Q50 4 58 18 L60 24 Q50 20 40 24 Z'], ['p', 'M40 26 Q50 22 60 26 L68 92 L32 92 Z'], ['s', 'M70 96 L74 20', 3], ['gc', 74, 16, 5]],
    rider_dark: [['p', 'M14 62 Q18 49 38 50 L64 50 Q72 44 78 35 L87 32 L91 39 L85 46 Q81 54 79 62 L81 90 L76 90 L72 68 L49 68 L45 90 L40 90 L39 68 Q27 72 23 90 L18 90 Q19 74 14 62 Z'], ['p', 'M44 52 L42 30 L52 26 L58 32 L60 52 Z'], ['p', 'M44 26 L42 14 L48 20 L50 10 L52 20 L58 14 L56 26 Z'], ['gc', 50, 23, 1.6], ['gc', 86, 36, 1.4]],

    arpadsoldier: [['c', 50, 18, 7], ['p', 'M42 17 Q50 4 58 17 L59 20 L41 20 Z'], ['p', BODY], ['st', 'M18 30 L42 28 L42 56 Q30 72 18 56 Z', 18, 28, 24, 44, 8], ['p', 'M59 44 L61.5 46 L76 9 L73.5 7.5 Z'], ['s', 'M56 40 L66 46', 3]],
    crossknight: [['c', 50, 18, 7], ['p', 'M41 21 L41 12 Q50 4 59 12 L59 21 Z'], ['p', 'M40 27 Q50 23 60 27 L66 90 L34 90 Z'], ['k', 'M18 30 L42 28 L42 56 Q30 72 18 56 Z', '#e8e2d4'], ['k', 'M28 34 L32 34 L32 44 L39 44 L39 48 L32 48 L32 62 L28 62 L28 48 L21 48 L21 44 L28 44 Z', '#141414'], ['p', 'M61 44 L63.5 46 L78 9 L75.5 7.5 Z'], ['s', 'M58 40 L68 46', 3]],
    banner_arpad: [['s', 'M26 98 L26 4', 3.5], ['c', 26, 4, 3], ['st', 'M26 8 L84 12 L74 29 L84 46 L26 44 Z', 26, 8, 58, 38, 8]],
    doublecross: [['k', 'M12 98 Q22 74 34 84 Q50 60 66 84 Q78 74 88 98 Z', '#2f5a2a'], ['k', 'M46 6 L54 6 L54 20 L66 20 L66 27 L54 27 L54 38 L72 38 L72 46 L54 46 L54 74 L46 74 L46 46 L28 46 L28 38 L46 38 L46 27 L34 27 L34 20 L46 20 Z', '#ece4d0'], ['g', 'M49 9 L51 9 L51 72 L49 72 Z']],
    holycrown: [['k', 'M20 64 L80 64 L78 86 L22 86 Z', '#c99a3a'], ['k', 'M24 64 Q50 22 76 64 Z', '#8a6420'], ['s', 'M50 26 L50 64 M28 58 Q50 40 72 58', 2.5], ['k', 'M53 6 L57 7 L56 14 L63 15 L62 19 L55 18 L54 26 L50 25 L51 17 L44 16 L45 12 L52 13 Z', '#e0bc5c'], ['gc', 50, 75, 4], ['gc', 34, 75, 3], ['gc', 66, 75, 3], ['s', 'M24 86 L22 96 M30 86 L29 95 M76 86 L78 96 M70 86 L71 95', 1.5]],
    turul: [['p', 'M50 46 Q28 8 0 10 Q14 22 10 34 Q24 30 26 42 Q34 36 40 48 L44 62 L50 80 L56 62 L60 48 Q66 36 74 42 Q76 30 90 34 Q86 22 100 10 Q72 8 50 46 Z'], ['c', 50, 38, 7], ['p', 'M54 36 L62 40 L55 42 Z'], ['gc', 52, 36, 1.4], ['s', 'M34 86 L70 66', 2.5], ['p', 'M70 66 L80 60 L74 70 Z'], ['s', 'M38 80 L42 90', 3], ['s', 'M44 80 Q48 86 56 80', 2]],
    turulchick: [['k', 'M14 80 Q50 100 86 80 Q76 70 50 72 Q24 70 14 80 Z', '#4a3420'], ['s', 'M18 80 Q50 92 82 80', 1], ['p', 'M38 74 Q34 56 48 52 Q60 52 60 62 L68 60 L63 67 Q58 76 38 74 Z'], ['gc', 53, 59, 1.6], ['g', 'M64 60 L70 58 L66 64 Z']],
    eagle2: [['p', 'M50 54 Q30 22 2 26 Q16 34 12 46 Q26 42 28 54 Q36 48 42 58 L46 76 L50 92 L54 76 L58 58 Q64 48 72 54 Q74 42 88 46 Q84 34 98 26 Q70 22 50 54 Z'], ['p', 'M44 52 Q36 40 36 30 L40 26 L44 34 Q46 44 50 50 Q54 44 56 34 L60 26 L64 30 Q64 40 56 52 Z'], ['c', 37, 26, 5], ['c', 63, 26, 5], ['p', 'M33 26 L26 28 L32 30 Z M67 26 L74 28 L68 30 Z'], ['k', 'M32 18 L35 14 L38 18 L41 14 L42 20 L32 20 Z', '#e2b85a'], ['k', 'M58 20 L59 14 L62 18 L65 14 L68 18 L68 20 Z', '#e2b85a'], ['gc', 37, 25, 1.2], ['gc', 63, 25, 1.2]],
    horsearcher: [['p', 'M14 62 Q18 49 38 50 L64 50 Q72 44 78 35 L87 32 L91 39 L85 46 Q81 54 79 62 L81 90 L76 90 L72 68 L49 68 L45 90 L40 90 L39 68 Q27 72 23 90 L18 90 Q19 74 14 62 Z'], ['p', 'M10 58 Q4 70 8 82 Q12 72 15 64 Z'], ['c', 50, 22, 5.5], ['p', 'M44 20 Q50 10 56 20 Z'], ['p', 'M44 52 L42 31 L52 27 L58 33 L60 52 Z'], ['s', 'M64 14 Q78 32 64 52', 2.5], ['s', 'M64 14 L54 33 L64 52', 0.8], ['s', 'M54 33 L88 30', 1.4]],
    halo: [['kc', 50, 17, 13, '#ffe7a6'], ['c', 50, 18, 7], ['p', 'M42 16 Q50 6 58 16 L60 26 Q50 22 40 26 Z'], ['p', 'M40 26 Q50 22 60 26 L70 94 L30 94 Z'], ['p', 'M44 40 L56 40 L54 56 L46 56 Z'], ['g', 'M49 30 L51 30 L51 44 L49 44 Z M45 34 L55 34 L55 36 L45 36 Z']],
    roses: [['c', 50, 18, 7], ['k', 'M42 15 Q50 6 58 15 L56 12 L52 8 L50 11 L48 8 L44 12 Z', '#d6aa4a'], ['p', 'M40 26 Q50 22 60 26 L70 94 L30 94 Z'], ['kc', 44, 56, 4, '#b8202e'], ['kc', 52, 54, 4.5, '#c8283a'], ['kc', 58, 60, 4, '#a81c2a'], ['kc', 48, 62, 4, '#c8283a'], ['kc', 55, 66, 3.5, '#b8202e'], ['s', 'M34 50 Q50 72 66 50', 2]],
    strongman: [['c', 50, 16, 8], ['p', 'M34 26 Q50 20 66 26 L72 56 Q70 60 66 60 L64 94 L55 94 L51 64 L49 64 L45 94 L36 94 L34 60 Q30 60 28 56 Z'], ['s', 'M6 30 L94 22', 4], ['c', 6, 30, 3], ['c', 94, 22, 3], ['p', 'M30 30 L24 26 L26 22 L34 26 Z M70 28 L76 22 L78 26 L70 32 Z']],
    shaman: [['p', 'M50 8 Q66 12 66 30 L72 92 L28 92 L34 30 Q34 12 50 8 Z'], ['s', 'M40 14 L30 2 M34 8 L26 8 M60 14 L70 2 M66 8 L74 8', 2.5], ['c', 76, 58, 13], ['g', 'M76 58 m-8 0 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0'], ['gc', 45, 24, 1.8], ['gc', 55, 24, 1.8], ['s', 'M30 60 L18 84', 3]],
    hydra: [['p', 'M24 96 Q20 70 34 62 Q50 54 66 62 Q80 70 76 96 Z'], ['s', 'M38 62 Q20 44 12 22 M44 58 Q32 34 30 10 M50 56 Q48 30 50 4 M56 58 Q68 34 70 10 M62 62 Q80 44 88 22 M34 66 Q12 60 4 44 M66 66 Q88 60 96 44', 5], ['c', 12, 20, 4.5], ['c', 30, 8, 4.5], ['c', 50, 4, 5], ['c', 70, 8, 4.5], ['c', 88, 20, 4.5], ['c', 4, 42, 4], ['c', 96, 42, 4], ['gc', 50, 3, 1.4], ['gc', 30, 7, 1.2], ['gc', 70, 7, 1.2]],
    devil: [['c', 50, 20, 8], ['p', 'M43 15 L36 2 L46 12 Z M57 15 L64 2 L54 12 Z'], ['p', 'M38 28 Q50 24 62 28 L66 60 L58 60 L58 94 L52 94 L50 66 L48 94 L42 94 L42 60 L34 60 Z'], ['s', 'M58 80 Q80 84 82 70 Q84 62 90 64', 2], ['p', 'M88 60 L96 64 L88 68 Z'], ['s', 'M70 96 L70 30', 2.5], ['s', 'M64 30 L64 22 M70 30 L70 20 M76 30 L76 22 M64 30 L76 30', 2], ['gc', 47, 19, 1.5], ['gc', 53, 19, 1.5]],
    fairy: [['g', 'M48 34 Q20 6 6 20 Q14 36 44 42 Z'], ['g', 'M52 34 Q80 6 94 20 Q86 36 56 42 Z'], ['g', 'M46 44 Q22 50 16 68 Q34 66 48 50 Z'], ['g', 'M54 44 Q78 50 84 68 Q66 66 52 50 Z'], ['c', 50, 20, 7], ['p', 'M43 18 Q40 40 36 52 Q42 40 46 26 Z M57 18 Q60 40 64 52 Q58 40 54 26 Z'], ['p', 'M44 28 Q50 25 56 28 L64 96 L36 96 Z']],
    appletree: [['p', 'M46 98 L48 60 Q36 58 22 60 Q8 52 14 38 Q8 24 24 18 Q32 4 50 8 Q68 4 76 18 Q92 24 86 38 Q92 52 78 60 Q64 58 52 60 L54 98 Z'], ['kc', 30, 30, 4, '#f0c040'], ['kc', 50, 22, 4.5, '#f4c84a'], ['kc', 68, 32, 4, '#f0c040'], ['kc', 40, 46, 4, '#e8b636'], ['kc', 62, 48, 4, '#f4c84a'], ['kc', 76, 44, 3.5, '#e8b636']],
    mace: [['s', 'M24 94 L64 34', 5], ['p', 'M56 18 L66 12 L72 20 L80 18 L80 30 L88 34 L82 42 L84 50 L72 50 L66 56 L60 48 L52 46 L56 36 L50 28 Z'], ['gc', 68, 34, 3], ['s', 'M20 98 L28 88', 7]],
    shadoof: [['s', 'M30 96 L30 30', 4], ['s', 'M30 32 L28 26 M30 32 L34 26', 2], ['s', 'M6 58 L92 14', 3], ['s', 'M88 16 L88 64', 1], ['k', 'M84 64 L92 64 L91 72 L85 72 Z', '#3a2a18'], ['k', 'M74 80 L98 80 L96 96 L76 96 Z', '#4a3a28'], ['p', 'M2 54 L12 54 L12 66 L2 66 Z']],
  };

  // ---------- assignment: [motif, palette, terrain, particles] ----------
  const A = {
    scarecrow: ['scarecrow', 'dusk', 'plain', 'none'],
    royal_war_horn: ['horn', 'crown', 'castle', 'none'],
    taltos_fire: ['flames', 'fire', 'ruins', 'embers'],
    carpathian_frost: ['hanged', 'snow', 'village', 'snow'],
    ecsed_marsh_fog: ['tree', 'fog', 'swamp', 'fog'],
    danube_deluge: ['spear', 'storm', 'river', 'rain'],
    clear_puszta_sky: ['shadoof', 'day', 'puszta', 'none'],
    balaton_squall: ['lightning', 'storm', 'sea', 'rain'],
    taltos_brew: ['mushrooms', 'forest', 'forest', 'fireflies'],
    miklos_toldi: ['strongman', 'storm', 'puszta', 'none'],
    prince_csaba_of_the_starry_road: ['cavalry', 'night', 'plain', 'stars'],
    saint_margaret_the_healer: ['halo', 'day', 'castle', 'none'],
    saint_elizabeth_of_the_roses: ['roses', 'dusk', 'castle', 'none'],
    the_hooded_taltos: ['shaman', 'night', 'ruins', 'fog'],
    golden_dragon_of_the_matra: ['dragon', 'fire', 'mountains', 'embers'],
    old_gaspar_monster_hunter: ['sword', 'snow', 'mountains', 'snow'],
    domotor_the_dwarf: ['axe', 'forest', 'hills', 'none'],
    kalman_the_nightdrinker: ['vampire', 'night', 'ruins', 'stars'],
    igric_the_minstrel: ['lute', 'dusk', 'village', 'none'],
    ispan_of_the_broken_oath: ['sword', 'blood', 'castle', 'embers'],
    the_mirror_merchant: ['mirror', 'gold', 'plain', 'none'],
    mirror_shadow: ['wraith', 'night', 'plain', 'fog'],
    grey_cattle: ['cow', 'day', 'puszta', 'none'],
    bull_of_the_puszta: ['beast', 'dusk', 'puszta', 'embers'],
    castle_ballista: ['ballista', 'crown', 'castle', 'none'],
    arpad_stripe_guard: ['arpadsoldier', 'crown', 'castle', 'none'],
    stone_thrower_of_esztergom: ['catapult', 'crown', 'castle', 'embers'],
    cuman_horse_archer: ['horsearcher', 'dusk', 'puszta', 'none'],
    court_astrologer: ['robed', 'night', 'castle', 'stars'],
    hospitaller_surgeon: ['medic', 'crown', 'castle', 'none'],
    palatine_denes: ['banner_arpad', 'crown', 'plain', 'embers'],
    ugrin_csak_warrior_archbishop: ['doublecross', 'dusk', 'hills', 'embers'],
    queen_maria_laskarina: ['bird', 'purple', 'castle', 'stars'],
    duke_coloman_of_slavonia: ['swords', 'crown', 'river', 'embers'],
    saxon_siege_engineer: ['hammer', 'crown', 'castle', 'embers'],
    hedge_witch_of_pilis: ['orb', 'swamp', 'swamp', 'fireflies'],
    levied_peasant: ['spearman', 'fog', 'plain', 'rain'],
    bribed_castellan: ['mask', 'gold', 'castle', 'none'],
    castle_warrior: ['spearman', 'crown', 'castle', 'none'],
    fire_witch_of_szeged: ['orb', 'fire', 'mountains', 'embers'],
    silver_miner_of_selmec: ['dwarf', 'dusk', 'hills', 'none'],
    siege_tower: ['tower', 'crown', 'castle', 'rain'],
    teutonic_knight_of_barcasag: ['crossknight', 'snow', 'mountains', 'snow'],
    spymaster_of_the_royal_court: ['mask', 'night', 'castle', 'none'],
    sorceress_of_obuda: ['orb', 'violet', 'castle', 'stars'],
    wandering_peddler_spy: ['mask', 'fog', 'village', 'fog'],
    trebuchet: ['trebuchet', 'crown', 'castle', 'none'],
    vitez_of_the_border: ['sword', 'forest', 'forest', 'none'],
    dwarf_of_selmec: ['dwarf', 'storm', 'mountains', 'none'],
    palace_scribe: ['orb', 'purple', 'domes', 'none'],
    theodora_the_seeress: ['orb', 'purple', 'domes', 'stars'],
    toxotai_archer: ['archer', 'purple', 'domes', 'none'],
    kataphrakt_commander: ['helm', 'purple', 'domes', 'embers'],
    court_informant: ['mask', 'purple', 'domes', 'none'],
    monastery_healer: ['archer', 'purple', 'domes', 'none'],
    sorceress_of_the_purple_court: ['orb', 'purple', 'domes', 'stars'],
    greek_fire_siphon: ['scorpion', 'fire', 'domes', 'embers'],
    varangian_guard: ['axe', 'purple', 'domes', 'none'],
    andronikos_kontostephanos: ['swords', 'purple', 'mountains', 'none'],
    grand_domestic_john_axouch: ['sun', 'purple', 'domes', 'none'],
    skoutatos_spearman: ['soldier', 'purple', 'domes', 'none'],
    megas_doux_of_the_fleet: ['crown', 'purple', 'domes', 'none'],
    kataphrakt_rider: ['cavalry', 'purple', 'domes', 'none'],
    psiloi_slinger: ['archer', 'purple', 'domes', 'none'],
    palace_assassin: ['sword', 'purple', 'domes', 'none'],
    toxotes_captain: ['archer', 'purple', 'domes', 'none'],
    old_mangonel: ['catapult', 'swamp', 'domes', 'fog'],
    imperial_ambassador: ['mask', 'purple', 'domes', 'none'],
    imperial_siege_engineer: ['hammer', 'purple', 'domes', 'none'],
    engine_wright: ['medic', 'purple', 'domes', 'none'],
    spymaster_of_the_purple_chamber: ['mask', 'blood', 'domes', 'none'],
    logothete: ['robed', 'purple', 'domes', 'none'],
    strategos_nikephoros: ['eagle2', 'purple', 'domes', 'none'],
    ice_mage_of_the_pontus: ['orb', 'ice', 'mountains', 'snow'],
    agent_of_the_logothete: ['mask', 'night', 'domes', 'none'],
    akritai_borderer: ['spearman', 'purple', 'domes', 'none'],
    young_kaballarios: ['cavalry', 'purple', 'domes', 'none'],
    greek_fire_grenadier: ['scorpion', 'fire', 'domes', 'embers'],
    cave_spider: ['spider', 'swamp', 'swamp', 'fog'],
    brood_mother_spider: ['spider', 'blood', 'swamp', 'fog'],
    liderc_hatchling: ['goblin', 'swamp', 'village', 'fog'],
    storm_harpy: ['bird', 'violet', 'cliffs', 'none'],
    basilisk_chick: ['bird', 'swamp', 'ruins', 'none'],
    boszorkany_the_brewer: ['hag', 'swamp', 'swamp', 'fog'],
    boszorkany_the_spinner: ['hag', 'blood', 'swamp', 'fog'],
    boszorkany_the_whisperer: ['hag', 'night', 'swamp', 'fog'],
    the_undead_ispan: ['wraith', 'blood', 'ruins', 'fog'],
    stone_giant_of_the_matra: ['golem', 'storm', 'mountains', 'none'],
    marsh_beetle: ['spider', 'forest', 'forest', 'none'],
    the_fene: ['beast', 'night', 'forest', 'fog'],
    fire_liderc: ['golem', 'fire', 'ruins', 'embers'],
    fog_wraith: ['wraith', 'fog', 'swamp', 'fog'],
    sarkanykigyo: ['dragon', 'storm', 'mountains', 'none'],
    the_mumus: ['beast', 'blood', 'ruins', 'none'],
    church_gargoyle: ['golem', 'night', 'castle', 'none'],
    grave_ghoul: ['ghoul', 'blood', 'ruins', 'none'],
    graveyard_hag: ['hag', 'night', 'ruins', 'fog'],
    carpathian_griff: ['bird', 'day', 'mountains', 'none'],
    harpy: ['bird', 'dusk', 'cliffs', 'none'],
    frost_giant_of_the_tatras: ['golem', 'ice', 'mountains', 'snow'],
    the_seven_headed_dragon: ['hydra', 'blood', 'mountains', 'embers'],
    wyrm_of_the_tisza: ['tentacles', 'swamp', 'sea', 'fog'],
    old_man_of_the_woods: ['tree', 'forest', 'forest', 'fog'],
    mano: ['goblin', 'forest', 'forest', 'none'],
    dogvesz_the_plague_maiden: ['hag', 'swamp', 'village', 'fog'],
    nightdrinker_lamia: ['vampire', 'blood', 'castle', 'none'],
    nightdrinker_strigoi: ['vampire', 'night', 'ruins', 'none'],
    nightdrinker_upir: ['vampire', 'blood', 'ruins', 'fog'],
    nightdrinker_mora: ['vampire', 'night', 'castle', 'fog'],
    nightdrinker_vrykolakas: ['vampire', 'blood', 'ruins', 'embers'],
    farkasember: ['wolf', 'night', 'forest', 'stars'],
    lesser_dragon: ['dragon', 'dusk', 'cliffs', 'none'],
    bog_toad_king: ['beast', 'swamp', 'swamp', 'fog'],
    captain_of_the_matra_dwarves: ['dwarf', 'forest', 'mountains', 'none'],
    fairy_pathfinder: ['archer', 'forest', 'forest', 'fireflies'],
    chieftain_of_the_bukk_dwarves: ['dwarf', 'dusk', 'hills', 'none'],
    tunder_archer: ['archer', 'forest', 'forest', 'none'],
    tunder_scout: ['archer', 'day', 'forest', 'none'],
    bukk_dwarf_skirmisher: ['dwarf', 'forest', 'hills', 'none'],
    hajnal_lady_of_the_silver_birches: ['appletree', 'forest', 'forest', 'fireflies'],
    tunder_skirmisher: ['archer', 'forest', 'ruins', 'none'],
    elder_of_the_fairy_garden: ['leaf', 'forest', 'ruins', 'fireflies'],
    fuvesasszony_herb_wife: ['medic', 'forest', 'forest', 'fireflies'],
    bakony_outlaw: ['dwarf', 'night', 'forest', 'none'],
    fairy_seeress: ['orb', 'forest', 'ruins', 'fireflies'],
    csongor_the_wanderer: ['leaf', 'forest', 'forest', 'none'],
    old_gyula_outlaw_lord: ['swords', 'forest', 'ruins', 'none'],
    mountain_dwarf_defender: ['shieldaxe', 'storm', 'mountains', 'none'],
    huntress_rozalia: ['archer', 'dusk', 'forest', 'none'],
    fairy_apprentice: ['archer', 'night', 'forest', 'stars'],
    tunde_the_dragon_fairy: ['dragon', 'gold', 'mountains', 'none'],
    fairy_bowmaiden: ['archer', 'forest', 'forest', 'fireflies'],
    greenwood_recruit: ['archer', 'forest', 'hills', 'none'],
    greenwood_veteran: ['soldier', 'forest', 'forest', 'none'],
    outlaw_captain: ['leaf', 'dusk', 'forest', 'none'],
    dwarven_fire_mortar: ['catapult', 'forest', 'ruins', 'embers'],
    bear_kin_warrior: ['axe', 'violet', 'cliffs', 'none'],
    young_bear_kin: ['axe', 'sea', 'cliffs', 'none'],
    clan_wise_woman: ['medic', 'violet', 'river', 'none'],
    bulcsu_the_blue_eyed: ['axe', 'sea', 'cliffs', 'none'],
    reka_shield_queen: ['shieldaxe', 'violet', 'river', 'none'],
    tisza_clan_warrior: ['soldier', 'sea', 'cliffs', 'none'],
    kende_clan_archer: ['archer', 'sea', 'cliffs', 'none'],
    danube_fire_raider: ['flames', 'sea', 'river', 'embers'],
    shieldmaiden_of_reka: ['shieldaxe', 'storm', 'river', 'rain'],
    regos_singer: ['lute', 'violet', 'cliffs', 'none'],
    clan_smith_of_vasvar: ['hammer', 'fire', 'cliffs', 'embers'],
    elder_kurszan: ['crown', 'sea', 'cliffs', 'none'],
    river_horn_blower: ['horn', 'violet', 'cliffs', 'none'],
    old_taltos_of_the_clans: ['mushrooms', 'violet', 'cliffs', 'fireflies'],
    almos_the_dream_born: ['axe', 'ice', 'mountains', 'snow'],
    shipwright_hollo: ['ship', 'storm', 'river', 'rain'],
    turul_chick: ['turulchick', 'sea', 'river', 'none'],
    light_river_boat: ['ship', 'sea', 'river', 'none'],
    madman_of_the_reeds: ['axe', 'blood', 'cliffs', 'none'],
    kende_the_bear_father: ['bear', 'violet', 'cliffs', 'none'],
    young_chieftain_taksony: ['crown', 'violet', 'cliffs', 'none'],
    haunted_szabolcs: ['sword', 'storm', 'cliffs', 'rain'],
    danube_war_galley: ['ship', 'violet', 'river', 'none'],
    the_great_turul: ['turul', 'storm', 'river', 'none'],
    bear_of_the_danube: ['bear', 'blood', 'cliffs', 'embers'],
    young_danube_bear: ['bear', 'violet', 'cliffs', 'none'],
  };

  const FAC_DEF = { CR: ['soldier', 'crown', 'castle'], GE: ['soldier', 'purple', 'domes'], FF: ['archer', 'forest', 'forest'], NB: ['beast', 'swamp', 'swamp'], RC: ['axe', 'violet', 'river'], NE: ['sword', 'dusk', 'plain'] };
  const LEAD_ART = {'cr_coloman_the_learned_keeper_of_the_mists': ['holycrown', 'fog', 'castle', 'fog'], 'cr_saint_ladislaus_the_knight_king': ['cavalry', 'crown', 'hills', 'none'], 'cr_bela_iv_the_second_founder': ['tower', 'dusk', 'castle', 'embers'], 'cr_charles_robert_breaker_of_oligarchs': ['banner_arpad', 'crown', 'castle', 'none'], 'cr_louis_the_great_lord_of_three_seas': ['holycrown', 'sea', 'river', 'none'], 'ge_alexios_bela_despot_of_two_crowns': ['doublecross', 'purple', 'domes', 'none'], 'ge_anna_komnene_the_chronicler': ['orb', 'purple', 'domes', 'stars'], 'ge_manuel_i_komnenos_the_basileus': ['eagle2', 'purple', 'domes', 'none'], 'ge_andronikos_komnenos_the_usurper': ['mask', 'purple', 'domes', 'none'], 'ge_irene_piroska_founder_of_the_pantokrator': ['halo', 'purple', 'domes', 'none'], 'nb_vasorru_baba_mother_of_the_brood': ['hag', 'blood', 'swamp', 'fog'], 'nb_the_liderc_lord_bringer_of_death': ['flames', 'night', 'swamp', 'embers'], 'nb_the_dragon_king_devourer_of_realms': ['hydra', 'fire', 'mountains', 'embers'], 'nb_the_garaboncias_rider_of_storms': ['dragon', 'storm', 'mountains', 'rain'], 'nb_the_ordog_the_deceiver': ['devil', 'blood', 'ruins', 'embers'], 'ff_tunder_ilona_queen_of_the_fairy_garden': ['fairy', 'forest', 'forest', 'fireflies'], 'ff_tunder_ilona_the_radiant': ['fairy', 'night', 'ruins', 'stars'], 'ff_tunder_ilona_keeper_of_the_golden_apples': ['appletree', 'dusk', 'forest', 'fireflies'], 'ff_tunder_ilona_of_the_winter_moon': ['fairy', 'ice', 'forest', 'snow'], 'ff_tunder_ilona_hope_of_the_greenwood': ['leaf', 'forest', 'forest', 'fireflies'], 'rc_botond_of_the_iron_mace': ['mace', 'storm', 'domes', 'rain'], 'rc_lehel_of_the_horn': ['horn', 'sea', 'river', 'none']};

  // ---------- terrain ----------
  function ridge(r, y0, amp, n, H) { let d = `M0 ${H} L0 ${y0}`; for (let i = 1; i <= n; i++) { const x = i / n * 200; d += ` L${x.toFixed(1)} ${(y0 - r() * amp).toFixed(1)}`; } return d + ` L200 ${H} Z`; }
  function smooth(r, y0, amp, n, H) { let d = `M0 ${H} L0 ${y0}`; let px = 0, py = y0; for (let i = 1; i <= n; i++) { const x = i / n * 200, y = y0 - r() * amp; d += ` Q${((px + x) / 2).toFixed(1)} ${(Math.min(py, y) - amp * .3).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)}`; px = x; py = y; } return d + ` L200 ${H} Z`; }
  function trees(r, y0, n, h, H) { let d = `M0 ${H} L0 ${y0}`; for (let i = 0; i < n; i++) { const x = i / n * 200 + r() * 6, th = h * (0.6 + r() * .6); d += ` L${x} ${y0} L${x + 5} ${y0 - th} L${x + 10} ${y0}`; } return d + ` L200 ${y0} L200 ${H} Z`; }
  function castle(r, y0, H) { let d = `M0 ${H} L0 ${y0}`; let x = 0; while (x < 200) { const w = 10 + r() * 22, h = 10 + r() * 34, tower = r() < .45; d += ` L${x} ${y0 - h}`; if (tower) { for (let k = 0; k < 3; k++) { d += ` L${x + k * w / 3} ${y0 - h - 5} L${x + (k + .5) * w / 3} ${y0 - h - 5} L${x + (k + .5) * w / 3} ${y0 - h}`; } } d += ` L${x + w} ${y0 - h}`; x += w; } return d + ` L200 ${y0} L200 ${H} Z`; }
  function huts(r, y0, H) { let d = `M0 ${H} L0 ${y0}`; let x = 0; while (x < 200) { const w = 16 + r() * 20, h = 8 + r() * 8; d += ` L${x} ${y0} L${x} ${y0 - h} L${x + w / 2} ${y0 - h - w * .45} L${x + w} ${y0 - h} L${x + w} ${y0}`; x += w + r() * 18; } return d + ` L200 ${y0} L200 ${H} Z`; }
  function deadTrees(r, y0) { let d = ''; for (let i = 0; i < 3; i++) { const x = 15 + r() * 170, h = 40 + r() * 50; d += `M${x} ${y0} L${x + 1} ${y0 - h} M${x + 1} ${y0 - h * .6} L${x + 14 * (r() - .3)} ${y0 - h * .9} M${x + 1} ${y0 - h * .4} L${x - 12} ${y0 - h * .7} `; } return d; }
  function terrain(type, r, p) {
    const H = 260; const far = p[3], near = p[4];
    let out = '';
    const L = (d, c, op = 1) => `<path d="${d}" fill="${c}" opacity="${op}"/>`;
    switch (type) {
      case 'mountains': out += L(ridge(r, 170, 70, 9, H), far, .9) + L(ridge(r, 205, 40, 12, H), near); break;
      case 'hills': out += L(smooth(r, 185, 35, 4, H), far, .9) + L(smooth(r, 215, 25, 5, H), near); break;
      case 'forest': out += L(trees(r, 185, 22, 40, H), far, .85) + L(trees(r, 220, 14, 55, H), near); break;
      case 'castle': out += L(smooth(r, 200, 20, 3, H), far, .7) + L(castle(r, 190, H), far, .95) + L(smooth(r, 225, 12, 4, H), near); break;
      case 'village': out += L(smooth(r, 200, 18, 4, H), far, .8) + L(huts(r, 212, H), near, .95) + L(`M0 ${H} L0 222 L200 222 L200 ${H} Z`, near); break;
      case 'sea': out += L(ridge(r, 175, 30, 6, H), far, .75) + `<path d="M0 205 Q25 198 50 205 T100 205 T150 205 T200 205 L200 260 L0 260 Z" fill="${near}"/><path d="M0 218 Q25 212 50 218 T100 218 T150 218 T200 218" stroke="${p[5]}" stroke-opacity=".25" fill="none" stroke-width="1.2"/>`; break;
      case 'cliffs': out += L(`M0 ${H} L0 150 L30 160 L48 140 L70 175 L70 ${H} Z`, far, .9) + `<path d="M70 205 Q100 198 130 205 T200 205 L200 260 L70 260 Z" fill="${far}" opacity=".7"/>` + L(`M0 ${H} L0 205 L60 200 L95 222 L130 ${H} Z`, near); break;
      case 'swamp': out += L(trees(r, 190, 16, 30, H), far, .7) + `<path d="${deadTrees(r, 215)}" stroke="${near}" stroke-width="3" fill="none"/>` + L(`M0 ${H} L0 214 Q60 206 120 216 T200 212 L200 ${H} Z`, near); break;
      case 'ruins': out += L(smooth(r, 205, 20, 3, H), far, .8) + L(`M20 ${H} L20 150 L34 150 L34 170 L44 170 L44 ${H} Z M150 ${H} L150 130 L156 126 L166 132 L166 ${H} Z M176 ${H} L176 170 L196 170 L196 ${H} Z`, far, .95) + L(smooth(r, 228, 10, 4, H), near); break;
      case 'domes': { let d = ''; let x = -6; while (x < 206) { const w = 14 + r() * 18, h = 14 + r() * 26; d += `M${x} 210 L${x} ${190 - h} Q${x + w / 2} ${190 - h - w * .7} ${x + w} ${190 - h} L${x + w} 210 Z `; if (r() < .35) d += `M${x + w / 2 - 1.5} ${190 - h - w * .7} L${x + w / 2 - 1.5} ${178 - h - w * .7} L${x + w / 2 + 1.5} ${178 - h - w * .7} L${x + w / 2 + 1.5} ${190 - h - w * .7} Z `; x += w + r() * 10; } out += L(smooth(r, 200, 14, 3, H), far, .6) + L(d, far, .95) + `<path d="M0 214 Q50 208 100 214 T200 214 L200 260 L0 260 Z" fill="${near}"/>`; break; }
      case 'river': { let reeds = ''; for (let i = 0; i < 26; i++) { const x = r() * 200, h = 10 + r() * 22; reeds += `M${x.toFixed(1)} 232 Q${(x + 3).toFixed(1)} ${232 - h / 2} ${(x + 1 + r() * 6).toFixed(1)} ${(232 - h).toFixed(1)} `; } out += L(smooth(r, 186, 22, 4, H), far, .8) + `<path d="M0 200 Q60 194 120 202 T200 200 L200 230 L0 230 Z" fill="${p[2]}" opacity=".35"/><path d="M0 210 Q50 206 100 212 T200 208" stroke="${p[5]}" stroke-opacity=".3" fill="none"/>` + L(`M0 ${H} L0 228 Q80 222 200 230 L200 ${H} Z`, near) + `<path d="${reeds}" stroke="${near}" stroke-width="1.6" fill="none"/>`; break; }
      case 'puszta': out += L(`M0 ${H} L0 214 Q100 210 200 214 L200 ${H} Z`, far, .8) + L(huts(r, 212, H).replace(/L200 \d+ L200/, 'L200 212 L200'), far, .5) + `<path d="M150 214 L150 176 M150 180 L118 160 M120 161 L120 178" stroke="${near}" stroke-width="2" fill="none"/>` + L(`M0 ${H} L0 226 Q100 220 200 226 L200 ${H} Z`, near); break;
      default: out += L(smooth(r, 210, 12, 3, H), far, .8) + L(smooth(r, 228, 8, 4, H), near);
    }
    return out;
  }
  function particles(type, r, p) {
    let s = '';
    if (type === 'snow') for (let i = 0; i < 60; i++) s += `<circle cx="${(r() * 200).toFixed(1)}" cy="${(r() * 260).toFixed(1)}" r="${(0.6 + r() * 1.8).toFixed(1)}" fill="#fff" opacity="${(0.4 + r() * .6).toFixed(2)}"/>`;
    if (type === 'rain') { let d = ''; for (let i = 0; i < 90; i++) { const x = r() * 220, y = r() * 260; d += `M${x.toFixed(1)} ${y.toFixed(1)} l-5 16 `; } s += `<path d="${d}" stroke="${p[5]}" stroke-opacity=".35" stroke-width=".8"/>`; }
    if (type === 'embers') for (let i = 0; i < 40; i++) s += `<circle cx="${(r() * 200).toFixed(1)}" cy="${(80 + r() * 180).toFixed(1)}" r="${(0.5 + r() * 1.6).toFixed(1)}" fill="${p[5]}" opacity="${(0.4 + r() * .6).toFixed(2)}" filter="url(#bl1)"/>`;
    if (type === 'stars') for (let i = 0; i < 50; i++) s += `<circle cx="${(r() * 200).toFixed(1)}" cy="${(r() * 120).toFixed(1)}" r="${(0.3 + r() * 0.9).toFixed(1)}" fill="#fff" opacity="${(0.3 + r() * .7).toFixed(2)}"/>`;
    if (type === 'fireflies') for (let i = 0; i < 22; i++) s += `<circle cx="${(r() * 200).toFixed(1)}" cy="${(120 + r() * 130).toFixed(1)}" r="${(1 + r() * 1.5).toFixed(1)}" fill="${p[5]}" filter="url(#bl1)"/>`;
    if (type === 'fog') for (let i = 0; i < 5; i++) s += `<ellipse cx="${(r() * 200).toFixed(1)}" cy="${(150 + r() * 100).toFixed(1)}" rx="${(60 + r() * 60).toFixed(1)}" ry="${(8 + r() * 10).toFixed(1)}" fill="${p[5]}" opacity=".18" filter="url(#bl6)"/>`;
    return s;
  }
  let CLIP = 0;
  function prims(list, mode, light, dark) {
    return list.map(pr => {
      const k = pr[0];
      if (mode === 'glow') { if (k === 'g') return `<path d="${pr[1]}" fill="${light}"/>`; if (k === 'gc') return `<circle cx="${pr[1]}" cy="${pr[2]}" r="${pr[3]}" fill="${light}"/>`; return ''; }
      const col = mode === 'rim' ? light : dark;
      const sw = mode === 'rim' ? 3 : 0;
      if (k === 'p') return `<path d="${pr[1]}" fill="${col}" stroke="${col}" stroke-width="${sw}" stroke-linejoin="round"/>`;
      if (k === 's') return `<path d="${pr[1]}" fill="none" stroke="${col}" stroke-width="${pr[2] + sw}" stroke-linecap="round" stroke-linejoin="round"/>`;
      if (k === 'c') return `<circle cx="${pr[1]}" cy="${pr[2]}" r="${pr[3] + sw / 2}" fill="${col}"/>`;
      if (k === 'e') return `<ellipse cx="${pr[1]}" cy="${pr[2]}" rx="${pr[3] + sw / 2}" ry="${pr[4] + sw / 2}" transform="rotate(${pr[5]} ${pr[1]} ${pr[2]})" fill="${col}"/>`;
      if (k === 'k') return mode === 'rim' ? `<path d="${pr[1]}" fill="${light}" stroke="${light}" stroke-width="3"/>` : `<path d="${pr[1]}" fill="${pr[2]}"/><path d="${pr[1]}" fill="url(#shade)"/>`;
      if (k === 'kc') return mode === 'rim' ? `<circle cx="${pr[1]}" cy="${pr[2]}" r="${pr[3] + 1.5}" fill="${light}"/>` : `<circle cx="${pr[1]}" cy="${pr[2]}" r="${pr[3]}" fill="${pr[4]}"/>`;
      if (k === 'st') { if (mode === 'rim') return `<path d="${pr[1]}" fill="${light}" stroke="${light}" stroke-width="3"/>`; const id = 'clp' + (CLIP++); let r = ''; const hh = pr[5] / pr[6]; for (let q = 0; q < pr[6]; q++) r += `<rect x="${pr[2]}" y="${pr[3] + q * hh}" width="${pr[4]}" height="${hh + .3}" fill="${q % 2 ? '#e2dacb' : '#a8222c'}"/>`; return `<clipPath id="${id}"><path d="${pr[1]}"/></clipPath><g clip-path="url(#${id})">${r}<path d="${pr[1]}" fill="url(#shade)"/></g>`; }
      if (mode === 'body' && k === 'g') return `<path d="${pr[1]}" fill="${col}"/>`;
      if (mode === 'body' && k === 'gc') return `<circle cx="${pr[1]}" cy="${pr[2]}" r="${pr[3]}" fill="${col}"/>`;
      return '';
    }).join('');
  }
  function banners(r, fac) {
    if (fac !== 'CR') return '';
    let o = ''; for (let k = 0; k < 2; k++) { const x = 18 + k * 150 + r() * 14, y = 150 + r() * 20, id = 'bn' + (CLIP++); o += `<path d="M${x} ${y + 60} L${x} ${y}" stroke="#1a1210" stroke-width="1.6"/><clipPath id="${id}"><path d="M${x} ${y + 1} L${x + 22} ${y + 3} L${x + 17} ${y + 9} L${x + 22} ${y + 15} L${x} ${y + 14} Z"/></clipPath><g clip-path="url(#${id})" opacity=".85">${[0, 1, 2, 3, 4, 5, 6, 7].map(q => `<rect x="${x}" y="${y + 1 + q * 1.8}" width="24" height="1.9" fill="${q % 2 ? '#d8d0c0' : '#9a1f28'}"/>`).join('')}</g>`; }
    return o;
  }
  function compose(key, spec, opts = {}) {
    const [motif, palK, terr, part] = spec; const p = PAL[palK] || PAL.dusk; const r = rng(hash(key));
    const mot = M[motif] || M.sword;
    const sunX = 40 + r() * 120, sunY = 70 + r() * 60;
    const scale = 1.5, tx = 100 - 50 * scale, ty = 214 - 100 * scale;
    const T = `translate(${tx.toFixed(1)} ${ty.toFixed(1)}) scale(${scale})`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 260" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p[0]}"/><stop offset=".55" stop-color="${p[1]}"/><stop offset=".85" stop-color="${p[2]}"/></linearGradient>
<radialGradient id="sun" cx="${sunX}" cy="${sunY}" r="110" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="${p[5]}" stop-opacity=".9"/><stop offset=".25" stop-color="${p[2]}" stop-opacity=".45"/><stop offset="1" stop-color="${p[2]}" stop-opacity="0"/></radialGradient>
<linearGradient id="shade" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".12"/><stop offset=".6" stop-color="#000" stop-opacity=".25"/><stop offset="1" stop-color="#000" stop-opacity=".6"/></linearGradient>
<radialGradient id="vig" cx="100" cy="120" r="170" gradientUnits="userSpaceOnUse"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".75"/></radialGradient>
<filter id="bl1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1"/></filter>
<filter id="bl3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.4"/></filter>
<filter id="bl6" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6"/></filter>
<filter id="grain"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="${hash(key) % 97}"/><feColorMatrix values="0 0 0 0 .5  0 0 0 0 .45  0 0 0 0 .4  0 0 0 .55 0"/></filter>
<filter id="paint"><feTurbulence type="fractalNoise" baseFrequency=".035" numOctaves="3" seed="${hash(key) % 89}"/><feDisplacementMap in="SourceGraphic" scale="7"/></filter></defs>
<rect width="200" height="260" fill="url(#sky)"/><rect width="200" height="260" fill="url(#sun)"/>
<g filter="url(#paint)">${terrain(terr, r, p)}</g>
${banners(r, opts.fac)}<ellipse cx="100" cy="${ty + 60 * scale}" rx="70" ry="80" fill="${p[5]}" opacity="${opts.scene ? .28 : .16}" filter="url(#bl6)"/>
${opts.scene ? '' : `<g transform="${T}"><g filter="url(#bl3)" opacity=".85">${prims(mot, 'rim', p[5], p[6])}</g>${prims(mot, 'body', p[5], p[6])}<g filter="url(#bl1)">${prims(mot, 'glow', p[5], p[6])}</g>${prims(mot, 'glow', p[5], p[6])}</g>`}
${particles(part, r, p)}
<rect width="200" height="260" fill="url(#vig)"/><rect width="200" height="260" filter="url(#grain)" opacity=".35"/></svg>`;
  }
  const cache = new Map();
  function url(key, spec, opts) { if (cache.has(key)) return cache.get(key); const u = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(compose(key, spec, opts)); cache.set(key, u); return u; }
  return {
    card(d) { const spec = A[d.id] || (() => { const f = FAC_DEF[d.f] || FAC_DEF.NE; const m = d.r === 'ranged' ? 'archer' : d.r === 'siege' ? 'catapult' : f[0]; return [m, f[1], f[2], 'none']; })(); return url(d.id, spec); },
    leader(L) { return url('L_' + L.id, LEAD_ART[L.id] || ['crown', 'dusk', 'castle', 'none']); },
    has: id => !!A[id],
    scene(d) { const spec = A[d.id] || LEAD_ART[d.id] || (() => { const f = FAC_DEF[d.f] || FAC_DEF.NE; return ['sword', f[1], f[2], 'none']; })(); return url('S_' + d.id, spec, { scene: true, fac: d.f }); },
  };
})();
