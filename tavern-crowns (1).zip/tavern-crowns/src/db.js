// Tavern Crowns card database (original world; rules slots only)
const CARD_DATA=[
{
"id": "scarecrow",
"n": "Scarecrow",
"f": "NE",
"s": 0,
"r": "special",
"h": 0,
"a": [
"decoy"
],
"c": 3,
"g": "",
"d": "core",
"p": "a ragged scarecrow in a wheat field at dusk, wearing a dented kettle helmet and a sack hood"
},
{
"id": "royal_war_horn",
"n": "Royal War Horn",
"f": "NE",
"s": 0,
"r": "special",
"h": 0,
"a": [
"horn"
],
"c": 3,
"g": "",
"d": "core",
"p": "a soldier blowing a huge carved aurochs war horn on castle walls, red-and-silver striped pennant"
},
{
"id": "taltos_fire",
"n": "Táltos Fire",
"f": "NE",
"s": 0,
"r": "special",
"h": 0,
"a": [
"scorch"
],
"c": 3,
"g": "",
"d": "core",
"p": "a pillar of shamanic fire bursting from the earth, burning warriors to ash, embers swirling"
},
{
"id": "carpathian_frost",
"n": "Carpathian Frost",
"f": "NE",
"s": 0,
"r": "weather",
"h": 0,
"a": [
"weather_frost"
],
"c": 3,
"g": "",
"d": "core",
"p": "a frozen Carpathian mountain village, hoarfrost on thatched roofs, icicles, snow in the wind"
},
{
"id": "ecsed_marsh_fog",
"n": "Ecsed Marsh Fog",
"f": "NE",
"s": 0,
"r": "weather",
"h": 0,
"a": [
"weather_fog"
],
"c": 3,
"g": "",
"d": "core",
"p": "thick fog over the Ecsed marsh, dead trees and glowing eyes in the mist"
},
{
"id": "danube_deluge",
"n": "Danube Deluge",
"f": "NE",
"s": 0,
"r": "weather",
"h": 0,
"a": [
"weather_rain"
],
"c": 2,
"g": "",
"d": "core",
"p": "torrential rain over a muddy battlefield by the Danube, a spear stuck in the mud"
},
{
"id": "clear_puszta_sky",
"n": "Clear Puszta Sky",
"f": "NE",
"s": 0,
"r": "weather",
"h": 0,
"a": [
"weather_clear"
],
"c": 2,
"g": "",
"d": "core",
"p": "sunlight breaking over the great Hungarian plain, a shadoof well and white-walled village"
},
{
"id": "balaton_squall",
"n": "Balaton Squall",
"f": "NE",
"s": 0,
"r": "weather",
"h": 0,
"a": [
"weather_storm"
],
"c": 3,
"g": "",
"d": "river",
"p": "a violent storm on Lake Balaton, lightning, huge waves tossing a river galley"
},
{
"id": "miklos_toldi",
"n": "Miklós Toldi",
"f": "NE",
"s": 15,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a giant 14th-century Hungarian strongman knight with a massive pole and a sword, broad shoulders, plain gambeson"
},
{
"id": "prince_csaba_of_the_starry_road",
"n": "Prince Csaba of the Starry Road",
"f": "NE",
"s": 15,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a young royal horseman riding down the Milky Way, starlight armour, sword raised"
},
{
"id": "saint_margaret_the_healer",
"n": "Saint Margaret the Healer",
"f": "NE",
"s": 7,
"r": "ranged",
"h": 1,
"a": [
"medic"
],
"c": 1,
"g": "",
"d": "core",
"p": "a 13th-century Dominican nun princess healing a wounded soldier with soft golden light"
},
{
"id": "saint_elizabeth_of_the_roses",
"n": "Saint Elizabeth of the Roses",
"f": "NE",
"s": 7,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a young medieval princess whose apron of bread turns into red roses, castle in the background"
},
{
"id": "the_hooded_taltos",
"n": "The Hooded Táltos",
"f": "NE",
"s": 0,
"r": "close",
"h": 1,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a hooded táltos shaman with a drum and an antler headdress hidden in smoke, eyes glowing"
},
{
"id": "golden_dragon_of_the_matra",
"n": "Golden Dragon of the Mátra",
"f": "NE",
"s": 7,
"r": "close",
"h": 0,
"a": [
"scorch_close"
],
"c": 1,
"g": "",
"d": "core",
"p": "a golden dragon spreading wings over the Mátra mountains, breathing fire"
},
{
"id": "old_gaspar_monster_hunter",
"n": "Old Gáspár, Monster-Hunter",
"f": "NE",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a grizzled old monster hunter with a lantern and a silver-edged sword in a snowy forest"
},
{
"id": "domotor_the_dwarf",
"n": "Dömötör the Dwarf",
"f": "NE",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a cheerful red-bearded dwarf with a two-handed axe and a tankard"
},
{
"id": "kalman_the_nightdrinker",
"n": "Kálmán the Nightdrinker",
"f": "NE",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a gentle pale scholar-vampire in a dark coat reading in a candlelit cellar of herbs"
},
{
"id": "igric_the_minstrel",
"n": "Igric the Minstrel",
"f": "NE",
"s": 2,
"r": "close",
"h": 0,
"a": [
"horn"
],
"c": 1,
"g": "",
"d": "core",
"p": "a flamboyant medieval minstrel (igric) playing a lute in a tavern"
},
{
"id": "ispan_of_the_broken_oath",
"n": "Ispán of the Broken Oath",
"f": "NE",
"s": 6,
"r": "agile",
"h": 0,
"a": [
"agile",
"morale"
],
"c": 1,
"g": "",
"d": "mirror",
"p": "a cursed noble count (ispán) with a sabre and a scar, unkillable, in a burning manor"
},
{
"id": "the_mirror_merchant",
"n": "The Mirror Merchant",
"f": "NE",
"s": 2,
"r": "siege",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "mirror",
"d": "mirror",
"p": "a smiling travelling merchant holding a silver hand mirror, too-perfect smile, crossroads at night"
},
{
"id": "mirror_shadow",
"n": "Mirror Shadow",
"f": "NE",
"s": 4,
"r": "ranged",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "mirror",
"d": "mirror",
"p": "a shadow creature crawling out of a broken mirror"
},
{
"id": "grey_cattle",
"n": "Grey Cattle",
"f": "NE",
"s": 0,
"r": "ranged",
"h": 0,
"a": [
"summon_avenger"
],
"c": 1,
"g": "cattle",
"d": "mirror",
"p": "a long-horned Hungarian grey cattle on the puszta"
},
{
"id": "bull_of_the_puszta",
"n": "Bull of the Puszta",
"f": "NE",
"s": 8,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "cattle",
"d": "mirror",
"t": 1,
"p": "an enormous enraged long-horned grey bull charging, steam from its nostrils"
},
{
"id": "castle_ballista",
"n": "Castle Ballista",
"f": "CR",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a heavy ballista on a stone castle tower"
},
{
"id": "arpad_stripe_guard",
"n": "Árpád-Stripe Guard",
"f": "CR",
"s": 4,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "arpad_guard",
"d": "core",
"p": "a royal guard with a shield painted with red and silver horizontal stripes"
},
{
"id": "stone_thrower_of_esztergom",
"n": "Stone-Thrower of Esztergom",
"f": "CR",
"s": 8,
"r": "siege",
"h": 0,
"a": [
"bond"
],
"c": 2,
"g": "stone_thrower",
"d": "core",
"p": "a wooden catapult hurling a stone, Esztergom castle on a hill"
},
{
"id": "cuman_horse_archer",
"n": "Cuman Horse Archer",
"f": "CR",
"s": 5,
"r": "ranged",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "cuman_archers",
"d": "core",
"p": "a Cuman horse archer with a composite bow, felt hat, galloping on the plain"
},
{
"id": "court_astrologer",
"n": "Court Astrologer",
"f": "CR",
"s": 6,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a royal astrologer with an astrolabe on a tower at night"
},
{
"id": "hospitaller_surgeon",
"n": "Hospitaller Surgeon",
"f": "CR",
"s": 5,
"r": "siege",
"h": 0,
"a": [
"medic"
],
"c": 1,
"g": "",
"d": "core",
"p": "a Knights Hospitaller field surgeon in a black mantle with a white cross"
},
{
"id": "palatine_denes",
"n": "Palatine Dénes",
"f": "CR",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "the palatine of the kingdom in full mail, holding a mace, 1241"
},
{
"id": "ugrin_csak_warrior_archbishop",
"n": "Ugrin Csák, Warrior-Archbishop",
"f": "CR",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a warrior archbishop in mitre and mail, leading knights into battle"
},
{
"id": "queen_maria_laskarina",
"n": "Queen Maria Laskarina",
"f": "CR",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine-born Hungarian queen in a jewelled crown, a falcon on her arm"
},
{
"id": "duke_coloman_of_slavonia",
"n": "Duke Coloman of Slavonia",
"f": "CR",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a young royal duke defending a bridge with a sword, wounded but defiant"
},
{
"id": "saxon_siege_engineer",
"n": "Saxon Siege Engineer",
"f": "CR",
"s": 1,
"r": "siege",
"h": 0,
"a": [
"morale"
],
"c": 3,
"g": "",
"d": "core",
"p": "a Transylvanian Saxon engineer with a hammer and plans, building a siege engine"
},
{
"id": "hedge_witch_of_pilis",
"n": "Hedge-Witch of Pilis",
"f": "CR",
"s": 5,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a hedge witch in the Pilis hills holding a glowing green orb"
},
{
"id": "levied_peasant",
"n": "Levied Peasant",
"f": "CR",
"s": 1,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "levy",
"d": "core",
"p": "a frightened peasant levy with a pitchfork and a wicker shield"
},
{
"id": "bribed_castellan",
"n": "Bribed Castellan",
"f": "CR",
"s": 5,
"r": "close",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a corrupt castle steward counting gold coins by candlelight"
},
{
"id": "castle_warrior",
"n": "Castle Warrior",
"f": "CR",
"s": 1,
"r": "close",
"h": 0,
"a": [],
"c": 2,
"g": "",
"d": "core",
"p": "a castle warrior (várjobbágy) with a spear and kettle hat"
},
{
"id": "fire_witch_of_szeged",
"n": "Fire-Witch of Szeged",
"f": "CR",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a sorceress conjuring a fireball on the Tisza riverbank"
},
{
"id": "silver_miner_of_selmec",
"n": "Silver-Miner of Selmec",
"f": "CR",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a German miner with a pick and a lamp in a silver mine"
},
{
"id": "siege_tower",
"n": "Siege Tower",
"f": "CR",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a wooden siege tower covered in hides rolling toward walls"
},
{
"id": "teutonic_knight_of_barcasag",
"n": "Teutonic Knight of Barcaság",
"f": "CR",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Teutonic knight in white mantle with black cross in the Burzenland, 1211"
},
{
"id": "spymaster_of_the_royal_court",
"n": "Spymaster of the Royal Court",
"f": "CR",
"s": 4,
"r": "close",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a large spymaster in a dim office with letters and seals"
},
{
"id": "sorceress_of_obuda",
"n": "Sorceress of Óbuda",
"f": "CR",
"s": 5,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a noble sorceress on the walls of Óbuda casting a violet spell"
},
{
"id": "wandering_peddler_spy",
"n": "Wandering Peddler-Spy",
"f": "CR",
"s": 1,
"r": "siege",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a cheerful peddler with a pack full of trinkets and hidden letters"
},
{
"id": "trebuchet",
"n": "Trebuchet",
"f": "CR",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 2,
"g": "",
"d": "core",
"p": "a giant counterweight trebuchet at dawn"
},
{
"id": "vitez_of_the_border",
"n": "Vitéz of the Border",
"f": "CR",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fierce female border warrior (vitéz) with a sabre"
},
{
"id": "dwarf_of_selmec",
"n": "Dwarf of Selmec",
"f": "CR",
"s": 2,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a stout dwarf with a war hammer and a mining helmet"
},
{
"id": "palace_scribe",
"n": "Palace Scribe",
"f": "GE",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a palace scribe writing with gold ink in a Byzantine scriptorium"
},
{
"id": "theodora_the_seeress",
"n": "Theodora the Seeress",
"f": "GE",
"s": 6,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine seeress with a golden veil, gazing into a bowl of water"
},
{
"id": "toxotai_archer",
"n": "Toxotai Archer",
"f": "GE",
"s": 10,
"r": "ranged",
"h": 0,
"a": [],
"c": 2,
"g": "",
"d": "core",
"p": "a Byzantine archer in lamellar armour drawing a composite bow"
},
{
"id": "kataphrakt_commander",
"n": "Kataphrakt Commander",
"f": "GE",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a heavily armoured Byzantine cavalry commander with a gilded helmet"
},
{
"id": "court_informant",
"n": "Court Informant",
"f": "GE",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a veiled court lady whispering a secret behind a column"
},
{
"id": "monastery_healer",
"n": "Monastery Healer",
"f": "GE",
"s": 1,
"r": "ranged",
"h": 0,
"a": [
"medic"
],
"c": 2,
"g": "",
"d": "core",
"p": "a monk healer from a Byzantine monastery hospital with herbs"
},
{
"id": "sorceress_of_the_purple_court",
"n": "Sorceress of the Purple Court",
"f": "GE",
"s": 6,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a sorceress in purple silk with golden embroidery casting a spell"
},
{
"id": "greek_fire_siphon",
"n": "Greek Fire Siphon",
"f": "GE",
"s": 10,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a bronze siphon spraying Greek fire from a dromon ship"
},
{
"id": "varangian_guard",
"n": "Varangian Guard",
"f": "GE",
"s": 3,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 4,
"g": "varangians",
"d": "core",
"p": "a Varangian guardsman with a long-hafted axe and a red cloak"
},
{
"id": "andronikos_kontostephanos",
"n": "Andronikos Kontostephanos",
"f": "GE",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "the victorious Byzantine general of Sirmium 1167 in gilded armour"
},
{
"id": "grand_domestic_john_axouch",
"n": "Grand Domestic John Axouch",
"f": "GE",
"s": 10,
"r": "close",
"h": 1,
"a": [
"medic"
],
"c": 1,
"g": "",
"d": "core",
"p": "the grand domestic of the Byzantine army, wise and stern, with a baton"
},
{
"id": "skoutatos_spearman",
"n": "Skoutatos Spearman",
"f": "GE",
"s": 3,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine infantryman with a large oval shield and a spear"
},
{
"id": "megas_doux_of_the_fleet",
"n": "Megas Doux of the Fleet",
"f": "GE",
"s": 10,
"r": "siege",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "the Byzantine grand admiral on a dromon deck"
},
{
"id": "kataphrakt_rider",
"n": "Kataphrakt Rider",
"f": "GE",
"s": 2,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "kataphrakts",
"d": "core",
"p": "a fully armoured Byzantine cavalry rider with a lance"
},
{
"id": "psiloi_slinger",
"n": "Psiloi Slinger",
"f": "GE",
"s": 3,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a light Byzantine skirmisher whirling a sling"
},
{
"id": "palace_assassin",
"n": "Palace Assassin",
"f": "GE",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "an assassin with a curved dagger in the shadows of a marble palace"
},
{
"id": "toxotes_captain",
"n": "Toxotes Captain",
"f": "GE",
"s": 5,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine archer captain directing a volley"
},
{
"id": "old_mangonel",
"n": "Old Mangonel",
"f": "GE",
"s": 3,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "an old weathered traction mangonel"
},
{
"id": "imperial_ambassador",
"n": "Imperial Ambassador",
"f": "GE",
"s": 7,
"r": "close",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a smooth Byzantine ambassador presenting a golden gift"
},
{
"id": "imperial_siege_engineer",
"n": "Imperial Siege Engineer",
"f": "GE",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine engineer with compass and rope beside a siege engine"
},
{
"id": "engine_wright",
"n": "Engine-Wright",
"f": "GE",
"s": 0,
"r": "siege",
"h": 0,
"a": [
"medic"
],
"c": 1,
"g": "",
"d": "core",
"p": "a craftsman repairing a siege engine"
},
{
"id": "spymaster_of_the_purple_chamber",
"n": "Spymaster of the Purple Chamber",
"f": "GE",
"s": 9,
"r": "close",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine spymaster in black and purple with a signet ring"
},
{
"id": "logothete",
"n": "Logothete",
"f": "GE",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine minister of state with a scroll and seal"
},
{
"id": "strategos_nikephoros",
"n": "Strategos Nikephoros",
"f": "GE",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine strategos in gilded armour under a double-headed eagle banner"
},
{
"id": "ice_mage_of_the_pontus",
"n": "Ice-Mage of the Pontus",
"f": "GE",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine mage summoning frost"
},
{
"id": "agent_of_the_logothete",
"n": "Agent of the Logothete",
"f": "GE",
"s": 4,
"r": "close",
"h": 0,
"a": [
"spy"
],
"c": 1,
"g": "",
"d": "core",
"p": "a masked imperial agent reading a stolen letter"
},
{
"id": "akritai_borderer",
"n": "Akritai Borderer",
"f": "GE",
"s": 2,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a Byzantine frontier warrior with a spear on a rocky border"
},
{
"id": "young_kaballarios",
"n": "Young Kaballarios",
"f": "GE",
"s": 5,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 2,
"g": "kaballarioi",
"d": "core",
"p": "a young Byzantine cavalryman in shining scale armour"
},
{
"id": "greek_fire_grenadier",
"n": "Greek Fire Grenadier",
"f": "GE",
"s": 5,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a soldier hurling a clay pot of Greek fire"
},
{
"id": "cave_spider",
"n": "Cave Spider",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "cave_spiders",
"d": "core",
"p": "a giant armoured cave spider in a dark cavern"
},
{
"id": "brood_mother_spider",
"n": "Brood-Mother Spider",
"f": "NB",
"s": 6,
"r": "siege",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "cave_spiders",
"d": "core",
"p": "a colossal spider brood-mother covered in eggs"
},
{
"id": "liderc_hatchling",
"n": "Lidérc Hatchling",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a lidérc hatching from a black egg, a fiery little imp"
},
{
"id": "storm_harpy",
"n": "Storm Harpy",
"f": "NB",
"s": 2,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "a harpy shrieking in a storm"
},
{
"id": "basilisk_chick",
"n": "Basilisk Chick",
"f": "NB",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a rooster-serpent basilisk in a ruined well"
},
{
"id": "boszorkany_the_brewer",
"n": "Boszorkány: The Brewer",
"f": "NB",
"s": 6,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "boszorkany",
"d": "core",
"p": "a witch stirring a bubbling cauldron at a witches' sabbath"
},
{
"id": "boszorkany_the_spinner",
"n": "Boszorkány: The Spinner",
"f": "NB",
"s": 6,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "boszorkany",
"d": "core",
"p": "a witch spinning dark threads at a spinning wheel"
},
{
"id": "boszorkany_the_whisperer",
"n": "Boszorkány: The Whisperer",
"f": "NB",
"s": 6,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "boszorkany",
"d": "core",
"p": "a witch whispering curses to the wind"
},
{
"id": "the_undead_ispan",
"n": "The Undead Ispán",
"f": "NB",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "an undead count rising from a battlefield with a rusted crown"
},
{
"id": "stone_giant_of_the_matra",
"n": "Stone Giant of the Mátra",
"f": "NB",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a giant made of mountain rock and roots"
},
{
"id": "marsh_beetle",
"n": "Marsh Beetle",
"f": "NB",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a giant beetle in the marsh"
},
{
"id": "the_fene",
"n": "The Fene",
"f": "NB",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "the fene, a horned shaggy beast of curses, with glowing eyes"
},
{
"id": "fire_liderc",
"n": "Fire Lidérc",
"f": "NB",
"s": 6,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a lidérc as a burning man made of fire"
},
{
"id": "fog_wraith",
"n": "Fog Wraith",
"f": "NB",
"s": 2,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a wraith made of marsh fog"
},
{
"id": "sarkanykigyo",
"n": "Sárkánykígyó",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a winged dragon-serpent (sárkánykígyó) in a thunderstorm"
},
{
"id": "the_mumus",
"n": "The Mumus",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "the mumus bogeyman, a tall shadow under a bed"
},
{
"id": "church_gargoyle",
"n": "Church Gargoyle",
"f": "NB",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a stone gargoyle coming alive on a Romanesque church"
},
{
"id": "grave_ghoul",
"n": "Grave Ghoul",
"f": "NB",
"s": 1,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "ghouls",
"d": "core",
"p": "a ghoul crawling over graves"
},
{
"id": "graveyard_hag",
"n": "Graveyard Hag",
"f": "NB",
"s": 5,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a hag with a long tongue in a graveyard"
},
{
"id": "carpathian_griff",
"n": "Carpathian Griff",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a griffin on a Carpathian cliff"
},
{
"id": "harpy",
"n": "Harpy",
"f": "NB",
"s": 2,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "a harpy diving from a cliff"
},
{
"id": "frost_giant_of_the_tatras",
"n": "Frost Giant of the Tatras",
"f": "NB",
"s": 5,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a frost giant in the Tatra mountains"
},
{
"id": "the_seven_headed_dragon",
"n": "The Seven-Headed Dragon",
"f": "NB",
"s": 10,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a seven-headed dragon (hétfejű sárkány) from Hungarian folk tales"
},
{
"id": "wyrm_of_the_tisza",
"n": "Wyrm of the Tisza",
"f": "NB",
"s": 8,
"r": "agile",
"h": 1,
"a": [
"agile",
"morale"
],
"c": 1,
"g": "",
"d": "core",
"p": "a giant tentacled river wyrm rising from the Tisza"
},
{
"id": "old_man_of_the_woods",
"n": "Old Man of the Woods",
"f": "NB",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "an ancient forest spirit made of wood and moss with glowing eyes"
},
{
"id": "mano",
"n": "Manó",
"f": "NB",
"s": 2,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "manok",
"d": "core",
"p": "a mischievous little goblin (manó) with a big grin"
},
{
"id": "dogvesz_the_plague_maiden",
"n": "Dögvész, the Plague Maiden",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a plague maiden in a rotting veil with rats"
},
{
"id": "nightdrinker_lamia",
"n": "Nightdrinker: Lamia",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "nightdrinkers",
"d": "core",
"p": "a beautiful lamia vampire with a shriek"
},
{
"id": "nightdrinker_strigoi",
"n": "Nightdrinker: Strigoi",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "nightdrinkers",
"d": "core",
"p": "a bat-like strigoi vampire"
},
{
"id": "nightdrinker_upir",
"n": "Nightdrinker: Upír",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "nightdrinkers",
"d": "core",
"p": "a feral upír vampire"
},
{
"id": "nightdrinker_mora",
"n": "Nightdrinker: Mora",
"f": "NB",
"s": 4,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "nightdrinkers",
"d": "core",
"p": "a mora night-hag vampire sitting on a sleeper's chest"
},
{
"id": "nightdrinker_vrykolakas",
"n": "Nightdrinker: Vrykolakas",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 1,
"g": "nightdrinkers",
"d": "core",
"p": "a hulking vrykolakas vampire"
},
{
"id": "farkasember",
"n": "Farkasember",
"f": "NB",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a werewolf (farkasember) howling at the moon"
},
{
"id": "lesser_dragon",
"n": "Lesser Dragon",
"f": "NB",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a lesser two-legged dragon over a cliff"
},
{
"id": "bog_toad_king",
"n": "Bog-Toad King",
"f": "NB",
"s": 7,
"r": "ranged",
"h": 0,
"a": [
"scorch_ranged"
],
"c": 1,
"g": "",
"d": "mirror",
"p": "a monstrous crowned toad in a bog spitting poison"
},
{
"id": "captain_of_the_matra_dwarves",
"n": "Captain of the Mátra Dwarves",
"f": "FF",
"s": 6,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "a battle-scarred dwarf captain with a crossbow in the Mátra"
},
{
"id": "fairy_pathfinder",
"n": "Fairy Pathfinder",
"f": "FF",
"s": 3,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "a slender fairy scout with a bow among Bakony beech trees"
},
{
"id": "chieftain_of_the_bukk_dwarves",
"n": "Chieftain of the Bükk Dwarves",
"f": "FF",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a dwarf chieftain with a braided beard and a hammer in a cave of the Bükk"
},
{
"id": "tunder_archer",
"n": "Tündér Archer",
"f": "FF",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fairy archer of Tündérkert with silver hair"
},
{
"id": "tunder_scout",
"n": "Tündér Scout",
"f": "FF",
"s": 6,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 3,
"g": "",
"d": "core",
"p": "a fairy scout running through a misty forest"
},
{
"id": "bukk_dwarf_skirmisher",
"n": "Bükk Dwarf Skirmisher",
"f": "FF",
"s": 3,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "bukk_dwarves",
"d": "core",
"p": "a dwarf skirmisher with an axe charging out of a cave"
},
{
"id": "hajnal_lady_of_the_silver_birches",
"n": "Hajnal, Lady of the Silver Birches",
"f": "FF",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fairy queen-mother in a grove of silver birches, ancient and fierce"
},
{
"id": "tunder_skirmisher",
"n": "Tündér Skirmisher",
"f": "FF",
"s": 2,
"r": "ranged",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "tunder_skirmishers",
"d": "core",
"p": "a fairy skirmisher loosing arrows from a tree"
},
{
"id": "elder_of_the_fairy_garden",
"n": "Elder of the Fairy Garden",
"f": "FF",
"s": 6,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "an ancient fairy elder in a ruined fairy garden"
},
{
"id": "fuvesasszony_herb_wife",
"n": "Füvesasszony Herb-Wife",
"f": "FF",
"s": 0,
"r": "ranged",
"h": 0,
"a": [
"medic"
],
"c": 3,
"g": "",
"d": "core",
"p": "an old herb-wife gathering herbs in a forest clearing"
},
{
"id": "bakony_outlaw",
"n": "Bakony Outlaw",
"f": "FF",
"s": 5,
"r": "close",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "bakony_outlaws",
"d": "core",
"p": "a forest outlaw with a hatchet-staff and a sheepskin cloak"
},
{
"id": "fairy_seeress",
"n": "Fairy Seeress",
"f": "FF",
"s": 6,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fairy seeress with glowing eyes in an old ruin"
},
{
"id": "csongor_the_wanderer",
"n": "Csongor the Wanderer",
"f": "FF",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a wandering hero-archer searching for the fairy garden"
},
{
"id": "old_gyula_outlaw_lord",
"n": "Old Gyula, Outlaw Lord",
"f": "FF",
"s": 10,
"r": "close",
"h": 1,
"a": [
"morale"
],
"c": 1,
"g": "",
"d": "core",
"p": "a scarred grey-haired outlaw lord with two swords"
},
{
"id": "mountain_dwarf_defender",
"n": "Mountain Dwarf Defender",
"f": "FF",
"s": 5,
"r": "close",
"h": 0,
"a": [],
"c": 5,
"g": "",
"d": "core",
"p": "a dwarf with a huge round shield guarding a mountain gate"
},
{
"id": "huntress_rozalia",
"n": "Huntress Rozália",
"f": "FF",
"s": 10,
"r": "ranged",
"h": 0,
"a": [
"morale"
],
"c": 1,
"g": "",
"d": "core",
"p": "a fierce huntress with a longbow in the Bakony"
},
{
"id": "fairy_apprentice",
"n": "Fairy Apprentice",
"f": "FF",
"s": 1,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a young fairy learning archery"
},
{
"id": "tunde_the_dragon_fairy",
"n": "Tünde the Dragon-Fairy",
"f": "FF",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fairy princess whose shadow is a golden dragon"
},
{
"id": "fairy_bowmaiden",
"n": "Fairy Bowmaiden",
"f": "FF",
"s": 2,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a fairy bowmaiden with a scornful look"
},
{
"id": "greenwood_recruit",
"n": "Greenwood Recruit",
"f": "FF",
"s": 4,
"r": "ranged",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "core",
"p": "a young forest rebel with a short bow"
},
{
"id": "greenwood_veteran",
"n": "Greenwood Veteran",
"f": "FF",
"s": 5,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 2,
"g": "",
"d": "core",
"p": "a seasoned forest rebel with a sword and a hood"
},
{
"id": "outlaw_captain",
"n": "Outlaw Captain",
"f": "FF",
"s": 6,
"r": "agile",
"h": 0,
"a": [
"agile"
],
"c": 1,
"g": "",
"d": "core",
"p": "a charismatic outlaw captain with a feathered cap"
},
{
"id": "dwarven_fire_mortar",
"n": "Dwarven Fire-Mortar",
"f": "FF",
"s": 8,
"r": "siege",
"h": 0,
"a": [
"scorch_siege"
],
"c": 1,
"g": "",
"d": "mirror",
"p": "a dwarf lighting a primitive fire-mortar in a ruined castle"
},
{
"id": "bear_kin_warrior",
"n": "Bear-Kin Warrior",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [
"bearkin"
],
"c": 1,
"g": "bear",
"d": "river",
"p": "a wild warrior with a bear pelt and an axe"
},
{
"id": "young_bear_kin",
"n": "Young Bear-Kin",
"f": "RC",
"s": 2,
"r": "ranged",
"h": 0,
"a": [
"bearkin"
],
"c": 3,
"g": "young_bear",
"d": "river",
"p": "a young warrior with a bear pelt and a bow"
},
{
"id": "clan_wise_woman",
"n": "Clan Wise-Woman",
"f": "RC",
"s": 2,
"r": "close",
"h": 0,
"a": [
"medic"
],
"c": 1,
"g": "",
"d": "river",
"p": "a clan wise-woman with herbs and bone charms"
},
{
"id": "bulcsu_the_blue_eyed",
"n": "Bulcsú the Blue-Eyed",
"f": "RC",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a tall blue-eyed river chieftain with an axe"
},
{
"id": "reka_shield_queen",
"n": "Réka, Shield-Queen",
"f": "RC",
"s": 10,
"r": "close",
"h": 1,
"a": [
"muster"
],
"c": 1,
"g": "shieldmaidens",
"d": "river",
"p": "a fierce young shield-queen leading shieldmaidens"
},
{
"id": "tisza_clan_warrior",
"n": "Tisza Clan Warrior",
"f": "RC",
"s": 6,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "tisza_clan",
"d": "river",
"p": "a river-clan warrior with an axe and round shield"
},
{
"id": "kende_clan_archer",
"n": "Kende Clan Archer",
"f": "RC",
"s": 6,
"r": "ranged",
"h": 0,
"a": [],
"c": 3,
"g": "",
"d": "river",
"p": "a river-clan archer on a riverbank"
},
{
"id": "danube_fire_raider",
"n": "Danube Fire-Raider",
"f": "RC",
"s": 6,
"r": "ranged",
"h": 0,
"a": [
"scorch"
],
"c": 1,
"g": "",
"d": "river",
"p": "a river raider throwing fire from a galley"
},
{
"id": "shieldmaiden_of_reka",
"n": "Shieldmaiden of Réka",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "shieldmaidens",
"d": "river",
"p": "a shieldmaiden with a painted round shield"
},
{
"id": "regos_singer",
"n": "Regös Singer",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a regös singer with a drum telling old tales"
},
{
"id": "clan_smith_of_vasvar",
"n": "Clan Smith of Vasvár",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a clan smith hammering a glowing sword"
},
{
"id": "elder_kurszan",
"n": "Elder Kurszán",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "an old clan elder with a staff"
},
{
"id": "river_horn_blower",
"n": "River Horn-Blower",
"f": "RC",
"s": 2,
"r": "siege",
"h": 0,
"a": [
"horn"
],
"c": 1,
"g": "",
"d": "river",
"p": "a bard blowing a horn on a galley prow"
},
{
"id": "old_taltos_of_the_clans",
"n": "Old Táltos of the Clans",
"f": "RC",
"s": 8,
"r": "ranged",
"h": 1,
"a": [
"brew"
],
"c": 1,
"g": "",
"d": "river",
"p": "an old táltos shaman with a drum and mushrooms"
},
{
"id": "almos_the_dream_born",
"n": "Álmos the Dream-Born",
"f": "RC",
"s": 10,
"r": "ranged",
"h": 1,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a young chieftain under a giant eagle dream vision"
},
{
"id": "shipwright_hollo",
"n": "Shipwright Holló",
"f": "RC",
"s": 4,
"r": "siege",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a one-handed shipwright with a raven"
},
{
"id": "turul_chick",
"n": "Turul Chick",
"f": "RC",
"s": 0,
"r": "close",
"h": 0,
"a": [
"summon_avenger"
],
"c": 1,
"g": "turul",
"d": "river",
"p": "a tiny falcon chick (turul) in a nest"
},
{
"id": "light_river_boat",
"n": "Light River Boat",
"f": "RC",
"s": 4,
"r": "ranged",
"h": 0,
"a": [
"muster"
],
"c": 3,
"g": "river_boats",
"d": "river",
"p": "a light river boat with oars on the Danube"
},
{
"id": "madman_of_the_reeds",
"n": "Madman of the Reeds",
"f": "RC",
"s": 6,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a wild-eyed warrior emerging from reeds"
},
{
"id": "kende_the_bear_father",
"n": "Kende the Bear-Father",
"f": "RC",
"s": 12,
"r": "agile",
"h": 0,
"a": [
"agile",
"morale"
],
"c": 1,
"g": "",
"d": "river",
"p": "a huge chieftain who is half bear"
},
{
"id": "young_chieftain_taksony",
"n": "Young Chieftain Taksony",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a proud young chieftain on a river boat"
},
{
"id": "haunted_szabolcs",
"n": "Haunted Szabolcs",
"f": "RC",
"s": 4,
"r": "close",
"h": 0,
"a": [],
"c": 1,
"g": "",
"d": "river",
"p": "a haunted warrior seeing ghosts"
},
{
"id": "danube_war_galley",
"n": "Danube War Galley",
"f": "RC",
"s": 6,
"r": "siege",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "war_galleys",
"d": "river",
"p": "a war galley with a carved prow on the Danube"
},
{
"id": "taltos_brew",
"n": "Táltos Brew",
"f": "RC",
"s": 0,
"r": "special",
"h": 0,
"a": [
"brew"
],
"c": 3,
"g": "",
"d": "river",
"p": "a steaming wooden cup of mushroom brew beside red-capped mushrooms on a mossy stone"
},
{
"id": "the_great_turul",
"n": "The Great Turul",
"f": "RC",
"s": 11,
"r": "close",
"h": 1,
"a": [],
"c": 1,
"g": "turul",
"d": "river",
"t": 1,
"p": "the great mythical turul bird with a sword in its talons"
},
{
"id": "bear_of_the_danube",
"n": "Bear of the Danube",
"f": "RC",
"s": 14,
"r": "close",
"h": 0,
"a": [
"morale"
],
"c": 1,
"g": "bear",
"d": "river",
"t": 1,
"p": "a huge bear warrior roaring"
},
{
"id": "young_danube_bear",
"n": "Young Danube Bear",
"f": "RC",
"s": 8,
"r": "ranged",
"h": 0,
"a": [
"bond"
],
"c": 3,
"g": "young_bear",
"d": "river",
"t": 1,
"p": "a young bear warrior"
}
];
const LEADER_DATA=[
{
"id": "cr_coloman_the_learned_keeper_of_the_mists",
"f": "CR",
"n": "Coloman the Learned",
"ti": "Keeper of the Mists",
"k": "play_fog_from_deck",
"d": "core",
"p": "a scholarly king with a book and crown, mist rising behind him"
},
{
"id": "cr_saint_ladislaus_the_knight_king",
"f": "CR",
"n": "Saint Ladislaus",
"ti": "the Knight-King",
"k": "clear_weather",
"d": "core",
"p": "a tall knight-king on horseback with a battle-axe"
},
{
"id": "cr_bela_iv_the_second_founder",
"f": "CR",
"n": "Béla IV",
"ti": "the Second Founder",
"k": "horn_siege",
"d": "core",
"p": "a king rebuilding stone castles after the Mongol invasion"
},
{
"id": "cr_charles_robert_breaker_of_oligarchs",
"f": "CR",
"n": "Charles Robert",
"ti": "Breaker of Oligarchs",
"k": "scorch_siege",
"d": "core",
"p": "an Anjou king with lilies on his surcoat storming a rebel castle"
},
{
"id": "cr_louis_the_great_lord_of_three_seas",
"f": "CR",
"n": "Louis the Great",
"ti": "Lord of Three Seas",
"k": "scorch_ranged",
"d": "mirror",
"p": "a magnificent king in Anjou lilies with three seas behind him"
},
{
"id": "ge_alexios_bela_despot_of_two_crowns",
"f": "GE",
"n": "Alexios Béla",
"ti": "Despot of Two Crowns",
"k": "play_rain_from_deck",
"d": "core",
"p": "a Hungarian prince raised in Constantinople, in Byzantine robes"
},
{
"id": "ge_anna_komnene_the_chronicler",
"f": "GE",
"n": "Anna Komnene",
"ti": "the Chronicler",
"k": "view_3_opponent_hand",
"d": "core",
"p": "a Byzantine princess-historian writing a chronicle"
},
{
"id": "ge_manuel_i_komnenos_the_basileus",
"f": "GE",
"n": "Manuel I Komnenos",
"ti": "the Basileus",
"k": "cancel_enemy_leader",
"d": "core",
"p": "a Byzantine emperor on a golden throne"
},
{
"id": "ge_andronikos_komnenos_the_usurper",
"f": "GE",
"n": "Andronikos Komnenos",
"ti": "the Usurper",
"k": "take_from_enemy_discard",
"d": "core",
"p": "a charismatic usurper seizing a crown"
},
{
"id": "ge_irene_piroska_founder_of_the_pantokrator",
"f": "GE",
"n": "Irene Piroska",
"ti": "Founder of the Pantokrator",
"k": "random_medic",
"d": "mirror",
"p": "a Hungarian-born Byzantine empress founding a hospital"
},
{
"id": "nb_vasorru_baba_mother_of_the_brood",
"f": "NB",
"n": "Vasorrú Bába",
"ti": "Mother of the Brood",
"k": "horn_close",
"d": "core",
"p": "the iron-nosed hag of folk tales"
},
{
"id": "nb_the_liderc_lord_bringer_of_death",
"f": "NB",
"n": "The Lidérc Lord",
"ti": "Bringer of Death",
"k": "discard_to_hand",
"d": "core",
"p": "a fiery lidérc in the shape of a lordly man"
},
{
"id": "nb_the_dragon_king_devourer_of_realms",
"f": "NB",
"n": "The Dragon King",
"ti": "Devourer of Realms",
"k": "discard2_pick1",
"d": "core",
"p": "a dragon king in human form with a crown of horns"
},
{
"id": "nb_the_garaboncias_rider_of_storms",
"f": "NB",
"n": "The Garabonciás",
"ti": "Rider of Storms",
"k": "play_any_weather_from_deck",
"d": "core",
"p": "a wandering scholar-sorcerer riding a dragon through storm clouds"
},
{
"id": "nb_the_ordog_the_deceiver",
"f": "NB",
"n": "The Ördög",
"ti": "the Deceiver",
"k": "double_spies",
"d": "mirror",
"p": "a sly folk devil offering a bargain"
},
{
"id": "ff_tunder_ilona_queen_of_the_fairy_garden",
"f": "FF",
"n": "Tündér Ilona",
"ti": "Queen of the Fairy Garden",
"k": "scorch_close",
"d": "core",
"p": "the fairy queen in her garden of golden apples"
},
{
"id": "ff_tunder_ilona_the_radiant",
"f": "FF",
"n": "Tündér Ilona",
"ti": "the Radiant",
"k": "horn_ranged",
"d": "core",
"p": "the fairy queen glowing with moonlight"
},
{
"id": "ff_tunder_ilona_keeper_of_the_golden_apples",
"f": "FF",
"n": "Tündér Ilona",
"ti": "Keeper of the Golden Apples",
"k": "extra_card_start",
"d": "core",
"p": "the fairy queen guarding a tree of golden apples"
},
{
"id": "ff_tunder_ilona_of_the_winter_moon",
"f": "FF",
"n": "Tündér Ilona",
"ti": "of the Winter Moon",
"k": "play_frost_from_deck",
"d": "core",
"p": "the fairy queen in a winter forest"
},
{
"id": "ff_tunder_ilona_hope_of_the_greenwood",
"f": "FF",
"n": "Tündér Ilona",
"ti": "Hope of the Greenwood",
"k": "optimize_agile",
"d": "mirror",
"p": "the fairy queen leading forest folk"
},
{
"id": "rc_botond_of_the_iron_mace",
"f": "RC",
"n": "Botond",
"ti": "of the Iron Mace",
"k": "shuffle_graveyards_into_decks",
"d": "river",
"p": "a legendary warrior striking a city gate with an iron mace"
},
{
"id": "rc_lehel_of_the_horn",
"f": "RC",
"n": "Lehel",
"ti": "of the Horn",
"k": "weather_halves",
"d": "river",
"p": "a legendary chieftain with a carved horn"
}
];
const FACTION_INFO={"CR": {"name": "Holy Crown of Hungaria", "lore": "The Árpád kingdom of the Carpathian Basin: stone castles raised after the Mongol storm, knights under red-and-silver stripes, Cuman horse archers and Saxon engineers."}, "GE": {"name": "Golden Basileia", "lore": "The empire of the Golden City on the Bosporus: purple silk, Varangian axes, Greek fire and a court where every whisper is a weapon."}, "FF": {"name": "Free Folk of the Bakony", "lore": "Fairies of Tündér Ilona's garden, dwarves of the Bükk and Mátra, outlaws and herb-wives who own the old forests and answer to no king."}, "NB": {"name": "Night Brood", "lore": "The creatures of Hungarian folk belief: lidérc, boszorkány witches, the garabonciás storm-rider, the iron-nosed hag and the seven-headed dragon."}, "RC": {"name": "River Clans of the Danube", "lore": "Chieftain-clans of the Danube and the Tisza: river galleys, shieldmaidens, táltos shamans and bear-kin warriors who drink the táltos brew."}, "NE": {"name": "Neutral", "lore": "Wanderers, saints, legends and beasts who fight for any banner."}};
